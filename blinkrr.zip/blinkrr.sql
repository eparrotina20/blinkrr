/*
SQLyog Ultimate v10.00 Beta1
MySQL - 5.5.5-10.1.19-MariaDB : Database - blinkrr
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`blinkrr` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `blinkrr`;

/*Table structure for table `accredited_insurance` */

DROP TABLE IF EXISTS `accredited_insurance`;

CREATE TABLE `accredited_insurance` (
  `acc_ins_id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact` varchar(25) DEFAULT NULL,
  `status` varchar(25) NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`acc_ins_id`),
  KEY `optshop_id` (`owner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

/*Data for the table `accredited_insurance` */

insert  into `accredited_insurance`(`acc_ins_id`,`owner_id`,`company_name`,`address`,`contact`,`status`) values (6,9,'PAGIBIG','0324-B V. Ranudo st. Cebu City','09231431923','Active'),(7,9,'AsianLife Financial Assurance Corporation',' ',' ','Active'),(8,9,'BPI-Philam Life Assurance Corporation','','','Inactive'),(9,9,'CAP Life Insurance Corporation','','','Active'),(10,9,'Insular Life Assurance Company','','','Inactive'),(11,9,'Sun Life of Canada (Philippines), Inc.','','','Inactive'),(12,0,'cc','cc','cc','Inactive'),(13,0,'dd','dd','dd','Inactive'),(14,0,'bb','bb','bb','Inactive'),(15,0,'xx','xx','xx','Inactive'),(16,0,'cc','cc','cc','Inactive'),(17,0,'dd','dd','dd','Inactive'),(18,10,'aa','aa','aa','Inactive'),(19,10,'bb','bb','bb','Inactive'),(20,10,'xx','xxx','xx','Inactive');

/*Table structure for table `activity_log` */

DROP TABLE IF EXISTS `activity_log`;

CREATE TABLE `activity_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `optshop_id` int(11) NOT NULL,
  `ctr` int(11) NOT NULL,
  `dtime` datetime NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `optshop_id` (`optshop_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `activity_log` */

/*Table structure for table `appointment` */

DROP TABLE IF EXISTS `appointment`;

CREATE TABLE `appointment` (
  `appointment_id` int(11) NOT NULL AUTO_INCREMENT,
  `optshop_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `emp_id` int(11) DEFAULT '0',
  `services` varchar(150) NOT NULL,
  `app_date` varchar(1000) NOT NULL,
  `app_time` varchar(1000) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`appointment_id`),
  KEY `patient_id` (`patient_id`),
  KEY `emp_id` (`emp_id`),
  KEY `services_id` (`services`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

/*Data for the table `appointment` */

insert  into `appointment`(`appointment_id`,`optshop_id`,`patient_id`,`emp_id`,`services`,`app_date`,`app_time`,`status`) values (51,29,37,6,'21','12/28/2016','10:00am','Approved'),(52,29,37,0,'23','01/27/2017','2:00pm','Pending'),(53,46,37,0,'24','01/26/2017','09:12am','Pending');

/*Table structure for table `bak_notifications` */

DROP TABLE IF EXISTS `bak_notifications`;

CREATE TABLE `bak_notifications` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `notif_type` varchar(25) NOT NULL,
  `field_id` int(11) NOT NULL,
  `path` varchar(25) DEFAULT NULL,
  `optshop_id` int(11) NOT NULL,
  `sentto` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'unread',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `message` varchar(100) NOT NULL,
  PRIMARY KEY (`notification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=latin1;

/*Data for the table `bak_notifications` */

insert  into `bak_notifications`(`notification_id`,`notif_type`,`field_id`,`path`,`optshop_id`,`sentto`,`user_id`,`status`,`date`,`message`) values (66,'Subscription',0,'subscription.php',28,'Owner',9,'read','2016-05-23 03:09:02','Your Optical Shop has no Subscription!'),(67,'Appointment',34,'appointmentlist.php',27,'Employee',6,'unread','0000-00-00 00:00:00','New Reservation from Magto, Clairemji '),(68,'Appointment',34,'appointmentlist.php',27,'Owner',9,'read','0000-00-00 00:00:00','New Reservation from Magto, Clairemji '),(69,'Reservation',36,'reservationlist.php',27,'Employee',6,'unread','0000-00-00 00:00:00','New Reservation from Magto, Clairemji '),(70,'Reservation',36,'reservationlist.php',27,'Employee',7,'read','0000-00-00 00:00:00','New Reservation from Magto, Clairemji '),(71,'Reservation',36,'reservationlist.php',27,'Owner',9,'unread','0000-00-00 00:00:00','New Reservation from Magto, Clairemji '),(72,'Reservation',37,'reservationlist.php',27,'Employee',6,'unread','0000-00-00 00:00:00','New Reservation from Magto, Clairemji '),(73,'Reservation',37,'reservationlist.php',27,'Employee',7,'unread','0000-00-00 00:00:00','New Reservation from Magto, Clairemji '),(74,'Reservation',37,'reservationlist.php',27,'Owner',9,'unread','0000-00-00 00:00:00','New Reservation from Magto, Clairemji ');

/*Table structure for table `brand` */

DROP TABLE IF EXISTS `brand`;

CREATE TABLE `brand` (
  `brand_id` int(11) NOT NULL AUTO_INCREMENT,
  `optshop_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;

/*Data for the table `brand` */

insert  into `brand`(`brand_id`,`optshop_id`,`name`,`logo`) values (53,27,'Oakley','../images/product/List-of-22-Top-Sunglasses-Brands-and-Their-Logos.jpg'),(54,27,'Ray Ban','../images/product/Ray-ban-logos.jpg');

/*Table structure for table `discounts` */

DROP TABLE IF EXISTS `discounts`;

CREATE TABLE `discounts` (
  `discount_id` int(11) NOT NULL AUTO_INCREMENT,
  `optshop_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `rate` int(11) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`discount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `discounts` */

/*Table structure for table `employees` */

DROP TABLE IF EXISTS `employees`;

CREATE TABLE `employees` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `password` varchar(25) NOT NULL,
  `optshop_id` int(11) NOT NULL,
  `fname` varchar(25) NOT NULL,
  `mname` varchar(25) DEFAULT NULL,
  `lname` varchar(25) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `civil_status` varchar(10) NOT NULL,
  `emp_image` varchar(255) DEFAULT NULL,
  `DOB` date NOT NULL,
  `position` varchar(25) NOT NULL,
  `licenseNo` varchar(50) DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`emp_id`),
  KEY `optshop_id` (`optshop_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

/*Data for the table `employees` */

insert  into `employees`(`emp_id`,`email`,`password`,`optshop_id`,`fname`,`mname`,`lname`,`address`,`contact`,`gender`,`civil_status`,`emp_image`,`DOB`,`position`,`licenseNo`,`status`) values (6,'maryallyn','budlat',29,'Mary Allyn','','Manguilimotan','Lasang','092626010','Female','Married','images/default.png','1991-12-21','Optometrist','111000333','Active'),(7,'parrot@gmail.com','parrotina',29,'Mary Allyn','','Manguilimotan','Bukid','092626010','Female','Single','images/default.png','2001-02-04','Admin','12345678','Active'),(8,'staff','staff',29,'Arcu','Ba','Balino','Staff','Staff','Male','Single','images/default.png','2016-11-10','Staff','234','Active'),(9,'admin','admin',27,'Aadmin','Aadmin','Aadmin','Aadmin','Aadmin','Male','Single','images/default.png','2016-11-10','Admin','234234','Active'),(12,'homera','',29,'Homera','homera','Simpsona','homera','234234','Male','Single','system/images/employees/161116025510_homer-glasses.png','0000-00-00','Staff','2342341','Active'),(0,'None','None',0,' ',' ',' ','None','None','None','None','None','2016-12-07','Staff','232','Inactive'),(14,'ran.revolution@gmail.com','resetwr30m',29,'Ranil','Berezo','Jaramillo','Mandaue City','1231','Male','Single','system/images/employees/170119034407_amazing Iron Man Widescreen Hd Wallpaper.jpg','0000-00-00','Staff','1231','Active'),(15,'ac','ac',29,'ac','ac','ac','ac','12313','Female','Single','system/images/employees/170119034508_amazing Iron Man Widescreen Hd Wallpaper.jpg','2017-01-19','Staff','231231','Inactive'),(16,'afa','asdf',29,'adfa','adfa','adfa','123','123','Female','Married','system/images/employees/170128044935_amazing Iron Man Widescreen Hd Wallpaper.jpg','0000-00-00','Optometrist','1231','Active'),(17,'vv','vv',29,'vv','vv','vv','vv','123','Male','Single','system/images/employees/170128044959_amazing Iron Man Widescreen Hd Wallpaper.jpg','2017-01-28','Staff','123121','Active');

/*Table structure for table `insurance` */

DROP TABLE IF EXISTS `insurance`;

CREATE TABLE `insurance` (
  `insurance_id` int(11) NOT NULL AUTO_INCREMENT,
  `pathis_id` int(11) NOT NULL,
  `acc_ins_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `agreement` varchar(100) NOT NULL,
  `authorized_person` varchar(100) NOT NULL,
  `amount` double NOT NULL,
  `status` varchar(25) NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`insurance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `insurance` */

insert  into `insurance`(`insurance_id`,`pathis_id`,`acc_ins_id`,`date`,`agreement`,`authorized_person`,`amount`,`status`) values (1,22,6,'2016-12-09 10:53:38','he Committee may terminate this Agreement at any time by 10 ','Dr. Jack Black',2000,'Active'),(3,24,0,'2017-01-09 03:18:08','bb','bb',1231,'Active');

/*Table structure for table `job_orders` */

DROP TABLE IF EXISTS `job_orders`;

CREATE TABLE `job_orders` (
  `joborder_id` int(11) NOT NULL AUTO_INCREMENT,
  `optshop_id` int(11) NOT NULL,
  `optprod_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `promo_id` int(11) DEFAULT NULL,
  `emp_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `due_date` date NOT NULL,
  `od` varchar(10) DEFAULT NULL,
  `os` varchar(10) DEFAULT NULL,
  `remark` varchar(50) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `total` double NOT NULL,
  `deposit` varchar(1000) DEFAULT NULL,
  `payment_status` varchar(10) NOT NULL DEFAULT 'Unpaid',
  `status` varchar(20) NOT NULL DEFAULT 'Reserved',
  PRIMARY KEY (`joborder_id`),
  KEY `optprod_id` (`optprod_id`),
  KEY `patient_id` (`patient_id`),
  KEY `promo_id` (`promo_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

/*Data for the table `job_orders` */

insert  into `job_orders`(`joborder_id`,`optshop_id`,`optprod_id`,`patient_id`,`promo_id`,`emp_id`,`date`,`due_date`,`od`,`os`,`remark`,`discount`,`total`,`deposit`,`payment_status`,`status`) values (13,29,50,36,1,8,'2017-01-09 01:34:04','2017-01-09','1231','123','sfdfs',500,200,'1000','Sold','Sold'),(14,29,50,36,1,8,'2017-01-09 01:52:53','2017-01-20','12312','1231','sdfsdf',500,200,'1231','Sold','Sold');

/*Table structure for table `joborder_products` */

DROP TABLE IF EXISTS `joborder_products`;

CREATE TABLE `joborder_products` (
  `jobprod_id` int(11) NOT NULL AUTO_INCREMENT,
  `joborder_id` int(11) NOT NULL,
  `optprod_id` int(11) NOT NULL,
  PRIMARY KEY (`jobprod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `joborder_products` */

/*Table structure for table `my_cart` */

DROP TABLE IF EXISTS `my_cart`;

CREATE TABLE `my_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `optshop_id` int(11) NOT NULL,
  `optprod_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `payment_status` varchar(10) NOT NULL DEFAULT 'Unpaid',
  `status` varchar(20) NOT NULL DEFAULT 'Pending',
  `date_paid` date DEFAULT NULL,
  `sdate` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `optprod_id` (`optprod_id`),
  KEY `patient_id` (`patient_id`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;

/*Data for the table `my_cart` */

insert  into `my_cart`(`id`,`optshop_id`,`optprod_id`,`qty`,`patient_id`,`payment_status`,`status`,`date_paid`,`sdate`) values (55,29,49,35,37,'Paid','Paid','2017-01-23','2017-01-28'),(54,29,50,4,37,'Paid','Paid','2017-01-23','2017-01-28'),(56,27,48,2,37,'Unpaid','Pending',NULL,'2017-01-28');

/*Table structure for table `notifications` */

DROP TABLE IF EXISTS `notifications`;

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` int(255) NOT NULL,
  `receiver` int(255) NOT NULL,
  `module` varchar(1000) NOT NULL,
  `date_send` varchar(1000) NOT NULL,
  `status` int(255) NOT NULL COMMENT '0 - Unread | 1 - Read',
  `message` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `notifications` */

insert  into `notifications`(`id`,`sender`,`receiver`,`module`,`date_send`,`status`,`message`) values (5,37,29,'Reservation','2016-12-25',1,'You receive new appointment'),(6,29,37,'Reservation','2016-12-25',1,'Your appointment has been approved'),(7,37,29,'Appointment','2017-01-22',1,'You receive new appointment'),(8,37,46,'Appointment','2017-01-22',0,'You receive new appointment'),(9,37,28,'Product Reservation','2017-01-28',0,'Customer reserved a product'),(10,37,29,'Product Reservation','2017-01-28',1,'Customer reserved a product');

/*Table structure for table `opt_products` */

DROP TABLE IF EXISTS `opt_products`;

CREATE TABLE `opt_products` (
  `optprod_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `gender` varchar(25) DEFAULT NULL,
  `optshop_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `model` varchar(1000) DEFAULT NULL,
  `description` varchar(100) NOT NULL,
  `brand` varchar(50) DEFAULT NULL,
  `qty` int(11) NOT NULL,
  `reserved_qty` int(11) NOT NULL,
  `reorder` int(11) NOT NULL,
  `discount` int(11) NOT NULL DEFAULT '0',
  `price` int(255) NOT NULL,
  `optprod_img` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Available',
  `material` varchar(255) DEFAULT NULL,
  `lens_type` varchar(50) DEFAULT NULL,
  `lens_size` varchar(25) DEFAULT NULL,
  `rim` varchar(50) DEFAULT NULL,
  `frame_color` varchar(50) DEFAULT NULL,
  `frame_shape` varchar(50) DEFAULT NULL,
  `volume` int(11) DEFAULT NULL COMMENT 'in ml',
  `supplier_id` int(255) DEFAULT NULL,
  PRIMARY KEY (`optprod_id`),
  KEY `optshop_id` (`optshop_id`),
  KEY `type_id` (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;

/*Data for the table `opt_products` */

insert  into `opt_products`(`optprod_id`,`name`,`gender`,`optshop_id`,`type_id`,`model`,`description`,`brand`,`qty`,`reserved_qty`,`reorder`,`discount`,`price`,`optprod_img`,`status`,`material`,`lens_type`,`lens_size`,`rim`,`frame_color`,`frame_shape`,`volume`,`supplier_id`) values (50,'Ray Ban','Unisex',29,1,'rb100','Ray Ban','Ray Ban',55,1,50,0,700,'system/images/products/converse-male.jpg','Available','plastic','rounded','15','round','brown','rounded',0,8),(49,'Ban Ray','Unisex',29,6,'rb100','Ray Ban','Ray Ban',65,0,65,0,700,'system/images/products/polo-male.jpg','Available','plastic','rounded','15','round','BLACK','rounded',0,8),(48,'Ray Ban Master','Female',27,1,'rb110','Ray Ban Master','Ray Ban',96,2,50,0,800,'system/images/products/tomford-female.jpg','Available','Plastic','Biconvex','18','full','Brown','rounded',0,8),(47,'Future Din','Unisex',28,1,'o101','Oakley Eyeglasses','Oakley',46,6,20,0,1500,'system/images/products/polo-female.jpg','Available','Metal','Uv resistant','18','full','Black','rounded',0,8),(52,'homer-glasses.png','Unisex',29,6,'aa','xx','xx',98,0,50,0,2000,'system/images/products/161128024524_homer-glasses.png','Available','xx','xx','xx','xx','xx','xx',0,8),(53,'aira1','Male',30,0,NULL,'aira1','aira1',58,231,231,231,123,'system/images/products/161129015244_avatar.png','Available','aira1','aira1','231','aira1','aira1','aira1',1,8),(56,'aa','Male',29,2,'aa','afa','aa',43,123,123,0,123,'system/images/products/170128024012_amazing Iron Man Widescreen Hd Wallpaper.jpg','Available','aa','aa','aa','aa','aa','aa',213,8),(57,'dd','Male',29,1,'1231','dd','dd',23,123,123,1231,123,'images/s-img1.jpg','Available','dd','123','123','dd','dd','dd',123,11);

/*Table structure for table `opt_shops` */

DROP TABLE IF EXISTS `opt_shops`;

CREATE TABLE `opt_shops` (
  `optshop_id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) NOT NULL,
  `optshop_name` varchar(50) NOT NULL,
  `optshop_add` varchar(50) NOT NULL,
  `optshop_tel` varchar(20) NOT NULL,
  `optshop_lat` float(10,6) DEFAULT NULL,
  `optshop_long` float(10,6) DEFAULT NULL,
  `optshop_status` varchar(20) NOT NULL DEFAULT 'Active',
  `optshop_img` varchar(255) DEFAULT NULL,
  `term` int(11) NOT NULL DEFAULT '0',
  `optshop_from_hour` int(255) DEFAULT NULL,
  `optshop_from_min` varchar(1000) DEFAULT NULL,
  `optshop_to_hour` int(255) DEFAULT NULL,
  `optshop_to_min` varchar(1000) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  PRIMARY KEY (`optshop_id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

/*Data for the table `opt_shops` */

insert  into `opt_shops`(`optshop_id`,`owner_id`,`optshop_name`,`optshop_add`,`optshop_tel`,`optshop_lat`,`optshop_long`,`optshop_status`,`optshop_img`,`term`,`optshop_from_hour`,`optshop_from_min`,`optshop_to_hour`,`optshop_to_min`,`created_at`) values (28,9,'HP Acebedo','Ramos Cebu City','09436446449',10.307006,123.896538,'Active','system/images/optical_shops/acebedo.jpg',5,7,'30',20,'00','2017-01-23'),(27,22,'Parrotina','Sanciangko St., Cebu City','09253497907',10.297721,123.897415,'Active','system/images/optical_shops/glory optics.png',5,7,'30',20,'00','2017-01-23'),(29,10,'Mandaue Opticals','Mandaue City Cebu Philippines','23234',10.340262,0.000000,'Active','system/images/optical_shops/170119030838_1432712191.jpg',0,7,'30',20,'00','2017-01-23'),(45,14,'Sleeping Forest','Cebu City','09173044222',NULL,NULL,'Active','images/default_glass.png',0,7,'30',20,'00','2017-01-23'),(46,15,'Arcubalino','rr','31231',NULL,NULL,'Active','images/default_glass.png',0,7,'00',19,'00','2017-01-23'),(53,21,'tt','tt','',NULL,NULL,'Active','images/default_glass.png',0,6,'00',18,'00','2017-01-24');

/*Table structure for table `optprod_supplier` */

DROP TABLE IF EXISTS `optprod_supplier`;

CREATE TABLE `optprod_supplier` (
  `optprod_sup_id` int(11) NOT NULL AUTO_INCREMENT,
  `optprod_id` int(11) NOT NULL,
  `sup_id` int(11) NOT NULL,
  PRIMARY KEY (`optprod_sup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `optprod_supplier` */

/*Table structure for table `optshop_insurance` */

DROP TABLE IF EXISTS `optshop_insurance`;

CREATE TABLE `optshop_insurance` (
  `optshop_ins_id` int(11) NOT NULL AUTO_INCREMENT,
  `optshop_id` int(11) NOT NULL,
  `acc_ins_id` int(11) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  PRIMARY KEY (`optshop_ins_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

/*Data for the table `optshop_insurance` */

insert  into `optshop_insurance`(`optshop_ins_id`,`optshop_id`,`acc_ins_id`,`company_name`) values (46,28,6,'PAGIBIG'),(47,27,6,'PAGIBIG');

/*Table structure for table `optshop_supplier` */

DROP TABLE IF EXISTS `optshop_supplier`;

CREATE TABLE `optshop_supplier` (
  `optshop_sup_id` int(11) NOT NULL AUTO_INCREMENT,
  `optshop_id` int(11) NOT NULL,
  `sup_id` int(11) NOT NULL,
  `company_name` varchar(50) NOT NULL,
  PRIMARY KEY (`optshop_sup_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

/*Data for the table `optshop_supplier` */

insert  into `optshop_supplier`(`optshop_sup_id`,`optshop_id`,`sup_id`,`company_name`) values (26,27,8,'Silawan');

/*Table structure for table `owner` */

DROP TABLE IF EXISTS `owner`;

CREATE TABLE `owner` (
  `owner_id` int(11) NOT NULL AUTO_INCREMENT,
  `last_name` varchar(25) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `middle_name` varchar(25) DEFAULT NULL,
  `contactNo` varchar(20) NOT NULL,
  `gender` char(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `DOB` date NOT NULL,
  `email` varchar(50) NOT NULL,
  `pw` varchar(20) NOT NULL,
  `owner_img` varchar(255) DEFAULT NULL,
  `civil_status` varchar(10) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

/*Data for the table `owner` */

insert  into `owner`(`owner_id`,`last_name`,`first_name`,`middle_name`,`contactNo`,`gender`,`address`,`DOB`,`email`,`pw`,`owner_img`,`civil_status`,`status`) values (9,'Parrotina Jr.','Edilberto','','09253497907','Male','0324-B V. Ranudo st. Cebu City','1996-02-10','e.parrotina@gmail.com','259914568','system/images/owners/Fuko.jpg','Single','Active'),(10,'Arcubalino','Sleeping','Forest','2323a','Female','0324-B V. Ranudo st. Cebu Citya','2016-12-27','aa','aa','images/default.png','Singlea','Active'),(13,'','',NULL,'','','','0000-00-00','cc','cc',NULL,'','Active'),(14,'','',NULL,'','','','0000-00-00','arcubalino','resetwr30m',NULL,'','Active'),(15,'','',NULL,'','','','0000-00-00','rr','rr',NULL,'','Active'),(16,'','',NULL,'','','','0000-00-00','bb','bb',NULL,'','Active'),(17,'','',NULL,'','','','0000-00-00','bb','bb',NULL,'','Active'),(21,'','',NULL,'','','','0000-00-00','tt','tt',NULL,'','Active');

/*Table structure for table `patient` */

DROP TABLE IF EXISTS `patient`;

CREATE TABLE `patient` (
  `patient_id` int(11) NOT NULL AUTO_INCREMENT,
  `last_name` varchar(1000) NOT NULL,
  `first_name` varchar(1000) NOT NULL,
  `middle_name` varchar(1000) DEFAULT NULL,
  `contactNo` varchar(20) NOT NULL,
  `gender` char(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `DOB` date NOT NULL,
  `email` varchar(50) NOT NULL,
  `pw` varchar(20) NOT NULL,
  `patient_img` varchar(255) DEFAULT NULL,
  `civil_status` varchar(10) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`patient_id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

/*Data for the table `patient` */

insert  into `patient`(`patient_id`,`last_name`,`first_name`,`middle_name`,`contactNo`,`gender`,`address`,`DOB`,`email`,`pw`,`patient_img`,`civil_status`,`status`) values (36,'Magto','Claire','','09253497907','Female','0324-B V. Ranudo st. Cebu City','2009-02-03','taki@gmail.com','takitaki','','Single','Active'),(35,'Magta','Clarita','','09174578903','Female','Sanciangko St., Cebu City','1990-02-02','abc@gmail.com','abcdefg',NULL,'Single','Active'),(34,'Magto','Clairemji','','09339338046','Female','Andres Abellana St.','1986-02-12','clairemji@gmail.com','takitaki',NULL,'Single','Active'),(37,'bb','bb','bb','','Male','','2016-12-06','bb','bb',NULL,'Single','Active'),(38,'dd','dd','dd','','Female','','2016-12-06','dd','dd',NULL,'Single','Active');

/*Table structure for table `patient_history` */

DROP TABLE IF EXISTS `patient_history`;

CREATE TABLE `patient_history` (
  `pathis_id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(25) NOT NULL DEFAULT 'Pending',
  `patient_id` int(11) NOT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `date` datetime NOT NULL,
  `od_sphere` varchar(10) DEFAULT NULL,
  `od_cylinder` varchar(10) DEFAULT NULL,
  `od_axis` varchar(10) DEFAULT NULL,
  `od_rdg_add` varchar(10) DEFAULT NULL,
  `os_sphere` varchar(10) DEFAULT NULL,
  `os_cylinder` varchar(10) DEFAULT NULL,
  `os_axis` varchar(10) DEFAULT NULL,
  `os_rdg_add` varchar(10) DEFAULT NULL,
  `pat_complain` varchar(50) NOT NULL,
  `diagnosis` varchar(255) DEFAULT NULL,
  `prescription` varchar(50) NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `discount_id` int(11) DEFAULT NULL,
  `discounted_amount` double NOT NULL,
  `balance_insurance` double NOT NULL,
  `balance` double NOT NULL,
  PRIMARY KEY (`pathis_id`),
  KEY `patient_id` (`patient_id`),
  KEY `emp_id` (`emp_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

/*Data for the table `patient_history` */

insert  into `patient_history`(`pathis_id`,`status`,`patient_id`,`emp_id`,`date`,`od_sphere`,`od_cylinder`,`od_axis`,`od_rdg_add`,`os_sphere`,`os_cylinder`,`os_axis`,`os_rdg_add`,`pat_complain`,`diagnosis`,`prescription`,`amount`,`discount_id`,`discounted_amount`,`balance_insurance`,`balance`) values (22,'Pending',37,7,'2016-05-23 12:58:19','12','12','31','21','11','111','21','31','dladlk','near sighted and astigmatism','glasses and eye solution',300,0,300,300,100),(21,'Pending',37,7,'2016-05-23 12:44:37','10','20','30','40','1','2','3','4','asdasdlk','lkuelu','liueliia',3000,0,3000,3000,1000),(20,'Pending',37,7,'2016-05-23 12:43:44','10','20','30','40','1','2','3','4','asdasdlk','lkuelu','liueliia',300,0,300,300,300),(24,'Pending',35,8,'2017-01-09 03:18:08','bb','bb','bb','bb','bb','bb','bb','bb','bb','bb','bb',1000,NULL,200,4200,4200);

/*Table structure for table `payments` */

DROP TABLE IF EXISTS `payments`;

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `payment_date` datetime NOT NULL,
  `customer` varchar(25) DEFAULT NULL,
  `receiver_id` int(11) NOT NULL,
  `modeof_payment` varchar(25) NOT NULL,
  `cash_received` double NOT NULL,
  `change_amount` double NOT NULL,
  `tracking_number` varchar(50) DEFAULT NULL,
  `amount_paid` double NOT NULL,
  `remaining_balance` double NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

/*Data for the table `payments` */

insert  into `payments`(`payment_id`,`transaction_id`,`payment_date`,`customer`,`receiver_id`,`modeof_payment`,`cash_received`,`change_amount`,`tracking_number`,`amount_paid`,`remaining_balance`,`status`) values (25,21,'2016-05-23 12:45:35','34',0,'Cash',2000,0,'',2000,1000,'Active'),(26,22,'2016-05-23 12:58:44','34',7,'Cash',200,0,'',200,100,'Active'),(27,49,'2016-05-23 13:03:39','34',0,'Cash',3000,0,'',3000,0,'Active');

/*Table structure for table `prod_supplies` */

DROP TABLE IF EXISTS `prod_supplies`;

CREATE TABLE `prod_supplies` (
  `prod_sup_id` int(11) NOT NULL AUTO_INCREMENT,
  `optprod_id` int(11) DEFAULT NULL,
  `sup_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `dateSupplied` datetime NOT NULL,
  `qtyOrdered` int(11) NOT NULL,
  `qtyReceived` int(11) NOT NULL,
  `terms` int(11) NOT NULL,
  `notedBy` varchar(50) NOT NULL,
  `remarks` varchar(50) DEFAULT NULL,
  `price` decimal(9,2) NOT NULL,
  `totalAmt` decimal(11,2) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`prod_sup_id`),
  KEY `optprod_id` (`optprod_id`),
  KEY `sup_id` (`sup_id`),
  KEY `emp_id` (`emp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `prod_supplies` */

/*Table structure for table `promos` */

DROP TABLE IF EXISTS `promos`;

CREATE TABLE `promos` (
  `promo_id` int(11) NOT NULL AUTO_INCREMENT,
  `optprod_id` int(11) NOT NULL,
  `optshop_id` int(11) NOT NULL,
  `sdate` date NOT NULL,
  `edate` date NOT NULL,
  `promoAmt` decimal(9,2) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`promo_id`),
  KEY `optprod_id` (`optprod_id`),
  KEY `optshop_id` (`optshop_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `promos` */

insert  into `promos`(`promo_id`,`optprod_id`,`optshop_id`,`sdate`,`edate`,`promoAmt`,`status`) values (1,50,29,'2016-12-27','2016-12-31','500.00','Active');

/*Table structure for table `reservation` */

DROP TABLE IF EXISTS `reservation`;

CREATE TABLE `reservation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `optshop_id` int(11) NOT NULL,
  `optprod_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `sdate` date NOT NULL,
  `edate` date NOT NULL,
  `payment_status` varchar(10) NOT NULL DEFAULT 'Unpaid',
  `status` varchar(20) NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`id`),
  KEY `optprod_id` (`optprod_id`),
  KEY `patient_id` (`patient_id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

/*Data for the table `reservation` */

insert  into `reservation`(`id`,`optshop_id`,`optprod_id`,`qty`,`patient_id`,`sdate`,`edate`,`payment_status`,`status`) values (46,30,53,42,37,'0000-00-00','0000-00-00','Unpaid','Pending'),(47,29,50,21,37,'0000-00-00','0000-00-00','Unpaid','Pending'),(49,28,47,54,37,'2017-01-28','0000-00-00','Unpaid','Pending'),(50,27,48,2,37,'2017-01-28','0000-00-00','Unpaid','Pending'),(51,29,52,2,37,'2017-01-28','0000-00-00','Unpaid','Pending');

/*Table structure for table `sales` */

DROP TABLE IF EXISTS `sales`;

CREATE TABLE `sales` (
  `sales_id` int(11) NOT NULL AUTO_INCREMENT,
  `optshop_id` int(11) NOT NULL,
  `customer` varchar(50) DEFAULT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `datetime` datetime NOT NULL,
  `total` double NOT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `discounted_amount` double NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`sales_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;

/*Data for the table `sales` */

insert  into `sales`(`sales_id`,`optshop_id`,`customer`,`emp_id`,`datetime`,`total`,`discount_id`,`discounted_amount`,`status`) values (49,27,'34',7,'2016-05-23 13:00:10',3000,0,3000,'paid');

/*Table structure for table `sales_products` */

DROP TABLE IF EXISTS `sales_products`;

CREATE TABLE `sales_products` (
  `sales_id` int(11) DEFAULT NULL,
  `optprod_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `sales_products` */

insert  into `sales_products`(`sales_id`,`optprod_id`,`qty`) values (1,1,2),(1,10,1),(2,1,1),(3,1,1),(4,9,1),(5,1,1),(6,3,1),(7,1,2),(7,4,1),(7,5,1),(8,2,1),(9,5,1),(10,2,1),(10,1,40000000),(11,1,21),(12,1,1),(13,3,1),(14,1,1),(15,1,1),(16,1,1),(17,4,1),(18,4,1),(19,3,2),(19,4,1),(19,5,2),(20,11,1),(21,4,2),(21,6,1),(24,9,1),(32,9,1),(33,1,1),(34,5,1),(35,1,1),(36,12,1),(37,12,1),(38,34,1),(38,8,1),(39,8,1),(41,34,3),(42,35,1),(43,35,1),(44,8,1),(45,35,1),(45,8,1),(46,13,1),(47,13,1),(47,33,2),(47,1,1),(48,13,1),(49,47,2),(1,1,2),(1,10,1),(2,1,1),(3,1,1),(4,9,1),(5,1,1),(6,3,1),(7,1,2),(7,4,1),(7,5,1),(8,2,1),(9,5,1),(10,2,1),(10,1,40000000),(11,1,21),(12,1,1),(13,3,1),(14,1,1),(15,1,1),(16,1,1),(17,4,1),(18,4,1),(19,3,2),(19,4,1),(19,5,2),(20,11,1),(21,4,2),(21,6,1),(24,9,1),(32,9,1),(33,1,1),(34,5,1),(35,1,1),(36,12,1),(37,12,1),(38,34,1),(38,8,1),(39,8,1),(41,34,3),(42,35,1),(43,35,1),(44,8,1),(45,35,1),(45,8,1),(46,13,1),(47,13,1),(47,33,2),(47,1,1),(48,13,1),(49,47,2);

/*Table structure for table `services` */

DROP TABLE IF EXISTS `services`;

CREATE TABLE `services` (
  `services_id` int(11) NOT NULL AUTO_INCREMENT,
  `optshop_id` int(11) NOT NULL,
  `service_name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`services_id`),
  KEY `optshop_id` (`optshop_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

/*Data for the table `services` */

insert  into `services`(`services_id`,`optshop_id`,`service_name`,`description`,`status`) values (21,29,'Eye Examination','Examination of the Eye ','Active'),(23,29,'Hilot','Cgeg Pahilot','Active'),(24,46,'Extra Service','just pay extra','Active'),(28,29,'aa','xxxaaa','Active');

/*Table structure for table `subs_plan` */

DROP TABLE IF EXISTS `subs_plan`;

CREATE TABLE `subs_plan` (
  `subs_plan_id` int(11) NOT NULL AUTO_INCREMENT,
  `term` int(11) NOT NULL COMMENT 'in months',
  `amount` decimal(9,2) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`subs_plan_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `subs_plan` */

insert  into `subs_plan`(`subs_plan_id`,`term`,`amount`,`status`) values (2,1,'300.00','Active');

/*Table structure for table `subscription` */

DROP TABLE IF EXISTS `subscription`;

CREATE TABLE `subscription` (
  `subs_id` int(11) NOT NULL AUTO_INCREMENT,
  `optshop_id` int(11) NOT NULL,
  `subs_plan_id` int(11) DEFAULT NULL,
  `sdate` date NOT NULL,
  `edate` date NOT NULL,
  `paymentAmt` double(9,2) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`subs_id`),
  KEY `optshop_id` (`optshop_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

/*Data for the table `subscription` */

insert  into `subscription`(`subs_id`,`optshop_id`,`subs_plan_id`,`sdate`,`edate`,`paymentAmt`,`status`) values (16,29,2,'2016-12-27','2017-12-27',300.00,'Active');

/*Table structure for table `subscription_payments` */

DROP TABLE IF EXISTS `subscription_payments`;

CREATE TABLE `subscription_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_id` int(255) DEFAULT NULL,
  `payment` varchar(1000) DEFAULT NULL,
  `remarks` varchar(1000) DEFAULT NULL,
  `status` int(255) DEFAULT '0',
  `date_paid` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

/*Data for the table `subscription_payments` */

insert  into `subscription_payments`(`id`,`shop_id`,`payment`,`remarks`,`status`,`date_paid`,`due_date`) values (1,28,'0','Trial',1,'2017-01-23','2017-03-23'),(2,27,'0','Trial',1,'2017-01-23','2017-03-23'),(3,29,'0','Trial',1,'2017-01-23','2017-03-23'),(4,30,'0','Trial',1,'2017-01-23','2017-03-23'),(5,39,'0','Trial',1,'2017-01-23','2017-03-23'),(6,41,'0','Trial',1,'2017-01-23','2017-03-23'),(7,42,'0','Trial',1,'2017-01-23','2017-03-23'),(8,43,'0','Trial',1,'2017-01-23','2017-03-23'),(9,44,'0','Trial',1,'2017-01-23','2017-03-23'),(10,45,'0','Trial',1,'2017-01-23','2017-03-23'),(11,46,'0','Trial',1,'2017-01-23','2017-03-23'),(12,49,'0','Trial',1,'2017-01-24','2017-03-24'),(13,50,'0','Trial',1,'2017-01-24','2017-03-24'),(14,50,'500','For Payment',0,NULL,'2017-02-24'),(19,53,'0','Trial',1,'2017-01-24','2017-03-24'),(20,53,'500','For Payment',0,NULL,'2017-04-24');

/*Table structure for table `suppliers` */

DROP TABLE IF EXISTS `suppliers`;

CREATE TABLE `suppliers` (
  `sup_id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) NOT NULL,
  `company_name` varchar(50) NOT NULL,
  `contact_person` varchar(50) NOT NULL,
  `contactNo` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `sup_image` varchar(255) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`sup_id`),
  KEY `optshop_id` (`owner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `suppliers` */

insert  into `suppliers`(`sup_id`,`owner_id`,`company_name`,`contact_person`,`contactNo`,`email`,`address`,`sup_image`,`status`) values (8,10,'Jonathan Paul','Angel Marie Senoc','09231431959','angel_marie@gmail.com','Sanciangko St., Cebu City','system/images/suppliers/jonathan_paul.png','Active'),(9,10,'Leep Cooper','Cooper Lee','09090909090','cooper_lee.com','Buwad City, Dried City','system/images/suppliers/lee_cooper.png','Inactive'),(10,10,'xx','xx','xx','xx','xx','system/images/suppliers/161130041645_B160wG-IgAE97kJ.jpg','Active'),(11,10,'bbb','bb','bb','bb','bb','system/images/suppliers/161130042214_homer-glasses.png','Active');

/*Table structure for table `type` */

DROP TABLE IF EXISTS `type`;

CREATE TABLE `type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `type` */

insert  into `type`(`type_id`,`description`,`name`) values (1,'for eyes stupid','Eye Glass'),(2,NULL,'Contact Lens'),(3,'Eye glass lens','Lens'),(4,NULL,'Frame'),(5,NULL,'Solution'),(6,NULL,'Sun Glass'),(7,'Accessories','Accessories');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
