Priority List:
	1. Subscription Management (1)
	2. Account -> Employee (1)
	3. Optical Shop Management (1)
	4. Product and Services -> Suppliers (2)
	5. Reservation -> Appointment (2)
	6. Payment -> Insurance (2)
	7. Notification (3)
	8. Reports (3)
	9. Job Orders (3)


List of Modules:
1. Subscription Management
2. Notification Management
3. Reports Management
4. Payment Management
5. Reservation Management
6. Account Management
7. Product Management
8. Services Management
9. Optical Shop Management
10. Employee Management
11. Insurance Management
12. Supplier Management
13. Appointment Management
14. Job Order  Management

Different Notification:
	- View Subscription Notice	
	- Add Promo Notification	
	- View Promo Notification	
	- View Reservation Notice	
	- Add Payment Notice	
	- View Payment Notice	


Different Reports:
	- View Registered Patient	
	- View Registered Owner	
	- View Subscription 	
	- View Product Inventory	
	- View Optical Shops	

Different User Type:
	- Patient
	- Optical Shop Owner
	- blinkrr Admin
	- Optical Shop Staff
	- Optometrist/ Optician

================================ User's Priviledges and Access: ================================

Patient:(0)				
	Accounts: 
		- Create Account	
		- View Account	
		- Update Account	
		- Deactivate Account	
		- Login/Logout	

	Employees: 
		- View Employee Details	

	Reservations: 
		- Add Reservation 	
		- View Reservation	
		- Cancel Reservation	

	Products: 
		- View Product	

	Services: 
		- View Service	

	Insurances:
		- View Insurance Details	
 
	Appointments: 
		- Create Appointment
		- View Appointment

	Optical Shop Management:
		- View Shop Information	
		- View Patient History	
		- Locate Optical Shop	

	Notification Management:
		- View Promo Notification	
		- View Reservation Notice	
		- View Payment Notice	

================================================================================================
Optical Shop Owner:	(1)			
	Accounts: 
		- Create Account	
		- View Account	
		- Update Account	
		- Deactivate Account	
		- Login/Logout	

	Employees: 
		- Add Employees	
		- Add Employees	
		- Update Employee Details	
		- Delete Employee	

	Subscriptions: 
		- View Subscription	
		- Create Subscription	

	Reports: 
		- View Product Inventory	
		- View Optical Shops	

	Payments: 
		- Add Payment	
		- View Payment	

	Reservations: 
		- Add Reservation 	
		- View Reservation	

	Products:
		- Add Product	
		- View Product	
		- Update Product	
		- Delete Product	
 
	Services: 
		- Add Service	
		- View Service	
		- Update Service	
		- Delete Service	

	Insurances: 
		- Add Insurance Company	
		- View Insurance Details	
		- Update Insurance	
		- Deactivate Insurance	
		- Deactivate Insurance	
		- Add Patient Insured	

	Suppliers:
		- Add Supplier
		- View Supplier
		- Update Supplier Information
		- Delete Supplier
 
	Appointments:
		- View Appointment
		- Respond to Appointment
 
	Job Orders: 
		- Add Job Order
		- View Job Order

	Optical Shop Management:
		- Add Shop Information	
		- View Shop Information	
		- Update Shop Information	
		- View Patient History	


	Notification Management:
		- View Subscription Notice	
		- Add Promo Notification	
		- View Promo Notification	
		- View Reservation Notice	
		- Add Payment Notice	
		- View Payment Notice	


================================================================================================

Blinkrr Admin: (2)
	
	Accounts: 
		- Create Account	
		- View Account	
		- Update Account	
		- Deactivate Account	
		- Login/Logout	

	Subscriptions: 
		- View Subscription	
		- Update Subscription	
		- Deactivate Subscription	

	Reports: 
		- View Registered Patient	
		- View Registered Owner	
		- View Subscription 	
		- View Product Inventory	
		- View Optical Shops	

	Payments: 
		- View Payment	

	Optical Shop Management:
		- View Shop Information	

================================================================================================

Optical Shop Staff:	(3)

	Accounts: 
		- View Account	
		- Login/Logout	

	Employees: 
		- Add Employees	

	Reports: 
		- View Product Inventory	

	Payments: 
		- Add Payment	
		- View Payment	

	Reservations: 
		- Add Reservation 	
		- View Reservation	

	Products: 
		- Add Product	
		- View Product	
		- Update Product	
		- Delete Product	

	Services: 
		- Add Service	
		- View Service	
		- Update Service	
		- Delete Service	

	Insurances: 
		- View Insurance Details	

	Suppliers: 
		- View Supplier

	Appointments: 
		- View Appointment
		- Respond to Appointment

	Job Orders: 
		- Add Job Order
		- View Job Order

	Optical Shop Management:
		- View Shop Information	
		- View Patient History	

	Notification Management:
		- Add Promo Notification	
		- View Promo Notification	
		- View Reservation Notice	
		- Add Payment Notice	
		- View Payment Notice	


================================================================================================

Optometrist/ Optician:	(4)

	Accounts: 
		- View Account	
		- Login/Logout	

	Employees: 
		- Add Employees	

	Products: 
		- View Product	

	Services: 
		- View Service	

	Insurances: 
		- View Insurance Details	

	Appointments: 
		- View Appointment

	Job Orders: 
		- Add Job Order
		- View Job Order

	Optical Shop Management:
		- View Shop Information	
		- View Patient History	























































































