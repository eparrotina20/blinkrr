$(function(){
var dateToday = new Date(); 
  notifications();
})

function notifications(){

  $.ajax({
    url: getBaseURL()+"Notifications/notice_only",
    type: "POST",
    success:function(data){
      data = $.parseJSON(data);
      if(data.length > 0){
        $("#notice_here").html("Notifications <strong>("+data.length+")</strong>");
      }

    }

  });

}

function time_list(action){
  //shop_from
    $("#"+action+"_hours").append('<option value="24">12:00AM</option>\n\
    <option value="01">1:00AM</option>\n\
    <option value="02">2:00AM</option>\n\
    <option value="03">3:00AM</option>\n\
    <option value="04">4:00AM</option>\n\
    <option value="05">5:00AM</option>\n\
    <option value="06">6:00AM</option>\n\
    <option value="07">7:00AM</option>\n\
    <option value="08">8:00AM</option>\n\
    <option value="09">9:00AM</option>\n\
    <option value="10">10:00AM</option>\n\
    <option value="11">11:00AM</option>\n\
    <option value="12">12:00PM</option>\n\
    <option value="13">1:00PM</option>\n\
    <option value="14">2:00PM</option>\n\
    <option value="15">3:00PM</option>\n\
    <option value="16">4:00PM</option>\n\
    <option value="17">5:00PM</option>\n\
    <option value="18">6:00PM</option>\n\
    <option value="19">7:00PM</option>\n\
    <option value="20">8:00PM</option>\n\
    <option value="21">9:00PM</option>\n\
    <option value="22">10:00PM</option>\n\
    <option value="23">11:00PM</option>');

    for(var i=0; i < 59; i++){
      $("#"+action+"_minutes").append('<option value="'+i+'">'+i+'</option>');  
    }
    
}


//============================================= DEFAULT CONFIGURATION ===========================
function datetime_picker(){
    $('#app_time').timepicker();

    $('#timepicker5').timepicker({
        template: false,
        showInputs: false,
        minuteStep: 5
    });

    $('#datepairExample .date').datepicker({
      'format': 'yyyy-m-d',
      'autoclose': true,
       minDate: 0
    });

    $('.pick_date').datepicker({
      'format': 'yyyy-m-d',
      'autoclose': true,
       minDate: 0
    });
}


function up_note(message){
  $("#up_note").html(message).fadeIn('slow').delay(3000).fadeOut('slow');
}


function close_modal(){
  $("#close_modal").click();
}

function pre_blocker(action){

  switch(action){
    case "on":
      $(".pre_blocker").show();
    break;
    
    case "off":
      $(".pre_blocker").hide();
    break;
  }

}

function addStylePath(path){        
    var link  = document.createElement('link');
    link.rel  = 'stylesheet';
    link.type = 'text/css';
    link.href = getBaseURL()+path;
    link.media = 'all';
    document.getElementsByTagName('head')[0].appendChild(link); 
}

function addScriptPath(path){

    var scr=document.createElement('script');
    scr.type = 'text/javascript';
    scr.src = getBaseURL()+path;
    document.getElementsByTagName('head')[0].appendChild(scr);  
}

function getBaseURL() {
    var origin = window.location.origin+'/';
    var pathArray = window.location.pathname.split( '/' );
    var base_url = '';
    base_url = origin+pathArray[1];
    // return '';
    return base_url+'/';
}

function getURIstring(){
    var pathArray = window.location.pathname.split( '/' ),
        uri = '';
    pathArray.splice(0,2);
    if( pathArray.length > 0 ){
        uri = pathArray.join('/');
    }
    return uri;
}

function getFolder( pathname ){
    switch( pathname ){
        case 'base': id = 1; break;
        case 'sub': id = 3; break;
        default: id = 2; break;
    }

    // check if error
    var error = ( (id == 2 && pathname != 'main') && pathname == '' ) ? true:false;
    if( error )
        return false;
    // end check error

    var origin = window.location.origin+'/';
    var pathArray = window.location.pathname.split( '/' );
    
    return pathArray[id];
}



function decimalonly(e, decimal) {
var key;
var keychar;

if (window.event) {
   key = window.event.keyCode;
}
else if (e) {
   key = e.which;
}
else {
   return true;
}
keychar = String.fromCharCode(key);

if ((key==null) || (key==0) || (key==8) ||  (key==9) || (key==13) || (key==27) ) {
   return true;
}
else if ((("0123456789").indexOf(keychar) > -1)) {
   return true;
}
else if (decimal && (keychar == ".")) { 
  return true;
}
else
   return false;
}






function letra(e, decimal) {

var key;
var keychar;

if (window.event) {
   key = window.event.keyCode;
}
else if (e) {
   key = e.which;
}
else {
   return true;
}
keychar = String.fromCharCode(key);

if ((key==null) || (key==0) || (key==8) ||  (key==9) || (key==13) || (key==27) ) {
   return true;
}
else if ((("ABCDEFGHIJKLMNÑOPQRSTUVWXYZ abcdefghijklmnñopqrstuvwxyz").indexOf(keychar) > -1)) {
   return true;
}
else if (decimal && (keychar == ".")) { 
  return true;
}
else
   return false;
}




 


