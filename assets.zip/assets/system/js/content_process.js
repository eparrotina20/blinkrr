$(function(){
	process_product('reorder','');
})

function job_process(action,id){

	switch(action){

		case "get_discount":
			$promo = $("#in_promo").val();
			if($promo == ""){
				var res2 = 0;
			}else{

				$discount = $("#in_promo option[value='"+$promo+"']").text();
				var res1 = $discount.replace("Less ", ""); 
				var res2 = res1.replace(".00", ""); 

			}
			$amount = $("#in_amount").val();

			$total = parseInt($amount) - parseInt(res2);

			$("#in_total").val($total);
			$("#in_discount").val(parseInt(res2)).attr('disabled',true);

		break;

		case "promos":
			$(".append_promo").remove();
			$.ajax({
				url: getBaseURL()+"Promos/lists",
				type: "POST",
				data:{'product_id':id},
				success:function(data){
					data = $.parseJSON(data);
					if(data!=""){
						$("#in_promo").attr('disabled',false);
						for(var i=0; i < data.length; i++){
							$("#in_promo").append('<option class="append_promo" value="'+data[i]['promo_id']+'" selected="selected">Less '+data[i]['promoAmt']+'</option>');
						}

						$("#in_promo").prepend("<option class='append_promo' value=''>Select Promo:</option>")
						$("#in_discount").val('').attr('disabled',false);
					}else{
						$("#in_discount").val(0).attr('disabled',true);
						$("#in_promo").append('<option class="append_promo" value="0" selected="selected">None</option>').attr('disabled',true);
					}
				}
			})

		break;

		case "find_shop":
			$emp_id = $("#emp_id").val();
			$.ajax({
				url: getBaseURL()+"Employees/employee_list",
				type: "POST", 
				data:{'from_job':'from_job','emp_id':$emp_id},
				success:function(data){
					data = $.parseJSON(data);
					$("#in_optshop").val(data[0]['optshop_id'])
					console.log(data);
				}
			})
		break;

		case "save":

			$in_optshop = $("#in_optshop").val();
			$patient_id = $("#patient_id").val();
			$emp_id = $("#emp_id").val();
			$due_date = $("#due_date").val();
			$od = $("#od").val();
			$os = $("#os").val();
			$optprod_id = $("#optprod_id").val();
			$job_order_id = $("#job_order_id").val();
			$in_diagnosis = $("#in_diagnosis").val();
			$in_prescription = $("#in_prescription").val();
			$in_amount = $("#in_amount").val();
			$in_discount = $("#in_discount").val();
			$in_total = $("#in_total").val();
			$in_remarks = $("#in_remarks").val();
			$in_deposit = $("#in_deposit").val();
			$in_promo = $("#in_promo").val();
			$job_attr = {
				in_deposit: $in_deposit,
				in_optshop: $in_optshop,
				patient_id: $patient_id,
				emp_id: $emp_id,
				due_date: $due_date,
				od: $od,
				os: $os,
				optprod_id: $optprod_id,
				in_diagnosis: $in_diagnosis,
				in_prescription: $in_prescription,
				in_amount: $in_amount,
				in_discount: $in_discount,
				in_promo: $in_promo,
				in_total: $in_total,
				in_remarks: $in_remarks,
				job_order_id:$job_order_id

			};
			pre_blocker('on');
			$.ajax({
				url: getBaseURL()+"Job_orders/process",
				type: "POST",
				data:{'action':action,'job_attr':$job_attr},
				success:function(data){
					if(data == "success"){
						location.reload();
						up_note('Successfully save job order');
					}else{
						pre_blocker('off');
						up_note('Error has been encountered while trying to save job order');
					}
				},error:function(data){
						pre_blocker('off');
						up_note('Error has been encountered while trying to save job order');
				}
			})

		break;

		case "get_price":
			$prod_id = $("#optprod_id").val();
			pre_blocker('on');
			$.ajax({
				url: getBaseURL()+"Products/lists",
				type: "POST",
				data:{'product_id':$prod_id},
				success:function(data){
					data = $.parseJSON(data);
					$price = data[0]['price'];
					$("#in_amount").val($price).attr('disabled',true);
					job_process('promos',$prod_id);
					pre_blocker('off');
				}

			})

		break;

		case "create":

			$("#job_ul li").removeAttr('class');
			$("#create").attr('class','active');	
			$("#job_list").hide();
			$("#create_job").show();

			$("#page_title").text('Create Job Order');
		break;

		case "sold":
			pre_blocker('on');
			$.ajax({
				url: getBaseURL()+"Job_orders/process",
				type: "POST",
				data:{'action':action,'job_id':id},
				success:function(data){
					$("#inline_"+id).remove();
					pre_blocker('off');
				}
			});

		break;

		case "remove":
			pre_blocker('on');
			$.ajax({
				url: getBaseURL()+"Job_orders/process",
				type: "POST",
				data:{'action':action,'job_id':id},
				success:function(data){
					$("#inline_"+id).remove();
					pre_blocker('off');
				}
			});
		break;

		case "update":


					$(".modal-title").text("Patient's History");
					$(".modal-body").html('<div class="container"><div class="row"><strong> &nbsp;&nbsp;Date: &nbsp;&nbsp;</strong>'+data[0]['date']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OD Sphere: &nbsp;&nbsp;</strong>'+data[0]['od_sphere']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OD Cylinder: &nbsp;&nbsp;</strong>'+data[0]['od_cylinder']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OD Axis: &nbsp;&nbsp;</strong>'+data[0]['od_axis']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OD RDG ADD: &nbsp;&nbsp;</strong>'+data[0]['od_rdg_add']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OS Sphere: &nbsp;&nbsp;</strong>'+data[0]['os_sphere']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OS Cylinder: &nbsp;&nbsp;</strong>'+data[0]['os_cylinder']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OS Axis: &nbsp;&nbsp;</strong>'+data[0]['os_axis']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OS RDG ADD: &nbsp;&nbsp;</strong>'+data[0]['os_rdg_add']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Complain: &nbsp;&nbsp;</strong>'+data[0]['pat_complain']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Diagnosis: &nbsp;&nbsp;</strong>'+data[0]['diagnosis']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Prescription: &nbsp;&nbsp;</strong>'+data[0]['prescription']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Amount: &nbsp;&nbsp;</strong>'+data[0]['amount']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Discount: &nbsp;&nbsp;</strong>'+data[0]['discounted_amount']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Insurance: &nbsp;&nbsp;</strong>'+data[0]['balance_insurance']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Balance: &nbsp;&nbsp;</strong>'+data[0]['balance']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Status : &nbsp;&nbsp;</strong>'+data[0]['status']+'</div><br></div><br>');	

						$("#g_modal").modal();

		break;

	}//end of switch

}

function report_process(action,id){
	switch(action){

		case "report_list":
			$(".module_list").hide();

			$("#report_ul li").removeAttr('class');
			$.ajax({
				url: getBaseURL()+"Reports/lists",
				type: "POST",
				data:{'action':id},
				success:function(data){

					data = $.parseJSON(data);
					switch(id){
						case "patients":
						$("#patient_list").html('');

							for(var i=0; i < data.length; i++){
								$("#patient_list").append('<tr>\n\
									<td>'+data[i]['last_name']+','+data[i]['first_name']+'</td>\n\
									<td>'+data[i]['contactNo']+'</td>\n\
									<td>'+data[i]['gender']+'</td>\n\
									<td>'+data[i]['civil_status']+'</td>\n\
									<td>'+data[i]['DOB']+'</td>\n\
									<td>'+data[i]['address']+'</td>\n\
								</tr>');
							}

							$("#module_title").text('Patient List');
							$("#patients_here").show();
						break;

						case "owners":
						$("#owner_list").html('');
							for(var i=0; i < data.length; i++){
								$("#owner_list").append('<tr>\n\
									<td>'+data[i]['last_name']+','+data[i]['first_name']+'</td>\n\
									<td>'+data[i]['contactNo']+'</td>\n\
									<td>'+data[i]['gender']+'</td>\n\
									<td>'+data[i]['civil_status']+'</td>\n\
									<td>'+data[i]['DOB']+'</td>\n\
									<td>'+data[i]['address']+'</td>\n\
								</tr>');
							}

							$("#module_title").text('Owner List');
							$("#owners_here").show();
						break;

						case "subscriptions":
							$("#sub_list").html('');

							for(var i=0; i < data.length; i++){
								$("#sub_list").append('<tr>\n\
									<td>'+data[i]['optshop_name']+'</td>\n\
									<td>'+data[i]['term']+'</td>\n\
									<td>'+data[i]['sdate']+'</td>\n\
									<td>'+data[i]['edate']+'</td>\n\
									<td>'+data[i]['paymentAmt']+'</td>\n\
									<td>'+data[i]['status']+'</td>\n\
								</tr>');
							}
						
							$("#module_title").text('Subscription List');
							$("#subscriptions_here").show();
						break;

						case "inventory":
						//$("#inventory_here").append('<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">\n\
								// 	<div class="panel price panel-blue">\n\
								// 		<div align="center"><img src="'+getBaseURL()+'assets/'+data[i]['optprod_img']+'" style="width:100px;height:100px;"></div>\n\
								// 		<div class="panel-heading arrow_box text-center">\n\
								// 			<h3>'+data[i]['name']+'</h3>\n\
								// 		</div>\n\
								// 		<div class="panel-body text-center">\n\
								// 			<p class="lead" style="font-size:25px"><strong>'+data[i]['qty']+'</strong></p>\n\
								// 		</div>\n\
								// 	</div>\n\
								// </div>');
							$("#insert_inventory_here").html('');
							for(var i=0; i < data.length; i++){
								$("#insert_inventory_here").append('<tr><td>'+data[i]['name']+'</td><td>'+data[i]['model']+'</td><td>'+data[i]['brand']+'</td><td>'+data[i]['qty']+'</td><td>'+data[i]['reorder']+'</td><td>'+data[i]['price']+'</td></tr>');

							}
							$("#module_title").text('List of Inventory');
							$("#inventory_here").show();
						break;

						case "shops":
							$("#shop_list").html('');
							for(var i=0; i < data.length; i++){
								$("#shop_list").append('<tr>\n\
									<td>'+data[i]['optshop_name']+'</td>\n\
									<td>'+data[i]['optshop_add']+'</td>\n\
									<td>'+data[i]['optshop_tel']+'</td>\n\
									<td>'+data[i]['optshop_lat']+'</td>\n\
									<td>'+data[i]['optshop_long']+'</td>\n\
									<td><a href="http://www.gps-coordinates.net/" target="_blank">Check Map</a></td>\n\
								</tr>');
							}

							$("#module_title").text('List of Shops');
							$("#shops_here").show();
						break;

					}//end of switch

						$("#"+id).attr('class','active');
				}//end of success call back

			})


		break;
	}
}




function notification_process(action,id){
	switch(action){
		case "mark_as_read":
			pre_blocker('on');
			$.ajax({
				url: getBaseURL()+"Notifications/process",
				type: "POST",
				data:{'action':action,'id':id},
				success:function(data){
					$("#status_here_"+id).html('Read');
					$("#notice_here_"+id).html('<button class="btn btn-primary" onclick="notification_process(\'mark_as_read\',\''+id+'\')"><i class="fa fa-check"></i> Mark as Unread</button>');
					location.reload();
					pre_blocker('off');

				}
			});
		break;

		case "mark_as_unread":
					pre_blocker('on');
			$.ajax({
				url: getBaseURL()+"Notifications/process",
				type: "POST",
				data:{'action':action,'id':id},
				success:function(data){
					$("#status_here_"+id).html('Unread');
					$("#notice_here_"+id).html('<button class="btn btn-success" onclick="notification_process(\'mark_as_read\',\''+id+'\')"><i class="fa fa-check"></i> Mark as Read</button>');
					 notifications();
					pre_blocker('off');
				}
			});
		break;
	}
}


function insurance_process(action,id){

	switch(action){

		case "count_balance":
			$in_discount = $("#running_balance").val();
			$in_insurance = $("#in_insurance").val();

			$balance = parseInt($in_insurance) - parseInt($in_discount);

			$("#in_balance").val($balance);
		break;

		case "minus_discount":
			$in_discount = $("#in_discount").val();
			$in_insurance = $("#in_amount").val();

			$balance = parseInt($in_insurance) - parseInt($in_discount);

			$("#running_balance").val($balance);
		break;

		case "save_insurance":
			pre_blocker('on');
			$in_company = $("#in_company").val();
			$in_authorized = $("#in_authorized").val();
			$in_date = $("#in_date").val();
			$in_agreement = $("#in_agreement").val();
			$in_covered_amount = $("#in_covered_amount").val();
			$in_patient = $("#in_patient").val();
			$in_employee = $("#in_employee").val();
			$in_date = $("#in_date").val();
			$in_od_sphere = $("#in_od_sphere").val();
			$id_od_cylinder = $("#id_od_cylinder").val();
			$in_od_axis = $("#in_od_axis").val();
			$in_rdg_add = $("#in_rdg_add").val();
			$in_os_sphere = $("#in_os_sphere").val();
			$in_os_cylinder = $("#in_os_cylinder").val();
			$in_os_axis = $("#in_os_axis").val();
			$in_os_rdg_add = $("#in_os_rdg_add").val();
			$in_complain = $("#in_complain").val();
			$in_diagnosis = $("#in_diagnosis").val();
			$in_prescription = $("#in_prescription").val();
			$in_amount = $("#in_amount").val();
			$in_discount = $("#in_discount").val();
			$in_insurance = $("#in_insurance").val();
			$in_balance = $("#in_balance").val();

			$.ajax({
				url: getBaseURL()+"Insurances/company_process",
				type: "POST",
				data:{'action':action,'in_company':$in_company,'in_date':$in_date,'in_agreement':$in_agreement,'in_covered_amount':$in_covered_amount,'in_patient':$in_patient,'in_employee':$in_employee,'in_date':$in_date,'in_od_sphere':$in_od_sphere,'id_od_cylinder':$id_od_cylinder,'in_od_axis':$in_od_axis,'in_rdg_add':$in_rdg_add,'in_os_sphere':$in_os_sphere,'in_os_cylinder':$in_os_cylinder,'in_os_axis':$in_os_axis,'in_os_rdg_add':$in_os_rdg_add,'in_complain':$in_complain,'in_diagnosis':$in_diagnosis,'in_prescription':$in_prescription,'in_amount':$in_amount,'in_discount':$in_discount,'in_insurance':$in_insurance,'in_balance':$in_balance,'in_authorized':$in_authorized},
				success:function(data){
					if(data == "success"){
						location.reload();
					}else{
						up_note('Error while trying to save insurance and patient history');
						pre_blocker('off');
					}
				},error:function(data){
						up_note('Error while trying to save insurance and patient history');
						pre_blocker('off');
				}	

			})

		break;

		case "patient_history":

			$(".modal-title").text("Patient's History");
			$.ajax({
				url: getBaseURL()+"Patient_history/lists",
				type: "POST",
				dat:{'pathis_id':id},
				success:function(data){
						data = $.parseJSON(data);

						$(".modal-body").html('<div class="container"><div class="row"><strong> &nbsp;&nbsp;Date: &nbsp;&nbsp;</strong>'+data[0]['date']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OD Sphere: &nbsp;&nbsp;</strong>'+data[0]['od_sphere']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OD Cylinder: &nbsp;&nbsp;</strong>'+data[0]['od_cylinder']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OD Axis: &nbsp;&nbsp;</strong>'+data[0]['od_axis']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OD RDG ADD: &nbsp;&nbsp;</strong>'+data[0]['od_rdg_add']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OS Sphere: &nbsp;&nbsp;</strong>'+data[0]['os_sphere']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OS Cylinder: &nbsp;&nbsp;</strong>'+data[0]['os_cylinder']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OS Axis: &nbsp;&nbsp;</strong>'+data[0]['os_axis']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;OS RDG ADD: &nbsp;&nbsp;</strong>'+data[0]['os_rdg_add']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Complain: &nbsp;&nbsp;</strong>'+data[0]['pat_complain']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Diagnosis: &nbsp;&nbsp;</strong>'+data[0]['diagnosis']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Prescription: &nbsp;&nbsp;</strong>'+data[0]['prescription']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Amount: &nbsp;&nbsp;</strong>'+data[0]['amount']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Discount: &nbsp;&nbsp;</strong>'+data[0]['discounted_amount']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Insurance: &nbsp;&nbsp;</strong>'+data[0]['balance_insurance']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Balance: &nbsp;&nbsp;</strong>'+data[0]['balance']+'</div><br>\n\
	                    <div class="row"><strong> &nbsp;&nbsp;Status : &nbsp;&nbsp;</strong>'+data[0]['status']+'</div><br></div><br>');	

						$("#g_modal").modal();
				}

			});




		break;


		case "company":
			$(".appended_company").remove();
			pre_blocker('on');

			$.ajax({
				url: getBaseURL()+"Insurances/company_list",
				type: "POST",
				success:function(data){
					data = $.parseJSON(data);

					for(var i=0; i < data.length; i++){

						$("#company_here").append('<tr class="appended_company" id="company_'+data[i]['acc_ins_id']+'">\n\
								<td>'+data[i]['company_name']+'</td>\n\
								<td>'+data[i]['address']+'</td>\n\
								<td>'+data[i]['contact']+'</td>\n\
								<td><button class="btn btn-danger btn-sm" onclick="insurance_process(\'remove_company\',\''+data[i]['acc_ins_id']+'\')"><i class="fa fa-remove"></i> Remove</button></td>\n\
							</tr>');
					}

					pre_blocker('off');
				}
			});

		break;

		case "company_save":
			pre_blocker('on');
			$company_id = $("#company_id").val();
			$company_name = $("#company_name").val();
			$company_address = $("#company_address").val();
			$company_contact = $("#company_contact").val();

			$.ajax({

				url: getBaseURL()+"Insurances/company_process",
				type: "POST",
				data:{'action':action,'company_id':$company_id,'company_name':$company_name,'company_address':$company_address,'company_contact':$company_contact},
				success:function(data){
					console.log(data);
					if(data == "success"){
						$message = 'Successfully saved company';
						$("#company_contact,#company_id,#company_name,#company_address").val('');
						insurance_process('company','')
					}//end of if
					else{
							$message = "Error encountered while trying to save company";
					}
								pre_blocker('off');
								up_note($message);
				},//end of success callback
				error:function(data){
					pre_blocker('off');
					up_note("Error encountered while trying to save company");
				}
			});

		break;

		case "remove_company":

				if(confirm('Are you sure to remove this company?')){
					pre_blocker('on');
					$.ajax({
						url: getBaseURL()+"Insurances/company_process",
						type: "POST",
						data:{'action':action,'company_id':id},
						success:function(data){
							
							if(data == "success"){
								$message = 'Successfully saved company';
								$("#company_"+id).remove();
							}//end of if
							else{
									$message = "Error encountered while trying to save company";
									$("#close_modal").click();
									up_note($message);
							}
										pre_blocker('off');
									
						},error:function(data){
							$message = "Error encountered while trying to save company";
							$("#close_modal").click();
							up_note($message);
						}
					});

				}

		break;

	}
}


function appointment_process(action,id){

	switch(action){

		case "approved":
		    pre_blocker('on');
			$id_patient = $("#id_patient").val();
			$shop_id = $("#shop_id").val();
			$app_date = $("#app_date").val();
			$app_time = $("#app_time").val();
			$service_id = id;
		    $emp_id = $('input[name=select_employee]:checked').val();

		    
		    
			$.ajax({
				url: getBaseURL()+"Appointments/process",
				type: "POST",
				data:{'emp_id':$emp_id,'action':action,'appointment_id':id,'id_patient':$id_patient,'shop_id':$shop_id},
				success:function(data){

					if(data == "success"){

						$message = 'Successfully approved appointment';
						$("#inline_"+id).remove();
					}//end of if
					else{
							$message = "Error encountered while trying to approve appointment";
					}
								// product_service('in_cart','');
								// product_service('in_reserved','');
								pre_blocker('off');
								$("#close_modal").click();
								up_note($message);
				},//end of success callback
				error:function(data){
					pre_blocker('off');
					up_note("Error encountered while trying to approve appointment");
				}
			});


		break;


		case "respond":
				pre_blocker('on');
					$(".modal-title").text("Select Optometrist/ Optician:");
				    $(".modal-body").html('<div class="row" id="employee_here"></div>');

				
				$shop_id = $("#shop_id_"+id).val();
				$id_patient = $("#patient_id_"+id).val();
				$.ajax({
					url: getBaseURL()+"Employees/employee_list",
					type: "POST",
					data:{'shop_id':$shop_id},
					success:function(data){
						data = $.parseJSON(data);
						console.log(data);

						for(var i=0; i < data.length;i++){
							$("#employee_here").append('\n\
								<div class="col-md-4" align="center" style="margin-bottom:10px;">\n\
									<img src="'+getBaseURL()+'assets/'+data[i]['emp_image']+'" style="width:70px;height:70px;" class="img-rounded">\n\
									<br>\n\
									<strong>'+data[i]['fname']+' '+data[i]['lname']+'</strong>\n\
									<br><input type="radio" name="select_employee" value="'+data[i]['emp_id']+'">\n\
								</div>\n\
								');
						}

						$(".modal-footer").html('<input type="hidden" value="'+$id_patient+'" id="id_patient"><input type="hidden" value="'+$shop_id+'" id="shop_id"><button onclick="appointment_process(\'approved\',\''+id+'\')" class="btn btn-success"><i class="fa fa-paper-plane"></i> Approve</button>');
						pre_blocker('off');
						$("#g_modal").modal();

					}

				});	

		break;
	}
}


function process_service(action,id){
	switch(action){

		case "create":

					$(".modal-title").text("Add Service:");
				    $(".modal-body").html('<div class="row">\n\
				    	<div class="col-md-12">\n\
				    		<input type="hidden" id="service_id">\n\
					    	<span>Service Name: <input class="form-control" type="text" id="service_name"></span>\n\
					    	<br>\n\
					    	<span>Description:</span>\n\
					    	<br>\n\
					    	 <textarea id="description" class="form-control"></textarea>\n\
				    	</div>\n\</div>');

						$(".modal-footer").html('<button onclick="process_service(\'save\',\'\')" class="btn btn-success"><i class="fa fa-paper-plane"></i> Save</button>');
						$("#g_modal").modal();
		break;
	
		case "update":

			pre_blocker('on');
			process_service('create','');

			
			$service_name = $("#service_name_"+id).html();
			$description = $("#description_"+id).html();

			$("#service_id").val(id);
			$("#service_name").val($service_name);
			$("#description").text($description);


			pre_blocker('off');


		break;

		case "save":
			pre_blocker('on');
			form_init('service');
			$.ajax({
				url: getBaseURL()+"Services/process",
				type: "POST",
				data:{'action':action,'service_id':$service_id,'service_name':$service_name,'description':$description},
				success:function(data){
					console.log(data);
							if(data == "success"){
								location.reload();
							}else{
								$message = "Error while trying to save service.";
								pre_blocker('off');
								up_note($message);
							}

				},error:function(data){
						$message = "Error while trying to save service.";
						pre_blocker('off');
						up_note($message);
				}


			});

		break;

		case "remove":

			if(confirm('Are you sure to remove this service?')){
				$.ajax({
					url: getBaseURL()+"Services/process",
					type: "POST",
					data:{'action':action,'service_id':id},
					success:function(data){
								if(data == "success"){
									$("#inline_"+id).remove();
								}else{
									$message = "Error while trying to remove service.";
									pre_blocker('off');
									up_note($message);
								}

					},error:function(data){
							$message = "Error while trying to remove service.";
							pre_blocker('off');
							up_note($message);
					}


				});
			}

		break;
	}
}
	

function process_supplier(action,id){

	switch(action){

		case "create":

					$(".modal-title").text("Add Supplier:");
				    $(".modal-body").html('<div class="row">\n\
				    	<div class="col-md-12">\n\
				    		<input type="hidden" id="supplier_id">\n\
					    	<span>Image: <input class="form-control" type="file" id="file_upload"></span>\n\
					    	<br>\n\
					    	<span>Company Name: <input class="form-control" type="text" id="company_name"></span>\n\
					    	<br>\n\
					    	<span>Contact Person: <input type="text" id="contact_person" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Contact Number: <input type="text" id="contactNo" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Email: <input type="text" id="email" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Address: <input type="text" id="address" class="form-control"></span>\n\
					    	<br>\n\
				    	</div>\n\</div>');

						$(".modal-footer").html('<button onclick="process_supplier(\'save\',\'\')" class="btn btn-success"><i class="fa fa-paper-plane"></i> Save</button>');
						$("#g_modal").modal();

		break;

		case "update":

			pre_blocker('on');
			process_supplier('create','');

			 $("#supplier_id").val(id);
			 $company_name = $("#company_name_"+id).html();
			
			 $("#company_name").val($company_name);
			
			$contact_person = $("#contact_person_"+id).html();
			$("#contact_person").val($contact_person);
			
			$contactNo = $("#contactNo_"+id).html();
			$("#contactNo").val($contactNo);
			
			$email = $("#email_"+id).html();
		    $("#email").val($email);
			
			$address = $("#address_"+id).html();
			$("#address").val($address);
			pre_blocker('off');
		break;


		case "save":

				pre_blocker('on');
		
				form_init('supplier');

				var data_post = new FormData();	
				data_post.append('action','save');
				data_post.append('supplier_id',$supplier_id);
				data_post.append('company_name',$company_name);
				data_post.append('contact_person',$contact_person);
				data_post.append('contactNo',$contactNo);
				data_post.append('email',$email);
				data_post.append('address',$address);
				data_post.append('upload_status',$upload_stat);
				data_post.append('file_upload',$file_upload);

				$.ajax({
					
						url: getBaseURL()+"Suppliers/process",
						type: "POST",
						processData: false,
						contentType: false,
						data: data_post,
						success:function(data){
							if(data == "success"){
								location.reload();
							}else{
								$message = "Error while trying to save product.";
								pre_blocker('off');
								up_note($message);
							}

						},error:function(data){
								$message = "Error while trying to save product.";
								pre_blocker('off');
								up_note($message);
						}

				});

		break;


		case "remove":
			if(confirm('Are you sure to remove this supplier?')){
			
				$.ajax({
					url: getBaseURL()+"Suppliers/process",
					type: "POST",
					data:{'action':action,'supplier_id':id},
					success:function(data){
						if(data =="success"){
							$("#inline_"+id).remove();
						}else{
								$message = "Error while trying to remove supplier.";
								pre_blocker('off');
								up_note($message);
							}

						},error:function(data){
								$message = "Error while trying to remove supplier.";
								pre_blocker('off');
								up_note($message);
						}
				});
			}

		break;

	}//end of switch
}



function process_product(action,id){

	switch(action){
		
		case "reorder":
			$.ajax({
				    url: getBaseURL()+"Products/reorder",
				    success:function(data){
				      data = $.parseJSON(data);
				      if(data.length > 0){
				        $("#reorder_here").html('('+data.length+')')
				      }
				    }
			})

		break;

		case "create":
			if(id==""){
				if(!confirm('Do you want to add supplier first?')){
					process_product('create_list','');
				}else{
					window.location.href=getBaseURL()+"content#/suppliers"
				}
			}else{
				process_product('create_list','');
			}

		break;

		case "create_list":
		$(".modal-title").text("Save Product:");
				    $(".modal-body").html('<div class="row">\n\
				    	<div class="col-md-6">\n\
				    		<input type="hidden" id="product_id">\n\
					    	<span>Image: <input class="form-control" type="file" id="file_upload"></span>\n\
					    	<br>\n\
					    	<span>Name: <input class="form-control" type="text" id="name"></span>\n\
					    	<br>\n\
					    	<span>Type: <select class="form-control" id="product_type"><option>Select Type:</option></select></span>\n\
					    	<br>\n\
					    	<span>Gender: <select class="form-control" id="gender"><option>Select Gender:</option><option value="Male">Male</option><option value="Female">Female</option><option value="Unisex">Unisex</option></select></span>\n\
					    	<br>\n\
					    	<span>Model: <input type="text" id="model" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Brand: <input type="text" id="brand" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Available Qty: <input type="number" id="qty" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Reserved Qty: <input type="number" id="reserved_qty" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Reorder: <input type="number" id="reorder" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Discount: <input type="number" id="discount" class="form-control"></span>\n\
					    	<br>\n\
				    	</div>\n\
				    	<div class="col-md-6">\n\
							\n\
					    	<span>Price: <input type="number" id="price" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Material: <input type="text" id="material" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Lens Type: <input type="text" id="lens_type" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Lens Size: <input type="text" id="lens_size" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Rim: <input type="text" id="rim" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Frame Color: <input type="text" id="frame_color" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Frame Shape: <input type="text" id="frame_shape" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Volume: <input type="number" id="volume" class="form-control"></span>\n\
					    	<br>\n\
					    	<span>Description:<br> \n\
					    	<textarea id="description" class="form-control"></textarea>\n\
					    	<span>Supplier: <select id="supplier_list" class="form-control"><option value="">Select Supplier:</option></select></span>\n\
					    	<br>\n\
					   \n\
				    	</div></div>');

				    process_product('supplier_list','');
				    process_product('product_type','');
				    $(".modal-footer").html('<button onclick=" process_product(\'save\',\'\')" class="btn btn-success"><i class="fa fa-paper-plane"></i> Save</button>');
				    $("#g_modal").modal();
		break;

		case "supplier_list":

			$.ajax({
				url: getBaseURL()+"Suppliers/lists",
				success:function(data){
					data = $.parseJSON(data);

					for(var i=0; i < data.length; i++){
						$("#supplier_list").append('<option value="'+data[i]['sup_id']+'">'+data[i]['company_name']+'</option>')
					}
				}
			})

		break;

		case "save":

			pre_blocker('on');
			form_init('product');

				var data_post = new FormData();	
				data_post.append('action','save');
				data_post.append('name',$name);
				data_post.append('product_id',$product_id);
				data_post.append('product_type',$product_type);
				data_post.append('gender',$gender);
				data_post.append('brand',$brand);
				data_post.append('qty',$qty);
				data_post.append('reserved_qty',$reserved_qty);
				data_post.append('reorder',$reorder);
				data_post.append('supplier_id',$supplier_id);
				data_post.append('discount',$discount);
				data_post.append('price',$price);
				data_post.append('material',$material);
				data_post.append('lens_type',$lens_type);
				data_post.append('lens_size',$lens_size);
				data_post.append('rim',$rim);
				data_post.append('frame_color',$frame_color);
				data_post.append('model',$model);
				data_post.append('frame_shape',$frame_shape);
				data_post.append('volume',$volume);
				data_post.append('description',$description);
				data_post.append('upload_status',$upload_stat);
				data_post.append('file_upload',$file_upload);

				console.log(data_post);

				$.ajax({
					
						url: getBaseURL()+"Products/process",
						type: "POST",
						processData: false,
						contentType: false,
						data: data_post,
						success:function(data){
							if(data == "success"){
								location.reload();
							}else{
								$message = "Error while trying to save product.";
								pre_blocker('off');
								up_note($message);
							}

						},error:function(data){
								$message = "Error while trying to save product.";
								pre_blocker('off');
								up_note($message);
						}

				});


		break;

		case "remove":
			console.log(id);
			if(confirm('Are you sure to remove this product?')){
			
				$.ajax({
					url: getBaseURL()+"Products/process",
					type: "POST",
					data:{'action':action,'product_id':id},
					success:function(data){

						if(data =="success"){
							$("#inline_"+id).remove();
						}else{
								$message = "Error while trying to remove product.";
								pre_blocker('off');
								up_note($message);
							}

						},error:function(data){
								$message = "Error while trying to remove product.";
								pre_blocker('off');
								up_note($message);
						}
				});
			}

		break;


		case "product_type":

			$.ajax({
				url: getBaseURL()+"Products/type_list",
				type: "POST",
				success:function(data){
					data = $.parseJSON(data);

					for(var i=0; i < data.length; i++){
						$("#product_type").append('<option value="'+data[i]['type_id']+'">'+data[i]['name']+'</option>')

					}
				}
			})

		break;


		case "update":

		pre_blocker('on');
			$.ajax({
				url: getBaseURL()+"Products/lists",
				type: 'post',
				data:{'product_id':id},
				success:function(data){

					process_product('create',id)

					data = $.parseJSON(data);

					$name = data[0]['name'];
					$gender = data[0]['gender'];
					$optshop_id = data[0]['optshop_id'];
					$type_id = data[0]['type_id'];
					$os_type = data[0]['os_type'];
					$model = data[0]['model'];
					$description = data[0]['description'];
					$brand = data[0]['brand'];
					$qty = data[0]['qty'];
					$reserved_qty = data[0]['reserved_qty'];
					$reorder = data[0]['reorder'];
					$discount = data[0]['discount'];
					$price = data[0]['price'];
					$optprod_img = data[0]['optprod_img'];
					$status = data[0]['status'];
					$material = data[0]['material'];
					$lens_type = data[0]['lens_type'];
					$lens_size = data[0]['lens_size'];
					$rim = data[0]['rim'];
					$frame_color = data[0]['frame_color'];
					$frame_shape = data[0]['frame_shape'];
					$volume = data[0]['volume'];
					$id_type = data[0]['id_type'];
					$type_name = data[0]['type_name'];	
					$supplier_id = data[0]['supplier_id'];	
					$("#product_id").val(id);
					$("#name").val($name);
					$("#product_type option[value='"+$os_type+"']").attr('selected','selected');
					$("#gender option[value='"+$gender+"']").attr('selected','selected');
					$("#model").val($model);
					$("#brand").val($brand);
					$("#qty").val($qty);
					$("#reserved_qty").val($reserved_qty);
					$("#reorder").val($reorder);
					$("#discount").val($discount);
					$("#price").val($price);
					$("#material").val($material);
					$("#lens_type").val($lens_type);
					$("#lens_size").val($lens_size);
					$("#rim").val($rim);
					$("#frame_color").val($frame_color);
					$("#frame_shape").val($frame_shape);
					$("#volume").val($volume);
					$("#description").text($description);
					$("#supplier_list option[value='"+$supplier_id+"']").attr('selected','selected');
					pre_blocker('off');
				}	

			});
		break;
		case "details":

		pre_blocker('on');
			$.ajax({
				url: getBaseURL()+"Products/lists",
				type: 'post',
				data:{'product_id':id},
				success:function(data){
					data = $.parseJSON(data);
					
					$name = data[0]['name'];
					$gender = data[0]['gender'];
					$optshop_id = data[0]['optshop_id'];
					$type_id = data[0]['type_id'];
					$os_type = data[0]['os_type'];
					$model = data[0]['model'];
					$description = data[0]['description'];
					$brand = data[0]['brand'];
					$qty = data[0]['qty'];
					$reserved_qty = data[0]['reserved_qty'];
					$reorder = data[0]['reorder'];
					$discount = data[0]['discount'];
					$price = data[0]['price'];
					$optprod_img = data[0]['optprod_img'];
					$status = data[0]['status'];
					$material = data[0]['material'];
					$lens_type = data[0]['lens_type'];
					$lens_size = data[0]['lens_size'];
					$rim = data[0]['rim'];
					$frame_color = data[0]['frame_color'];
					$frame_shape = data[0]['frame_shape'];
					$volume = data[0]['volume'];
					$id_type = data[0]['id_type'];
					$type_name = data[0]['type_name'];

					$(".modal-title").text("Product Details:");
				    $(".modal-body").html('<div class="row"><div class="col-md-4">\n\
				    		<img src="'+getBaseURL()+'assets/'+$optprod_img+'">\n\
				    	</div>\n\
				    	<div class="col-md-4">\n\
					    	<span>Name: <strong>'+$name+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Type: <strong>'+$type_name+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Gender: <strong>'+$gender+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Model: <strong>'+$model+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Brand: <strong>'+$brand+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Available Qty: <strong>'+$qty+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Reserved Qty: <strong>'+$reserved_qty+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Reorder: <strong>'+$reorder+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Discount: <strong>'+$discount+'</strong>&nbsp;</span>\n\
					    	<br>\n\
				    	</div>\n\
				    	<div class="col-md-4">\n\
							\n\
					    	<span>Price: <strong>'+$price+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Material: <strong>'+$material+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Lens Type: <strong>'+$lens_type+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Lens Size: <strong>'+$lens_size+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Rim: <strong>'+$rim+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Frame Color: <strong>'+$frame_color+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Frame Shape: <strong>'+$frame_shape+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Volume: <strong>'+$volume+'</strong>&nbsp;</span>\n\
					    	<br>\n\
					    	<span>Description: \n\
					    	<strong>'+$description+'</strong>&nbsp;</span>\n\
					   \n\
				    	</div></div>');
				    $(".modal-footer").html('');

		$("#g_modal").modal();
		pre_blocker('off');
				}

			});
		break;

		case "":

		break;
	}



}

function process_employee(action,id){

	switch(action){
		
		case "save":

			pre_blocker('on');
			form_init('employee');

				var data_post = new FormData();	
				data_post.append('action','save');
				data_post.append('emp_id',$emp_id);
				data_post.append('email',$email);
				data_post.append('password',$password);
				data_post.append('fname',$fname);
				data_post.append('mname',$mname);
				data_post.append('lname',$lname);
				data_post.append('address',$address);
				data_post.append('contact',$contact);
				data_post.append('gender',$gender);
				data_post.append('civil_status',$civil_status);
				data_post.append('birthdate',$birthdate);
				data_post.append('position',$position);
				data_post.append('licenseNo',$licenseNo);
				data_post.append('upload_status',$upload_stat);
				data_post.append('file_upload',$file_upload);

				$.ajax({
					
						url: getBaseURL()+"Employees/process",
						type: "POST",
						processData: false,
						contentType: false,
						data: data_post,
						success:function(data){
							
							console.log(data);
							if(data == "success"){
								location.reload();
							}else{
								$message = "Error while trying to save employee.";
								pre_blocker('off');
								up_note($message);
							}

						},error:function(data){
								$message = "Error while trying to save employee.";
								pre_blocker('off');
								up_note($message);
						}

				});

		break;

		case "create":
		$(".modal-title").text("Create Employee:");

		    $(".modal-body").html('<form class="form-horizontal" style="height:300px;overflow:auto;	overflow-x: hidden">\n\
		    	<input type="hidden" id="emp_id">\n\
		    	<div class="form-group">\n\
		    <label class="control-label col-sm-2" for="email">Image:</label>\n\
		    <div class="col-sm-9">\n\
		      <input type="file" class="form-control" id="file_upload" name="file_upload">\n\
		    </div>\n\
		  </div>\n\
		    	<div class="form-group">\n\
		    <label class="control-label col-sm-2" for="email">Email:</label>\n\
		    <div class="col-sm-9">\n\
		      <input type="email" class="form-control" id="email">\n\
		    </div>\n\
		  </div>\n\
		  \n\
		    	<div class="form-group">\n\
		    <label class="control-label col-sm-2" for="email">Password:</label>\n\
		    <div class="col-sm-9">\n\
		      <input type="password" class="form-control" id="password">\n\
		    </div>\n\
		  </div>\n\
		  \n\
		  <div class="form-group">\n\
		    <label class="control-label col-sm-2" for="pwd">First Name:</label>\n\
		    <div class="col-sm-9"> \n\
		      <input type="text" class="form-control" id="fname">\n\
		    </div>\n\
		  </div>\n\
		  \n\
		  <div class="form-group">\n\
		    <label class="control-label col-sm-2" for="pwd">Middle Name:</label>\n\
		    <div class="col-sm-9"> \n\
		      <input type="text" class="form-control" id="mname">\n\
		    </div>\n\
		  </div>\n\
		  <div class="form-group">\n\
		    <label class="control-label col-sm-2" for="pwd">Last Name:</label>\n\
		    <div class="col-sm-9"> \n\
		      <input type="text" class="form-control" id="lname">\n\
		    </div>\n\
		  </div>\n\
		  <div class="form-group">\n\
		    <label class="control-label col-sm-2" for="pwd">Address:</label>\n\
		    <div class="col-sm-9"> \n\
		      <input type="text" class="form-control" id="address">\n\
		    </div>\n\
		  </div>\n\
		  <div class="form-group">\n\
		    <label class="control-label col-sm-2" for="pwd">Contact:</label>\n\
		    <div class="col-sm-9"> \n\
		      <input type="number" class="form-control" id="contact">\n\
		    </div>\n\
		  </div>\n\
		  <div class="form-group">\n\
		    <label class="control-label col-sm-2" for="pwd">Gender:</label>\n\
		    <div class="col-sm-9"> \n\
		      <select id="gender" class="form-control"><option value="Male">Male</option><option value="Female">Female</option></select>\n\
		    </div>\n\
		  </div>\n\
		  <div class="form-group">\n\
		    <label class="control-label col-sm-2" for="pwd">Civil Status:</label>\n\
		    <div class="col-sm-9"> \n\
		       <select id="civil_status" class="form-control"><option value="Single">Single</option><option value="Married">Married</option><option value="Widowed">Widowed</option></select>\n\
		    </div>\n\
		  </div>\n\
		  <div class="form-group">\n\
		    <label class="control-label col-sm-2" for="pwd">Birthdate:</label>\n\
		    <div class="col-sm-9"> \n\
		      <input type="date" class="form-control" id="birthdate">\n\
		    </div>\n\
		  </div>\n\
		  <div class="form-group">\n\
		    <label class="control-label col-sm-2" for="pwd">Position:</label>\n\
		    <div class="col-sm-9"> \n\
		      <select id="position" class="form-control"><option value="Staff">Staff</option><option value="Optometrist">Optometrist</option></select>\n\
		    </div>\n\
		  </div>\n\
		  <div class="form-group">\n\
		    <label class="control-label col-sm-2" for="pwd">License:</label>\n\
		    <div class="col-sm-9"> \n\
		      <input type="number" class="form-control" id="licenseNo">\n\
		    </div>\n\
		  </div>\n\
		  \n\
		</form>');
		    $(".modal-footer").html('<button type="submit" class="btn btn-success" id="" onclick="process_employee(\'save\',\'\')">Save</button>');

		$("#g_modal").modal();

		break;

		case "update":
			pre_blocker('on');
			$.ajax({
				url: getBaseURL()+"Employees/employee_list",
				type: "POST",
				data: {'emp_id':id},
				success:function(data){
					data = $.parseJSON(data);
					console.log('dob: '+$.datepicker.formatDate("yy-mm-dd", new Date(data[0]['dob'])))
					process_employee('create','');
					$("#emp_id").val(data[0]['emp_id']);
					$("#email").val(data[0]['email']);
					$("#password").val(data[0]['password']);
					$("#fname").val(data[0]['fname']);
					$("#mname").val(data[0]['mname']);
					$("#lname").val(data[0]['lname']);
					$("#address").val(data[0]['address']);
					$("#contact").val(data[0]['contact']);
					$("#gender option[value='"+data[0]['gender']+"']").attr('selected','selected');
					$("#civil_status option[value='"+data[0]['civil_status']+"']").attr('selected','selected');
					$("#birthdate").val($.datepicker.formatDate("yy-mm-dd", new Date(data[0]['dob'])));
					$("#position option[value='"+data[0]['position']+"']").attr('selected','selected');
					$("#licenseNo").val(data[0]['licenseNo']);

					$(".modal-title").text('Update Employee:');
					pre_blocker('off');
				},error:function(data){
					pre_blocker('off')
					$message = "Error while trying to fetch data.";
								pre_blocker('off');
								up_note($message);

				}
			});

		break;



		case "remove":
		if(confirm('Are you sure to remove?')){
			pre_blocker('on');
			$.ajax({

				url: getBaseURL()+"Employees/process",
				type: "POST",
				data:{'action':'remove','emp_id':id},
				success:function(data){
					pre_blocker('off')
					console.log(data);
					if(data == "success"){
						$("#tr_"+id).remove();
					}else{
						$message = "Error while trying to remove employee.";
						pre_blocker('off');
						up_note($message);
					}
				
				},
				error:function(data){
					pre_blocker('off')
					$message = "Error while trying to remove employee.";
								pre_blocker('off');
								up_note($message);
				}
			});

		}
			
		break;

	}//end of switch

}



function process_account(action,id){
	switch(action){
		case "save":

			pre_blocker('on');
			form_init('account');

				var data_post = new FormData();	
				data_post.append('email',$email);
				data_post.append('last_name',$last_name);
				data_post.append('first_name',$first_name);
				data_post.append('middle_name',$middle_name);
				data_post.append('birthdate',$birthdate);
				data_post.append('gender',$gender);
				data_post.append('address',$address);
				data_post.append('contact',$contact);
				data_post.append('civil_status',$civil_status);
				data_post.append('upload_status',$upload_stat);
				data_post.append('file_upload',$file_upload);


				$.ajax({
					
						url: getBaseURL()+"Accounts/save_account",
						type: "POST",
						processData: false,
						contentType: false,
						data: data_post,
						success:function(data){
							if(data == "success"){
								location.reload();
							}else{
								$message = "Error while trying to save subscription.";
								pre_blocker('off');
								up_note($message);
							}

						},error:function(data){
								$message = "Error while trying to save subscription.";
								pre_blocker('off');
								up_note($message);
						}

				});


		break;
	}
}

function process_subscription(action,id){
// optshop_name
// optshop_add
// optshop_tel
// owner_id
// optshop_lat
// optshop_long

	switch(action){

		case "create":

		  $(".modal-title").text("Create Subscription:");

		    $(".modal-body").html('<form class="form-horizontal">\n\
		    	<div class="form-group">\n\
		    <label class="control-label col-sm-2" for="email">Image:</label>\n\
		    <div class="col-sm-10">\n\
		      <input type="file" class="form-control" id="file_upload" name="file_upload">\n\
		    </div>\n\
		  </div>\n\
		    	<div class="form-group">\n\
		    <label class="control-label col-sm-2" for="email">Name:</label>\n\
		    <div class="col-sm-10">\n\
		      <input type="email" class="form-control" id="optshop_name">\n\
		    </div>\n\
		  </div>\n\
		  \n\
		  <div class="form-group">\n\
		    <label class="control-label col-sm-2" for="pwd">Address:</label>\n\
		    <div class="col-sm-10"> \n\
		      <input type="text" class="form-control" id="optshop_add">\n\
		    </div>\n\
		  </div>\n\
		  \n\
		  <div class="form-group">\n\
		    <label class="control-label col-sm-2" for="pwd">Contact:</label>\n\
		    <div class="col-sm-10"> \n\
		      <input type="text" class="form-control" id="optshop_tel">\n\
		    </div>\n\
		    <input type="hidden" disabled="disabled" class="form-control" id="optshop_lat">\n\
		    <input type="hidden" disabled="disabled" class="form-control" id="optshop_lat">\n\
 			<input type="hidden" disabled="disabled" class="form-control" id="optshop_id">\n\
		  </div>\n\
		  \n\
		</form>');
		    $(".modal-footer").html('<button type="submit" class="btn btn-success" id="" onclick="process_subscription(\'get_map_location\',\'save\')">Save</button>');

		$("#g_modal").modal();

		   	 // <div align="right"><a href="http://www.gps-coordinates.net/" target="_blank">Check Map</a></div>\n\

		break;

		case "save":
			form_init('subscription');

				var data_post = new FormData();	
				data_post.append('action','save');
				data_post.append('optshop_name',$optshop_name);
				data_post.append('optshop_add',$optshop_add);
				data_post.append('optshop_tel',$optshop_tel);
				data_post.append('optshop_lat',$optshop_lat);
				data_post.append('optshop_long',$optshop_long);
				data_post.append('upload_status',$upload_stat);
				data_post.append('file_upload',$file_upload);
				data_post.append('optshop_id',$optshop_id);
				
				
				$.ajax({
					url: getBaseURL()+"Subscriptions/process",
					type: "POST",
					processData: false,
					contentType: false,
					data: data_post,
					success:function(data){
						if(data =="success"){
							$message = "Successfully saved.";
							location.reload();
						}else{
							$message = "Error while trying to save subscription.";

						}

							pre_blocker('off');
							up_note($message);
					},
					error:function(data){
						pre_blocker('off');
						up_note('Error while trying to save subscription.');
					}
				});	
		break;

		case "update":
			 pre_blocker('on');

			 process_subscription('create',id);	

			$optshop_name = $("#optshop_name_"+id).html();
			$optshop_add = $("#optshop_add_"+id).html();
			$optshop_tel = $("#optshop_tel_"+id).html();
			
			console.log($optshop_name);
			$("#optshop_name").val($optshop_name);
			$("#optshop_add").val($optshop_add);
			$("#optshop_tel").val($optshop_tel);
			$("#optshop_id").val(id);

			pre_blocker('off');

		break;

		case "remove":

		if(confirm('Are you sure you want to remove?')){	
			pre_blocker('on');
			$.ajax({
				url: getBaseURL()+"Subscriptions/process",
				type: "POST",
				data:{'action':'remove','optshop_id':id},
				success:function(data){

					if(data =="success"){
						$message = "Successfully removed";
						$("#tr_"+id).remove();
					}else{
						$message = "Error while trying to remove subscription.";
					}

				pre_blocker('off');
				up_note($message);
				},error:function(data){
					pre_blocker('off');
					up_note("Error while trying to remove subscription");
				}		
			});//end of ajax

		}//end of if

		break;

		case "get_map_location":
				pre_blocker('on');
				var sub_address = $("#optshop_add").val();
			
				$.ajax({
				url:"http://maps.googleapis.com/maps/api/geocode/json?address="+sub_address+"&sensor=false",
				type: "POST",
				success:function(res){
				$optshop_lat = res.results[0].geometry.location.lat;
				$optshop_long = res.results[0].geometry.location.lng;
					
					$("#optshop_lat").val($optshop_lat);	
					$("#optshop_long").val($optshop_long);	

					process_subscription('save','');
				},error:function(data){
					pre_blocker('off');
					up_note('Error encountered while trying to fetch data');
				}
			});

				
		break;

	}//end of switch

}


function form_init(module){
	switch(module){
		
		case "service":
			$service_id = $("#service_id").val();
			$service_name = $("#service_name").val();
			$description = $("#description").val();
		break; 

		case "supplier":

			$file_upload = $("#file_upload").prop('files')[0];
			if(!$file_upload){$upload_stat='dont_upload';}else{$upload_stat='upload';}

			$supplier_id = $("#supplier_id").val();
			$company_name = $("#company_name").val();
			$contact_person = $("#contact_person").val();
			$contactNo = $("#contactNo").val();
			$email = $("#email").val();
			$address = $("#address").val();

		break;

		case "product":
			$file_upload = $("#file_upload").prop('files')[0];
			if(!$file_upload){$upload_stat='dont_upload';}else{$upload_stat='upload';}
			
			$product_id = $("#product_id").val();
			$supplier_id = $("#supplier_list").val();
			$name = $("#name").val();
			$product_type = $("#product_type").val();
			$gender = $("#gender").val();
			$model = $("#model").val();
			$brand = $("#brand").val();
			$qty = $("#qty").val();
			$reserved_qty = $("#reserved_qty").val();
			$reorder = $("#reorder").val();
			$discount = $("#discount").val();
			$price = $("#price").val();
			$material = $("#material").val();
			$lens_type = $("#lens_type").val();
			$lens_size = $("#lens_size").val();
			$rim = $("#rim").val();
			$frame_color = $("#frame_color").val();
			$frame_shape = $("#frame_shape").val();
			$volume = $("#volume").val();
			$description = $("#description").val();
		break;

		case "subscription":

		$file_upload = $("#file_upload").prop('files')[0];
		if(!$file_upload){$upload_stat='dont_upload';}else{$upload_stat='upload';}

				$optshop_name = $("#optshop_name").val();
				$optshop_add = $("#optshop_add").val();
				$optshop_tel = $("#optshop_tel").val();
				$optshop_lat = $("#optshop_lat").val();
				$optshop_id = $("#optshop_id").val();
				$optshop_long = $("#optshop_long").val();

		break;

		case "account":

		$file_upload = $("#file_upload").prop('files')[0];
		if(!$file_upload){$upload_stat='dont_upload';}else{$upload_stat='upload';}

			$email =  $("#email").val();
			$last_name =  $("#last_name").val();
			$first_name =  $("#first_name").val();
			$middle_name =  $("#middle_name").val();
			$birthdate =  $("#birthdate").val();
			$gender = $('input[name=gender]:checked').val();
			$address =  $("#address").val();
			$contact =  $("#contact").val();
			$civil_status =  $("#civil_status").val();

		break;

		case "employee":
		$file_upload = $("#file_upload").prop('files')[0];
		if(!$file_upload){$upload_stat='dont_upload';}else{$upload_stat='upload';}

		$emp_id = $("#emp_id").val();
		$email = $("#email").val();
		$password = $("#password").val();
		$fname = $("#fname").val();
		$mname = $("#mname").val();
		$lname = $("#lname").val();
		$address = $("#address").val();
		$contact = $("#contact").val();
		$gender = $("#gender").val();
		$civil_status = $("#civil_status").val();
		$birthdate = $("#birthdate").val();
		$position = $("#position").val();
		$licenseNo = $("#licenseNo").val();

		break;

	}//end of switch
}