// var blinkrr = angular.module('blinkrr',['ngRoute','angularUtils.directives.dirPagination']);

blinkrr.controller("MyProfileCtrl",function($scope,$http){

  $scope.my_profile = function(){
    
    $http.get(getBaseURL()+"Web/get_profile").success(function(data){
      $scope.profile = data;
    })
  }

  $scope.update_profile = function(){
    $profile_attr = {
        first_name :$("#first_name").val(),
        middle_name :$("#middle_name").val(),
        last_name :$("#last_name").val(),
        contactNo :$("#contactNo").val(),
        email :$("#email").val(),
        pw :$("#pw").val(),
        address :$("#address").val(),
        dob :$("#dob").val(),
        civil_status :$("#civil_status").val()
    }

    // console.log($profile_attr)
    //pre_blocker('on');

    $http({
      url: getBaseURL()+"Web/profile_update",
      method: "POST",
      data:$.param({'profile_attr':$profile_attr}),
      headers:{'Content-Type':'application/x-www-form-urlencoded'}
    }).success(function(data){
      if(data == "success"){
        $scope.my_profile();
        alert('Successfully updated!');
      }else{
        alert("Error has been encountered!");
      }
      pre_blocker('off');
    })

  }

  $scope.my_profile();

})


blinkrr.controller("HistoryCtrl",function($scope,$http){

  $scope.page_title = "My History";
  $http.get(getBaseURL()+"Patient_history/lists").success(function(data){
    $scope.list = data;
  })

});

blinkrr.controller("NotificationCtrl",function($scope,$http){

  $scope.page_title = "Notification List";
  $http.get(getBaseURL()+"Notifications/lists").success(function(data){
    $scope.list = data;
  })

  $scope.notice_read = function(status,id){

        if(status == 0){
          $x = '<button class="btn btn-success" onclick="notification_process(\'mark_as_read\',\''+id+'\')"><i class="fa fa-check"></i> Mark as Read</button>';
        }else if(status == 1){
          $x = '<button class="btn btn-primary" onclick="notification_process(\'mark_as_unread\',\''+id+'\')"><i class="fa fa-check"></i> Mark as Unread</button>';
        }

        $("#notice_here_"+id).html($x);

  }//end of function


});

blinkrr.controller("AppointmentCtrl",function($scope,$http){

  $scope.page_title = "My Appointment(s)";

  $http.get(getBaseURL()+"Appointments/lists").success(function(data){
    $scope.list = data;
    
  });

  $scope.process = function(action,id){
    appointment_process(action,id);
  }


});

blinkrr.controller("ReserveCtrl",function($scope,$http){

     $("#current_module").val('reservation');  
     $current_user = $("#current_user").val();

    if($current_user==""){
      $scope.page_title = "Logged in to view reserved items";
    }else{
      $scope.page_title = "My Reserved Items";
      $scope.cart_table = true;
        $http.get(getBaseURL()+"Products/in_reserved").success(function(data){
          $scope.list = data;
        });
    }

    $scope.process = function(action,id){
      product_service(action,id);
    }
    
});

blinkrr.controller("CartCtrl",function($scope,$http){
    
     $("#current_module").val('my_cart');

    $current_user = $("#current_user").val();
    if($current_user==""){
      $scope.page_title = "Logged in to add items to cart";
    }else{
      $scope.page_title = "My Cart";
      $scope.cart_table = true;
        $http.get(getBaseURL()+"Products/in_cart").success(function(data){
          $scope.list = data;
        });
    }

    $scope.process = function(action,id){
      product_service(action,id);
    }

});

blinkrr.controller("OpticalCtrl",function($scope,$http){

     $("#current_module").val('shops');
  $http.get(getBaseURL()+"Web/opticals").success(function(data){
    $scope.list = data;
  });

  $scope.process = function(action,id){
    shop_process(action,id);
  }

  $scope.shop_details = function(shop_id){
    $("#submit_btn_"+shop_id).click();
    pre_blocker('on');
  }

});

blinkrr.controller("WebServiceCtrl",function($scope,$http){
     $("#current_module").val('services');
    pre_blocker('on');
    $http.get(getBaseURL()+"Services/lists").success(function(data){
        $scope.list = data;
        pre_blocker('off');
    });

    $scope.process = function(action,id){

      if(current_user('validate')){
          service_process(action,id);        
      }else{
          current_user('logged_in');
      }
    }

    $scope.convert = function(target,span,min){
      
      if(min == "13"){
        $return = "1";
      }
      else if(min == "14"){
        $return = "2";
      }
      else if(min == "15"){
        $return = "3";
      }
      else if(min == "16"){
        $return = "4";
      }
      else if(min == "17"){
        $return = "5";
      }
      else if(min == "18"){
        $return = "6";
      }
      else if(min == "19"){
        $return = "7";
      }
      else if(min == "20"){
        $return = "8";
      }
      else if(min == "21"){
        $return = "9";
      }
      else if(min == "22"){
        $return = "10";
      }
      else if(min == "23"){
        $return = "11";
      }
      else if(min == "24"){
        $return = "12";
      }
      else{
        $return = min;
      }


        if(min >=12){
          $meridan = "PM";
        }else{
          $meridan = "AM";
        }
      // console.log($return);
      if(target == "to"){
            $("#span_to_meridan_"+span).html($meridan);
      }else{
          $("#span_from_meridan_"+span).html($meridan);
      }
      
      $("#span_hour_"+target+"_"+span).html($return);
    }

});

blinkrr.controller("IndexCtrl",function($scope,$http){

  $("#current_module").val('index');
  
  pre_blocker('on');
  $http.get(getBaseURL()+"Products/lists").success(function(data){
      $scope.list = data;
      pre_blocker('off');
  });

   $scope.process = function(action,id){
         if(current_user('validate')){
            product_service(action,id);        
         }else{
            current_user('logged_in');
         }
     } 

});


blinkrr.controller("WebHeaderUp",function($scope,$http){
	$scope.signup = function(){
		$(".modal-title").text("Sign Up");
		$(".modal-body").html('<ul class="nav nav-tabs">\n\
		  <li class="active"><a onclick="sign_up_tab(\'0\')" data-toggle="tab" href="#home">Customer/Patient</a></li>\n\
		  <li><a data-toggle="tab" onclick="sign_up_tab(\'1\')" href="#menu2">Owner</a></li>\n\
		</ul>\n\
		\n\
		<div class="tab-content">\n\
		  <input type="hidden" id="selected_sign_up_tab" value="0">\n\
      <div id="home" class="tab-pane fade in active">\n\
		   '+customer_form()+'\n\
		  </div>\n\
		  <div id="menu2" class="tab-pane fade">\n\
		    '+optical_form()+'\n\
		  </div>\n\
		</div>');
		$(".modal-footer").html('<button type="submit" class="btn btn-success" onclick="insert_signup()">Register</button>');

	
		$("#g_modal").modal();

	}

var customer_form = function(){
$form = '<br><form class="form-horizontal"><div class="form-group">\n\
    <label class="control-label col-sm-2" for="email">Email:</label>\n\
    <div class="col-sm-10">\n\
      <input type="email" class="form-control" id="email">\n\
    </div>\n\
  </div>\n\
  \n\
  <div class="form-group">\n\
    <label class="control-label col-sm-2" for="pwd">Password:</label>\n\
    <div class="col-sm-10"> \n\
      <input type="password" class="form-control" id="pwd">\n\
    </div>\n\
  </div>\n\
  \n\
  <div class="form-group">\n\
    <label class="control-label col-sm-2" for="pwd">Firstname:</label>\n\
    <div class="col-sm-10"> \n\
      <input type="text" class="form-control" id="custo_first">\n\
    </div>\n\
  </div>\n\
  \n\
  <div class="form-group">\n\
    <label class="control-label col-sm-2" for="pwd">Middlename:</label>\n\
    <div class="col-sm-10"> \n\
      <input type="text" class="form-control" id="custo_middle">\n\
    </div>\n\
  </div>\n\
  \n\
  <div class="form-group">\n\
    <label class="control-label col-sm-2" for="pwd">Lastname:</label>\n\
    <div class="col-sm-10"> \n\
      <input type="text" class="form-control" id="custo_last">\n\
    </div>\n\
  </div>\n\
\n\
  <div class="form-group">\n\
    <label class="control-label col-sm-2" for="pwd">Gender:</label>\n\
    <div class="col-sm-10"> \n\
       <label class="radio-inline"><input id="custo_gender" type="radio" name="custo_gender" value="Male">Male</label>\n\
  		<label class="radio-inline"><input id="custo_gender" type="radio" name="custo_gender" value="Female">Female</label>\n\
  </div>\n\
    </div>\n\
\n\
</form>';

return $form;
}

var optical_form = function(){
$form = '<br><form class="form-horizontal"><div class="form-group">\n\
    <label class="control-label col-sm-2" for="email">Email:</label>\n\
    <div class="col-sm-10">\n\
      <input type="email" class="form-control" id="email2">\n\
    </div>\n\
  </div>\n\
  \n\
  <div class="form-group">\n\
    <label class="control-label col-sm-2" for="pwd">Password:</label>\n\
    <div class="col-sm-10"> \n\
      <input type="password" class="form-control" id="pwd2">\n\
    </div>\n\
  </div>\n\
  \n\
  <div class="form-group">\n\
    <label class="control-label col-sm-2" for="pwd">Shop Name:</label>\n\
    <div class="col-sm-10"> \n\
      <input type="text" class="form-control" id="shop_name">\n\
    </div>\n\
  </div>\n\
\n\
  <div class="form-group">\n\
    <label class="control-label col-sm-2" for="pwd">Shop Address:</label>\n\
    <div class="col-sm-10"> \n\
      <input type="text" class="form-control" id="shop_add">\n\
    </div>\n\
  </div>\n\
  <div class="form-group">\n\
    <label class="control-label col-sm-2" for="pwd">Shop Contact:</label>\n\
    <div class="col-sm-10"> \n\
      <input type="number" class="form-control" id="shop_contact">\n\
    </div>\n\
  </div>\n\
  <div class="form-group">\n\
    <label class="control-label col-sm-2" for="pwd">Business Hours:</label>\n\
    <div class="col-sm-10"><div class="row"><div class="col-md-6"><strong>From:</strong><br>\n\
    <select id="shop_from_hours" class="form-control"><option value="24">12:00AM</option>\n\
    <option value="01">1:00AM</option>\n\
    <option value="02">2:00AM</option>\n\
    <option value="03">3:00AM</option>\n\
    <option value="04">4:00AM</option>\n\
    <option value="05">5:00AM</option>\n\
    <option value="06">6:00AM</option>\n\
    <option value="07">7:00AM</option>\n\
    <option value="08">8:00AM</option>\n\
    <option value="09">9:00AM</option>\n\
    <option value="10">10:00AM</option>\n\
    <option value="11">11:00AM</option>\n\
    <option value="12">12:00PM</option>\n\
    <option value="13">1:00PM</option>\n\
    <option value="14">2:00PM</option>\n\
    <option value="15">3:00PM</option>\n\
    <option value="16">4:00PM</option>\n\
    <option value="17">5:00PM</option>\n\
    <option value="18">6:00PM</option>\n\
    <option value="19">7:00PM</option>\n\
    <option value="20">8:00PM</option>\n\
    <option value="21">9:00PM</option>\n\
    <option value="22">10:00PM</option>\n\
    <option value="23">11:00PM</option></select><br><select id="shop_from_minutes" class="form-control"></select>\n\
    </div>\n\
    <div class="col-md-6"><strong>Until:</strong><br>\n\
    <select id="shop_to_hours" class="form-control"><option value="24">12:00AM</option>\n\
    <option value="01">1:00AM</option>\n\
    <option value="02">2:00AM</option>\n\
    <option value="03">3:00AM</option>\n\
    <option value="04">4:00AM</option>\n\
    <option value="05">5:00AM</option>\n\
    <option value="06">6:00AM</option>\n\
    <option value="07">7:00AM</option>\n\
    <option value="08">8:00AM</option>\n\
    <option value="09">9:00AM</option>\n\
    <option value="10">10:00AM</option>\n\
    <option value="11">11:00AM</option>\n\
    <option value="12">12:00PM</option>\n\
    <option value="13">1:00PM</option>\n\
    <option value="14">2:00PM</option>\n\
    <option value="15">3:00PM</option>\n\
    <option value="16">4:00PM</option>\n\
    <option value="17">5:00PM</option>\n\
    <option value="18">6:00PM</option>\n\
    <option value="19">7:00PM</option>\n\
    <option value="20">8:00PM</option>\n\
    <option value="21">9:00PM</option>\n\
    <option value="22">10:00PM</option>\n\
    <option value="23">11:00PM</option></select><br><select id="shop_to_minutes" class="form-control"></select>\n\
    </div>\n\
  </div>\n\
\n\
</form>';

return $form;
}
  


$scope.sign_in = function (){
    current_user('logged_in');
}



});


function sign_up_tab(val){
  $("#selected_sign_up_tab").val(val); 
  $("#appended_minutes").remove();
  if(val == 1){
        for(var i=0; i < 62; i++){
        if(i <=9 && i >=1){
            $min = "0"+i;
            $min2 = i;
          }else if(i == 0){
            $min = "00";
            $min2 = "00";
          }else{
            $min2 = i;
            $min = i;
          }
          $("#shop_from_minutes").append('<option class="appended_minutes" value="'+$min2+'">'+$min+'</option>');  
          $("#shop_to_minutes").append('<option class="appended_minutes" value="'+$min2+'">'+$min+'</option>');  
        }
  }

}



blinkrr.config(function($routeProvider){

  $routeProvider
  .when("/services",{
    templateUrl: getBaseURL()+"Web/services"
  })

  .when("/notifications",{

      templateUrl: getBaseURL()+"Web/notice"
  })

  .when("/appointments",{
    templateUrl:getBaseURL()+"Web/appointments"
  })

  .when("/opticals",{
    templateUrl: getBaseURL()+"Web/shops"
  })

  .when("/my_cart",{
    templateUrl: getBaseURL()+"Web/my_cart"
  })

  .when("/reservations",{
    templateUrl: getBaseURL()+"Web/my_reserved"
  })

  .when("/shop_details",{
    templateUrl: getBaseURL()+"Web/view_shop"
  })

  .when("/my_history",{
    templateUrl: getBaseURL()+"Web/my_history"
  })

  .when("/my_profile",{
    templateUrl: getBaseURL()+"Web/my_profile"
  })

  .otherwise({
    templateUrl:getBaseURL()+"Web/web_index"
  })

});