$(function(){


})


blinkrr.controller("NoticeCtrl",function($scope,$http){

  $("#content_ul li").removeAttr('class');

  $scope.page_title = "Notification List";
  $http.get(getBaseURL()+"Notifications/lists").success(function(data){
    $scope.list = data;
  })

  $scope.notice_read = function(status,id){

        if(status == 0){
          $x = '<button class="btn btn-success" onclick="notification_process(\'mark_as_read\',\''+id+'\')"><i class="fa fa-check"></i> Mark as Read</button>';
        }else if(status == 1){
          $x = '<button class="btn btn-primary" onclick="notification_process(\'mark_as_unread\',\''+id+'\')"><i class="fa fa-check"></i> Mark as Unread</button>';
        }

        $("#notice_here_"+id).html($x);
  }//end of function

});

blinkrr.controller("ReserveCtrl",function($scope,$http){

      $scope.page_title = "Reservation List";
      $scope.cart_table = true;
        $http.get(getBaseURL()+"Products/in_reserved").success(function(data){
          $scope.list = data;
          console.log(data);
        });
 
    $scope.process = function(action,id){
      product_service(action,id);
    }
    
});


blinkrr.controller("SubscriptionCtrl",function($scope,$http){

	$scope.module_title = "Subscription List";

	pre_blocker('on');

	$http({
		url: getBaseURL()+"Subscriptions/sub_list",
		method: "POST",
		headers:{'Content-Type':'application/x-www-form-urlencoded'}
	}).success(function(data){

		pre_blocker('off');
		$scope.sub_list = data;
	}).error(function(data){

		pre_blocker('off');
		up_note('Error encountered while trying to fetch data');
	});

	$scope.process = function(action,id){		  
		
		// console.log('Action: '+action+' ID:'+id)
		process_subscription(action,id);
	}




}); //end of SupplierCtrl

//=====================================================  END =====================================================  


blinkrr.controller("AccountCtrl",function($scope,$http){

	$scope.details = {};
	$scope.module_title = "My Account";
	
	pre_blocker('on');	
	$http.get(getBaseURL()+"Accounts/get_info").success(function(data){
		
		 // $scope.details = data;
		$scope.details.lname =  data[0].lname
		$scope.details.fname =   data[0].fname
		$scope.details.mname =  data[0].mname
		$scope.details.contact =  data[0].contact

		$("input[name='gender'][value='"+data[0].sex+"']").prop('checked',true);

		console.log(data[0].sex);
		$scope.details.adds =  data[0].adds
		$scope.details.em =  data[0].em
		
		$("#img_here").attr('src','assets/'+data[0].image);

		$scope.details.birthdate =  data[0].birthdate
		$scope.details.cs =  data[0].cs

		pre_blocker('off');
	});


	$scope.upload_file = function(){
		$("#file_upload").click();
	}


}); //end of AccountCtrl

//=====================================================  END =====================================================  


blinkrr.controller("OpticalCtrl",function($scope,$http){

	$scope.module_title = "Supplier List";
}); //end of SupplierCtrl

//=====================================================  END =====================================================  


blinkrr.controller("ProductCtrl",function($scope,$http){

	$scope.module_title = "Product List";

	$http.get(getBaseURL()+"Products/lists").success(function(data){
		
		$scope.module_list = data;
	});

	$scope.process = function(action,id){
		process_product(action,id);
	}

}); //end of SupplierCtrl

blinkrr.controller("ReorderProductCtrl",function($scope,$http){

	$scope.module_title = "Re-order Product List";

	$http.get(getBaseURL()+"Products/reorder").success(function(data){
		
		$scope.module_list = data;
	});

	$scope.process = function(action,id){
		process_product(action,id);
	}

}); //end of SupplierCtrl

//=====================================================  END ===================================================== 

blinkrr.controller("ServicesCtrl",function($scope,$http){

	$scope.module_title = "Service List";

		$http.get(getBaseURL()+"Services/lists").success(function(data){
			$scope.list = data;
		});

	$scope.process = function(action,id){
		process_service(action,id)
	}	


}); //end of SupplierCtrl

//=====================================================  END ===================================================== 

blinkrr.controller("SupplierCtrl",function($scope,$http){

	$scope.module_title = "Supplier List";

	$http.get(getBaseURL()+"Suppliers/lists").success(function(data){
		$scope.suppliers = data;
	});

	$scope.process = function(action,id){
		process_supplier(action,id);
	}


}); //end of SupplierCtrl

//=====================================================  END ===================================================== 

blinkrr.controller("ReservationCtrl",function($scope,$http){

	$scope.module_title = "Reservation List";


}); //end of SupplierCtrl

//=====================================================  END ===================================================== 

blinkrr.controller("AppointmentCtrl",function($scope,$http){

  $scope.page_title = "Appointment List";
  $http.get(getBaseURL()+"Appointments/lists").success(function(data){
    $scope.list = data;
  });

  $scope.process = function(action,id){
  	appointment_process(action,id)

  }

}); //end of SupplierCtrl

//=====================================================  END ===================================================== 

blinkrr.controller("PaymentCtrl",function($scope,$http){

	$scope.module_title = "Payment List";
	$scope.sales_list = function(){
		$http.get(getBaseURL()+"Payments/sales").success(function(data){
			$scope.sales = data;
			$scope.sales_tbl = true;
			$scope.subs_tbl = false;
		})
	}

	$scope.sub_list = function(){
		$http.get(getBaseURL()+"Payments/subs").success(function(data){
			$scope.sub_list = data;
			console.log(data);
			$scope.sales_tbl = false;
			$scope.subs_tbl = true;
		})
	}


	$scope.change_tab = function(action){
		$("#pay_ul li").removeAttr('class');

		switch(action){
			case "sales":
				$("#sales_li").attr('class','active');
				$scope.sales_list();
			break;

			case "subscriptions":
				$("#sub_li").attr('class','active');
				$scope.sub_list();
			break;
		}
	}



	$scope.sales_list();

}); //end of SupplierCtrl

//=====================================================  END ===================================================== 

blinkrr.controller("NotificationCtrl",function($scope,$http){

	$scope.module_title = "Notification List";

}); //end of SupplierCtrl

//=====================================================  END ===================================================== 

blinkrr.controller("ReportsCtrl",function($scope,$http){

	$scope.module_title = "Report List";

	if($("#access_type").val()=="2"){
		report_process('report_list','patients');
	}else{
			report_process('report_list','inventory');
	}
	

	$scope.process = function(action,id){
		report_process(action,id);

		console.log('here');
	}

}); //end of SupplierCtrl

//====================================================== END =====================================================

blinkrr.controller("JobOrderCtrl",function($scope,$http){

	$scope.job_list = function(action){
		$("#create_job").hide();
		pre_blocker('on');
		$http({
			url:getBaseURL()+"Job_orders/lists",
			method: "POST",
			data:$.param({'request':action}),
			headers:{'Content-Type':'application/x-www-form-urlencoded'}
		}).success(function(data){
			$("#page_title").html(""+action+" Job Orders");
			$scope.list = data;
			console.log(data);

			$("#job_ul li").removeAttr('class');
			$("#"+action).attr('class','active');
			$("#job_list").show();
			pre_blocker('off');
		});

	}

	$scope.process = function(action,id){
			job_process(action,id);

			if(action == "create"){

				$http.get(getBaseURL()+"Employees/employee_list").success(function(data){
					$scope.x_employee = data;
				})

				$http.get(getBaseURL()+"Insurances/company_list").success(function(data){
					$scope.x_company = data;
				});

				$http.get(getBaseURL()+"Patients/lists").success(function(data){
					$scope.x_patient = data;
				});

				$http.get(getBaseURL()+"Products/lists").success(function(data){
					$scope.products = data;
					console.log(data);
				})

				// $http.get(getBaseURL()+"Promo/lists").success(function(data){
				// 	$scope.products = data;
				// })

				// datetime_picker();
			
			}//end of if
	}//end of function 

	$scope.check_status = function(id,status){
// <button class='btn btn-success' onclick='job_process(\"update\",\""+id+"\")'><i class='fa fa-check'></i> Update</button>&nbsp;&nbsp;
		if(status == "Reserved"){
			$x = "<button class='btn btn-success' onclick='job_process(\"sold\",\""+id+"\")'><i class='fa fa-list'></i> Mark as Sold</button>&nbsp;&nbsp;<button class='btn btn-danger' onclick='job_process(\"remove\",\""+id+"\")'><i class='fa fa-remove'></i> Remove</button>";
		}else if(status == "Sold"){
			$x = "<button class='btn btn-danger' onclick='job_process(\"remove\",\""+id+"\")'><i class='fa fa-remove'></i> Remove Record</button>";
		}

		$("#job_"+id).html($x);
	}


	$scope.job_list('Reserved');




}); //end of SupplierCtrl

//====================================================== END =====================================================

blinkrr.controller("EmployeeCtrl",function($scope,$http){

	$scope.module_title = "Employee List";	
	

	$http.get(getBaseURL()+"Employees/employee_list").success(function(data){
		$scope.list = data;
		console.log(data);
	});


	$scope.process = function(action,id){		  
		
		// console.log('Action: '+action+' ID:'+id)
		process_employee(action,id);
	}


}); //end of SupplierCtrl

//====================================================== END =====================================================

blinkrr.controller("InsuranceCtrl",function($scope,$http){

	$scope.remove_active = function(target){
		$("#module_tabs li").removeAttr('class');
		$("#"+target).attr('class','active');
	}


	$scope.create_insurance = function(action){

		switch(action){
			case "create":
				$scope.insurance_right = false;
				$scope.patient_insurance = true;
				$scope.insurance_table = false;

				$http.get(getBaseURL()+"Employees/employee_list").success(function(data){
					$scope.x_employee = data;
				})

				$http.get(getBaseURL()+"Insurances/company_list").success(function(data){
					$scope.x_company = data;
				});

				$http.get(getBaseURL()+"Patients/lists").success(function(data){
					$scope.x_patient = data;
				})

			break;

			case "cancel":
				$scope.insurance_right = true;
				$scope.patient_insurance = false;
				$scope.insurance_table = true;
			break;

			case "global_cancel":
				$scope.patient_insurance = false;
			break;
		}
	}

	
	$scope.show_history = function(){
		console.log('history');
		$scope.company_list = false;
		$scope.insurance_list = false;
		$scope.history_list = true;
		$scope.create_insurance('global_cancel');
		$scope.remove_active('show_history');
	
		$http.get(getBaseURL()+"Patient_history/lists").success(function(data){
		    $scope.ylist = data;
	    });


	}

	$scope.show_companies = function(){
		console.log('company');
		$scope.insurance_list = false;
		$scope.history_list = false;
		$scope.company_list = true;
		$scope.create_insurance('global_cancel');
		insurance_process('company','');
		$scope.remove_active('show_companies');
	}

	// $scope.module_title = "Insurance List";
	$scope.show_insurance = function(){
			pre_blocker('on');
		$http.get(getBaseURL()+"Insurances/lists").success(function(data){
			$scope.list = data;
			$scope.insurance_list = true;
			$scope.history_list = false;
			$scope.company_list = false;
			$scope.create_insurance('global_cancel');
			$scope.insurance_right = true;
			$scope.insurance_table = true;

			$scope.remove_active('show_insurance');
			pre_blocker('off');
		});

	}

	$scope.show_insurance();


	$scope.process = function(action,id){
		insurance_process(action,id);
	}



}); //end of SupplierCtrl









 var loadFile = function(event) {
    var output = document.getElementById('img_here');
    output.src = URL.createObjectURL(event.target.files[0]);
  };


 var loadFile2 = function(event) {
    var output = document.getElementById('img_here2');
    output.src = URL.createObjectURL(event.target.files[0]);
  };








function set_active(target){
	$("#content_ul li").removeAttr('class');
	$("#li_"+target).attr('class','active');
}

blinkrr.config(function($routeProvider){

	$routeProvider
	.when("/subscriptions",{
		templateUrl: getBaseURL()+"Subscriptions"
	})
	.when("/notifications",{
		templateUrl: getBaseURL()+"Notifications"
	})
	.when("/reports",{
		templateUrl: getBaseURL()+"Reports"
	})
	.when("/payments",{
		templateUrl: getBaseURL()+"Payments"
	})
	.when("/reservations",{
		templateUrl: getBaseURL()+"Reservations"
	})
	.when("/accounts",{
		templateUrl: getBaseURL()+"Accounts"
	})
	.when("/products",{
		templateUrl: getBaseURL()+"Products"
	})
	.when("/services",{
		templateUrl: getBaseURL()+"Services"
	})
	.when("/opticals",{
		templateUrl: getBaseURL()+"Opticals"
	})
	.when("/employees",{
		templateUrl: getBaseURL()+"Employees"
	})
	.when("/insurances",{
		templateUrl: getBaseURL()+"Insurances"
	})
	.when("/appointments",{
		templateUrl: getBaseURL()+"Appointments"
	})
	.when("/job_orders",{
		templateUrl: getBaseURL()+"Job_orders"
	})
	.when("/suppliers",{
		templateUrl: getBaseURL()+"Suppliers"
	})
	.when("/reorder",{
		templateUrl: getBaseURL()+"Products/reorder_list"
	})
	.otherwise({
		templateUrl: getBaseURL()+"Content/dashboard"
	});

});

