$(function(){
	product_service('in_cart','');
	product_service('in_reserved','');
	appointment_process('in_appoint','');
});


function notification_process(action,id){
	switch(action){
		case "mark_as_read":
			pre_blocker('on');
			$.ajax({
				url: getBaseURL()+"Notifications/process",
				type: "POST",
				data:{'action':action,'id':id},
				success:function(data){
					$("#status_here_"+id).html('Read');
					$("#notice_here_"+id).html('<button class="btn btn-primary" onclick="notification_process(\'mark_as_read\',\''+id+'\')"><i class="fa fa-check"></i> Mark as Unread</button>');
					location.reload();
					pre_blocker('off');

				}
			});
		break;

		case "mark_as_unread":
					pre_blocker('on');
			$.ajax({
				url: getBaseURL()+"Notifications/process",
				type: "POST",
				data:{'action':action,'id':id},
				success:function(data){
					$("#status_here_"+id).html('Unread');
					$("#notice_here_"+id).html('<button class="btn btn-success" onclick="notification_process(\'mark_as_read\',\''+id+'\')"><i class="fa fa-check"></i> Mark as Read</button>');
					 notifications();
					pre_blocker('off');
				}
			});
		break;
	}
}

function appointment_process(action,id){

	switch(action){

		case "resched":
			service_process('add_services','');
			$app_date = $("#app_date_"+id).html();
			$app_time = $("#app_time_"+id).html();
				
				$("#resched_id").val(id);
				$("#app_date").val($app_date);
				$("#app_time").val($app_time);

				$(".modal-title").text('Service: '+$("#service_name_"+id).html());
		break;

		case "in_appoint":
			$.ajax({
				url: getBaseURL()+"Appointments/lists",
				type: "POST",
				success:function(data){
					data = $.parseJSON(data);
					if(data.length!=0){
						$("#appointments_here").html('Appointments<span id="list_appointment"> ('+data.length+')</span>');
					}
				}
			});
		break;

		case "remove":

			if(confirm('Are you sure to remove this appointment?')){		
				$.ajax({
					url: getBaseURL()+"Appointments/process",
					type: "POST",
					data:{'action':action,'appointment_id':id},
					success:function(data){

						if(data == "success"){
							$("#inline_"+id).remove();
							appointment_process('in_appoint','');
						}//end of if
						else{
								$message = "Error encountered while trying to remove appointment";
								up_note($message);
						}
									// product_service('in_cart','');
									// product_service('in_reserved','');
									pre_blocker('off');
					},//end of success callback
					error:function(data){
						pre_blocker('off');
						up_note("Error encountered while trying to remove appointment");
					}
				});
			}	

		break;

		case "save":

			$from_hour = $("#business_hour_from").val();
			$from_min = $("#business_min_from").val();
			$to_hour = $("#business_hour_to").val();
			$to_min = $("#business_min_to").val();

		    $selected_hour = $("#selected_hour").val();
		    $selected_minute = $("#selected_minute").val();

		    console.log('Opens @:'+$from_hour+':'+$from_min+' Close @: '+$to_hour+':'+$to_min)
		    console.log('Selected Hour: '+$selected_hour+' Selected Minute: '+$selected_minute)

		    if(parseInt($selected_hour) < parseInt($from_hour)){
		    	up_note('Shop is not open at that time!');
		    }
		    else if(parseInt($selected_hour) >= parseInt($to_hour)){
		    	up_note('Shop is close at that time!');
		    }else{

		    	 if($selected_hour == "13"){
			        $return = "01";
			      }
			      else if($selected_hour == "14"){
			        $return = "02";
			      }
			      else if($selected_hour == "15"){
			        $return = "03";
			      }
			      else if($selected_hour == "16"){
			        $return = "04";
			      }
			      else if($selected_hour == "17"){
			        $return = "05";
			      }
			      else if($selected_hour == "18"){
			        $return = "06";
			      }
			      else if($selected_hour == "19"){
			        $return = "07";
			      }
			      else if($selected_hour == "20"){
			        $return = "08";
			      }
			      else if($selected_hour == "21"){
			        $return = "09";
			      }
			      else if($selected_hour == "22"){
			        $return = "10";
			      }
			      else if($selected_hour == "23"){
			        $return = "11";
			      }
			      else if($selected_hour == "24"){
			        $return = "12";
			      }
			      else{
			        $return = $selected_hour;
			      }


		    	if($selected_hour >=12){
		          $meridan = "pm";
		        }else{
		          $meridan = "am";
		        }

		    			pre_blocker('on');
						$shop_id = $("#shop_id").val();
						$resched_id = $("#resched_id").val();
						$app_date = $("#app_date").val();
						$service_id = id;
						$app_time = ""+$return+":"+$selected_minute+""+$meridan+"";
				
						$.ajax({
							url: getBaseURL()+"Appointments/process",
							type: "POST",
							data:{'action':action,'shop_id':$shop_id,'app_date':$app_date,'app_time':$app_time,'service_id':$service_id,'resched_id':$resched_id},
							success:function(data){
								if($resched_id!=""){

									location.reload();
										
								}else{

									if(data == "success"){
										$message = 'Successfully added appointments';
										appointment_process('in_appoint','');
									}//end of if
									else{
											$message = "Error encountered while trying to save appointment";
									}
									pre_blocker('off');
									$("#close_modal").click();
									up_note($message);
								}

							},//end of success callback
							error:function(data){
								pre_blocker('off');
								up_note("Error encountered while trying to save appointment");
							}
						});

		    }

		


		break;


	}//end of switch

}

function service_process(action,id){
	switch(action){

		case "add_services":
		 if(current_user('validate')){

		$("#appended_minutes").remove();
				$shop_id = $("#shop_id_"+id).val();
				$service_name = $("#service_name_"+id).html();
				$(".modal-title").text('Service: '+$service_name);
				$(".modal-body").html('<div class="container"><div class="row">\n\
				 <div class="col-md-10"><form class="form-horizontal" id="datepairExample">\n\
  					<div class="form-group">\n\
				    	<input type="hidden" value="'+$shop_id+'" id="shop_id">\n\
				    	<input type="hidden" id="resched_id">\n\
				    	<label for="email">Date:</label>\n\
				    	<input style="width:59%;" type="text" class="form-control date start" id="app_date">\n\
				  	</div>\n\
  					<div class="form-group">\n\
				    	<div class="row"><div class="col-md-4"><strong>Schedule Time:</strong><br>\n\
    <select id="selected_hour" class="form-control"><option value="24">12:00AM</option>\n\
    <option value="01">1:00AM</option>\n\
    <option value="02">2:00AM</option>\n\
    <option value="03">3:00AM</option>\n\
    <option value="04">4:00AM</option>\n\
    <option value="05">5:00AM</option>\n\
    <option value="06">6:00AM</option>\n\
    <option value="07">7:00AM</option>\n\
    <option value="08">8:00AM</option>\n\
    <option value="09">9:00AM</option>\n\
    <option value="10">10:00AM</option>\n\
    <option value="11">11:00AM</option>\n\
    <option value="12">12:00PM</option>\n\
    <option value="13">1:00PM</option>\n\
    <option value="14">2:00PM</option>\n\
    <option value="15">3:00PM</option>\n\
    <option value="16">4:00PM</option>\n\
    <option value="17">5:00PM</option>\n\
    <option value="18">6:00PM</option>\n\
    <option value="19">7:00PM</option>\n\
    <option value="20">8:00PM</option>\n\
    <option value="21">9:00PM</option>\n\
    <option value="22">10:00PM</option>\n\
    <option value="23">11:00PM</option></select></div><div class="col-md-3"><br><select id="selected_minute" class="form-control"></select>\n\
    </div></div><br><div id="business_hours"></div></div>\n\
				  </form>\n\
				 </div></div></div>');
				
				$(".modal-footer").html('<button type="button" class="btn btn-success" onclick="appointment_process(\'save\',\''+id+'\')"><i class="fa fa-paper-plane"></i> Save Appointment</button>');
		for(var i=0; i < 62; i++){
          if(i <=9 && i >=1){
            $min = "0"+i;
          	$min2 = i;
          }else if(i == 0){
            $min = "00";
            $min2 = "00";
          }else{
          	$min2 = i;
            $min = i;
          }
          $("#selected_minute").append('<option class="appended_minutes" value="'+$min2+'">'+$min+'</option>');  
        }
        $("#business_hours").html($("#business_hours_"+id).html());
				datetime_picker();	
				$("#g_modal").modal();

		 }else{
          current_user('logged_in');
      	}

		break;
	}	
}


function product_service(action,id){

	switch(action){

				case "move_item":
					if(confirm('Are you sure to move this item?')){
						pre_blocker('on');
						$current_module = $("#current_module").val();
						$.ajax({
							url: getBaseURL()+"Products/move_item",
							type: "POST",
							data:{'action':$current_module,'product_id':id},
							success:function(data){

								if(data == "success"){
										switch($current_module){
											case "my_cart":
												$message = "Successfully moved to reservation";								
											break;
											case "reservation":
												$message = "Successfully removed to cart";
											break;
										}//end of switch
										$("#inline_"+id).remove();
									}//end of if
									else{
										$message = "Error encountered while trying to add item";
									}
											// product_service('in_cart','');
											// product_service('in_reserved','');
											pre_blocker('off');
											location.reload();
											up_note($message);
								}//end of success callback
						});
					}

				break;

				case "remove_item":
					if(confirm('Are you sure to remove this item?')){
						pre_blocker('on');
						$current_module = $("#current_module").val();
						$.ajax({
							url: getBaseURL()+"Products/remove_item",
							type: "POST",
							data:{'action':$current_module,'product_id':id},
							success:function(data){

								if(data == "success"){
										switch($current_module){
											case "my_cart":
												$message = "Successfully removed from cart";								
											break;
											case "reservation":
												$message = "Successfully removed from reservation";
											break;
										}//end of switch
										$("#inline_"+id).remove();
									}//end of if
									else{
										$message = "Error encountered while trying to add item";
									}
											product_service('in_cart','');
											product_service('in_reserved','');
											pre_blocker('off');
											up_note($message);
								}//end of success callback
						});
					}

				break;

				case "cart_reserve":
				$product_id = $("#product_id").val();
				$shop_id = $("#shop_id").val();
				$desired_quantity = $("#desired_quantity").val();
				pre_blocker('on')
				$.ajax({
					url: getBaseURL()+"Products/cart_reserve",
					type: "POST",
					data:{'action':id,'product_id':$product_id,'shop_id':$shop_id,'desired_quantity':$desired_quantity},
					success:function(data){
						
						if(data == "success"){
							switch(id){
								case "my_cart":
									$message = "Successfully added to cart";								
								break;
								case "reservation":
									$message = "Item successfully reserved";
								break;
							}//end of switch
						}//end of if
						else{
							$message = "Error encountered while trying to add item";
						}
								product_service('in_cart','');
								product_service('in_reserved','');
								$("#close_modal").click();
								pre_blocker('off');
								up_note($message);
					}//end of success callback
				});


				break;

				case "calculate_due":

					$discount = $("#discount").html();
					$price = id;
					$desired_quantity = $("#desired_quantity").val();
					$qty  = $("#qty").html();

					// if($desired_quantity == ""){
					// 	$desired_quantity = 0;
					// 	$("#qty").html($qty);
					// }

					// $("#qty").html(parseFloat($qty) - parseFloat($desired_quantity));

					$multi = parseFloat($price) * parseFloat($desired_quantity);
					$amount_due = $multi - parseFloat($discount);
					// console.log('Price: '+$price+' Discount:'+$discount+' Qty:'+$desired_quantity);
					// console.log('Multi: '+$multi+' Discounted:'+$amount_due);
					$("#product_amount_due").html($amount_due);

				break;

				case "add_to_cart":
					if(current_user('validate')){
							console.log(id);
							pre_blocker('on');
							$.ajax({
							url: getBaseURL()+"Products/lists",
							type: 'post',
							data:{'product_id':id},
							success:function(data){
								data = $.parseJSON(data);

								$gender = data[0]['gender'];
								if($gender =="0"){
									$sex="Male";
								}else{
									$sex="Female";
								}

									$(".modal-title").text(data[0]['name']);
									$(".modal-body").html('<div class="row" class="product_details">\n\
							    	<div class="col-md-2">\n\
							    	<img src="'+getBaseURL()+'assets/'+data[0]['optprod_img']+'">\n\
							    	</div>\n\
							    	<div class="col-md-5">\n\
								    	<label>Gender:</label> <span id="gender">'+$sex+'</span>\n\
								    	<br>\n\
								    	<label>Model:</label> <span id="model">'+data[0]['model']+'</span>\n\
								    	<br>\n\
								    	<label>Brand:</label> <span id="brand">'+data[0]['brand']+'</span>\n\
								    	<br>\n\
								    	<label>Available Qty:</label> <span id="qty" style="color:green;font-weight:bold;">'+data[0]['qty']+'</span>\n\
								    	<br>\n\
								    	<label>Discount:</label> <span id="discount">'+data[0]['discount']+'</span>\n\
								    	<br>\n\
								    	<label>Price:</label> <span id="price">'+data[0]['price']+'</span>\n\
								    	<br>\n\
								    	<label>Material:</label> <span id="material">'+data[0]['material']+'</span>\n\
								    	<br>\n\
							    	</div>\n\
							    	<div class="col-md-5">\n\
										\n\
								    	<label>Lens Type:</label> <span id="lens_type">'+data[0]['lens_type']+'</span>\n\
								    	<br>\n\
								    	<label>Lens Size:</label> <span id="lens_size">'+data[0]['lens_size']+'</span>\n\
								    	<br>\n\
								    	<label>Rim:</label> <span id="rim">'+data[0]['rim']+'</span>\n\
								    	<br>\n\
								    	<label>Frame Color:</label> <span id="frame_color">'+data[0]['frame_color']+'</span>\n\
								    	<br>\n\
								    	<label>Frame Shape:</label> <span id="frame_shape">'+data[0]['frame_shape']+'</span>\n\
								    	<br>\n\
								    	<label>Volume:</label> <span id="volume">'+data[0]['volume']+'</span>\n\
								    	<br>\n\
								    	<label>Description:<br> \n\
								    	'+data[0]['description']+'\n\
								   \n\
							    	</div></div>\n\
							    	<hr>\n\
							    	<div class="row">\n\
							    		<input type="hidden" id="product_id" value="'+data[0]['optprod_id']+'">\n\
							    		<input type="hidden" id="shop_id" value="'+data[0]['optshop_id']+'">\n\
							    		<div class="col-md-6">\n\
							    		 	<label>Purchased Quantity: <input type="text" id="desired_quantity" onkeyup="product_service(\'calculate_due\',\''+data[0]['price']+'\')" class="form-control"></label>\n\
							    		</div>\n\
							    		<div class="col-md-6">\n\
							    		 	<label>Amount Due: <span id="product_amount_due" style="font-weight:bold;color:red;"></span> </label>\n\
							    		</div>\n\
							    	</div>\n\
							    	');
							}	

						});

							$(".modal-footer").html('<button type="button" class="btn btn-primary" onclick="product_service(\'cart_reserve\',\'reservation\')"><i class="fa fa-star-o"></i> Reserve</button> <button type="button" class="btn btn-success" onclick="product_service(\'cart_reserve\',\'my_cart\')"><i class="fa fa-shopping-cart"></i> Add to Cart</button>');


							$("#g_modal").modal();


								pre_blocker('off');
					}else{
			          current_user('logged_in');
			      }			

		break;

		case "in_cart":

			$.ajax({
				url: getBaseURL()+"Products/in_cart",
				type: "POST",
				success:function(data){
					data = $.parseJSON(data);
					if(data.length!=0){
						$("#cart_here").html('<span class="badge" id="items_in_cart">'+data.length+'</span>');
					}
				}
			});

		break;

		case "in_reserved":

			$.ajax({
				url: getBaseURL()+"Products/in_reserved",
				type: "POST",
				success:function(data){
					data = $.parseJSON(data);
					if(data.length!=0){
						$("#reserve_here").html('<span class="badge" id="items_in_reserved">'+data.length+'</span>');
					}
				}
			});

		break;
	}
}



function insert_signup(){

	$selected_sign_up_tab = $("#selected_sign_up_tab").val();
	$email = $("#email").val();
	$pwd = $("#pwd").val();
	$custo_first = $("#custo_first").val();
	$custo_middle = $("#custo_middle").val();
	$custo_last = $("#custo_last").val();
	$custo_gender = $('input[type="radio"][name=custo_gender]:checked').val();
	$shop_name = $("#shop_name").val();
	$shop_add = $("#shop_add").val();
	$shop_contact = $("#shop_contact").val();
	$email2 = $("#email2").val();
	$pwd2 = $("#pwd2").val();
	$shop_from_hours = $("#shop_from_hours").val();
	$shop_from_minutes = $("#shop_from_minutes").val();
	$shop_to_hours = $("#shop_to_hours").val();
	$shop_to_minutes = $("#shop_to_minutes").val();



	if($selected_sign_up_tab=="1"){
		$custo_gender="";
		$email = $email2;
		$pwd = $pwd2;
	}

	var sign_up_attributes = {
								selected_sign_up_tab: $selected_sign_up_tab,
								email: $email,
								pwd: $pwd,
								custo_first: $custo_first,
								custo_middle: $custo_middle,
								custo_last: $custo_last,
								custo_gender: $custo_gender,
								shop_name: $shop_name,
								shop_add: $shop_add,
								shop_contact: $shop_contact,
								shop_from_hours: $shop_from_hours,
								shop_from_minutes: $shop_from_minutes,
								shop_to_hours: $shop_to_hours,
								shop_to_minutes: $shop_to_minutes,
							 }
	console.log(sign_up_attributes);						 
    pre_blocker('on');								 
	$.ajax({
		url: getBaseURL()+"Web/sign_up/",
		type: "POST",
		data:{'sign_up_attributes':sign_up_attributes},
		success:function(data){	

				if(data =="success"){
					close_modal();
					$message = "Successfully Registered";
				}else{
					$message = "Error while trying to register.";
				}
				up_note($message);
				pre_blocker('off');
		},error:function(data){
				up_note(data);
			    pre_blocker('off');
			    close_modal();
		}
	});//end of ajax			 

		
}

function do_signin(){
	pre_blocker('on');
	$signin_email = $("#signin_email").val();
	$signin_pwd = $("#signin_pwd").val();
	$choose_access = $('input[type="radio"][name=choose_access]:checked').val();

	var signin_attr =  {
						action : "web",
						signin_email : $signin_email,
						signin_pwd : $signin_pwd,
						choose_access : $choose_access
					}
	$.ajax({
		url: getBaseURL()+"Web/sign_in",
		type: "POST",
		data: {'signin_attr':signin_attr},
		success:function(data){
				console.log(data);
				if(data =="success"){
						close_modal();
						location.reload();
				}else if(data == "deactivate"){
					$message = "You are unable to pay your subscription. Account Deactivated!";
					up_note($message);
					pre_blocker('off');
				}else{
					$message = "Invalid Username/Password. Please try again.";
					up_note($message);
					pre_blocker('off');
				}


		},error:function(data){
				up_note('Error encountered while trying to sign in..');
				pre_blocker('off');
		}		
	})						

}
	

function current_user(action){

	switch(action){
		case "validate":
			$user = $("#current_user").val();
			if($user!=""){
				return true;
			}else{
				return false;
			}
		break;
		case "logged_in":
				$(".modal-title").text("Sign In");
				$(".modal-body").html('<form class="form-horizontal"><div class="form-group">\n\
				<label class="control-label col-sm-2" for="email">Email:</label>\n\
				<div class="col-sm-10">\n\
				<input type="email" class="form-control" id="signin_email">\n\
				</div>\n\
				</div>\n\
				\n\
				<div class="form-group">\n\
				<label class="control-label col-sm-2" for="pwd">Password:</label>\n\
				<div class="col-sm-10"> \n\
				<input type="password" class="form-control" id="signin_pwd">\n\
				</div>\n\
				</div>\n\
				<div class="form-group">\n\
				<label class="control-label col-sm-2" for="pwd">Access:</label>\n\
				<div class="col-sm-10"> \n\
				<label class="radio-inline"><input id="choose_access" type="radio" name="choose_access" value="0">Customer/Patient</label>\n\
				<label class="radio-inline"><input id="choose_access" type="radio" name="choose_access" value="1">Optical Owner</label>\n\
				<label class="radio-inline"><input id="choose_access" type="radio" name="choose_access" value="2">Staff</label>\n\
				</div>\n\
				</div>\n\
				\n\
				</form>');
				$(".modal-footer").html('<button type="submit" class="btn btn-success" onclick="do_signin()">Sign in</button>');


				$("#g_modal").modal();
		break;
	}
}	