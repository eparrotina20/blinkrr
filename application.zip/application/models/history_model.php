<?php

Class History_model extends CI_Model{

	function __construct(){
		$this->load->database();
		$this->load->model('Content_model','CM');
	}

	function history_list(){

		$patient_id = $this->input->post('patient_id');
		$pathis_id = $this->input->post('pathis_id');
		$sess_id = $this->session->userdata('sess_id');
		$sess_access = $this->session->userdata('sess_access');

		if($sess_access == "1" || $sess_access == "3" || $sess_access == "4"){

			if(!empty($pathis_id)){
				$where = "pt.pathis_id='$pathis_id'";
			}else{
				$shop_id = $this->CM->find_shop();
				$where = "es.optshop_id='$shop_id'";
			}
		
		}else{

			if(empty($patient_id)){
				$patient = $sess_id;
			}else{
				$patient =  $patient_id;
			}
			$where = "pt.patient_id='$patient'";
		}	

		$query = $this->db->query("SELECT pt.pathis_id,pt.status,pt.patient_id,pt.emp_id,pt.date,pt.od_sphere,pt.od_cylinder,pt.od_axis,pt.od_rdg_add,pt.os_sphere,pt.os_cylinder,pt.os_axis,pt.os_rdg_add,pt.pat_complain,pt.diagnosis,pt.prescription,pt.amount,pt.discount_id,pt.discounted_amount,pt.balance_insurance,pt.balance,es.emp_id as id_employee,es.fname,es.optshop_id,es.lname,os.optshop_id as shop_id,os.optshop_name FROM patient_history as pt LEFT JOIN employees as es ON es.emp_id=pt.emp_id LEFT JOIN opt_shops as os ON os.optshop_id=es.optshop_id WHERE $where ");
		$this->CM->result_encode($query);
	}















}//end of class