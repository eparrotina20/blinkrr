<?php 


Class Report_model extends CI_Model{


	function __construct(){
		$this->load->database();
		$this->load->model('Content_model','CM');
	}

	function record_list(){

		$action = $this->input->post('action');

		switch($action){
			
			case "patients":

				$query = $this->db->query("SELECT last_name,first_name,contactNo,gender,civil_status,DOB,address FROM patient");
			break;

			case "owners":
				$query = $this->db->query("SELECT last_name,first_name,contactNo,gender,civil_status,DOB,address FROM owner");
			break;

			case "subscriptions":
				$query = $this->db->query("SELECT sn.subs_id,sn.optshop_id,sn.subs_plan_id,sn.sdate,sn.edate,sn.paymentAmt,sn.status,os.optshop_id,os.optshop_name,sp.term,sp.amount FROM subscription as sn LEFT JOIN opt_shops as os ON os.optshop_id=sn.optshop_id LEFT JOIN subs_plan as sp ON sp.subs_plan_id=sn.subs_plan_id");
			break;

			case "inventory":

				$shop_id = $this->CM->find_shop();
				$shopz = " AND os.optshop_id='$shop_id'";

				$query = $this->db->query("SELECT os.lens_size,os.optprod_id,os.name,os.gender,os.optshop_id,os.type_id as os_type,os.model,os.description,os.brand,os.qty,os.reserved_qty,os.reorder,os.discount,os.price,os.optprod_img,os.status,os.material,os.lens_type,os.rim,os.frame_color,os.frame_shape,os.volume,te.type_id as id_type,te.name as type_name,opt.optshop_name FROM opt_products as os LEFT JOIN type as te on te.type_id=os.type_id LEFT JOIN opt_shops as opt ON opt.optshop_id=os.optshop_id WHERE os.status='Available' ".$shopz."");

			break;

			case "shops":
				$sess_access = $this->session->userdata('sess_access');
				$sess_id = $this->session->userdata('sess_id');
				
				if($sess_access == 1){
					$where = " AND owner_id='".$sess_id."'";
				}else{
					$where = "";
				}

				$query = $this->db->query("SELECT * FROM opt_shops WHERE optshop_status='Active' ".$where."");
			break;

		}//end of switch

		$this->CM->result_encode($query);
	}








}