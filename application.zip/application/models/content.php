<?php

Class Content extends CI_Controller{

	function __construct(){

		parent::__construct();
		$this->load->model("Content_model","CM");
		$this->load->library('globalcall');
	}

	function index(){
			$data['page_title'] = "Dashboard";
			$data['other_call'] = "global_modal";
			$data['set_scripts'] = array('system/js/content.js','system/js/content_process.js');

			$this->globalcall->content_upper_call($data);
			$this->load->view('content/index');
			$this->globalcall->content_lower_call($data);	
	}


	function dashboard(){
		echo"This is dashboard";
	}

	function logout(){

		$this->session->sess_destroy();
		redirect(base_url());
	}










}//end of class