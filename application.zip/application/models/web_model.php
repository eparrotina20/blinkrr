<?php 

class Web_model extends CI_Model{

	function __construct(){
		$this->load->database();
		$this->load->model('Content_model','CM');
	}

	function update_profile(){
		$profile_attr = $this->input->post("profile_attr");
		$first_name = $profile_attr['first_name'];
		$middle_name = $profile_attr['middle_name'];
		$last_name = $profile_attr['last_name'];
		$contactNo = $profile_attr['contactNo'];
		$email = $profile_attr['email'];
		$pw = $profile_attr['pw'];
		$address = $profile_attr['address'];
		$dob = $profile_attr['dob'];
		$civil_status = $profile_attr['civil_status'];

		$user_id = $this->session->userdata('sess_id');

		$save_attr = array(
			'first_name' => $first_name,
			'middle_name' => $middle_name,
			'last_name' => $last_name,
			'contactNo' => $contactNo,
			'email' => $email,
			'pw' => $pw,
			'address' => $address,
			'DOB' => $dob,
			'civil_status' => $civil_status
		);

		$this->db->where('patient_id',$user_id);
		$query = $this->db->update('patient',$save_attr);

		if($query){
			return TRUE;
		}else{
			return FALSE;
		}

	}	

	function profile_get(){

		$user_id = $this->session->userdata('sess_id');
		$query = $this->db->query("SELECT * FROM patient WHERE patient_id='$user_id'");
		$this->CM->result_encode($query);
	}

	function optical_list(){
		$query = $this->db->query("SELECT * FROM opt_shops WHERE optshop_status='Active'");
		$this->CM->result_encode($query);
	}

	function insert_sign_up(){
			$sign_up_attributes = $this->input->post("sign_up_attributes");

			$selected_sign_up_tab = $sign_up_attributes['selected_sign_up_tab']; // 0 - Customer |  1 - Shop
			$email = $sign_up_attributes['email'];
			$pwd = $sign_up_attributes['pwd'];
			$custo_first = $sign_up_attributes['custo_first'];
			$custo_middle = $sign_up_attributes['custo_middle'];
			$custo_last = $sign_up_attributes['custo_last'];
			$custo_gender = $sign_up_attributes['custo_gender'];
			$shop_name = $sign_up_attributes['shop_name'];
			$shop_add = $sign_up_attributes['shop_add'];
			$shop_contact = $sign_up_attributes['shop_contact'];
			$shop_from_hours = $sign_up_attributes['shop_from_hours'];
			$shop_from_minutes = $sign_up_attributes['shop_from_minutes'];
			$shop_to_hours = $sign_up_attributes['shop_to_hours'];
			$shop_to_minutes = $sign_up_attributes['shop_to_minutes'];
	   switch($selected_sign_up_tab){
	   		
	   		case "0":
			   		$insert_customer = array(
			   			'email' => $email,
			   			'pw' => $pwd,
			   			'last_name' => $custo_last,
			   			'first_name' => $custo_first,
			   			'middle_name' => $custo_middle,
			   			'gender' => $custo_gender,
			   			'status' => 'Active'
			   		);

			   	$qry = $this->db->insert('patient',$insert_customer);

			if($qry){
				return TRUE;
			}else{
				return FALSE;
			}

			break;  

			case "1":

				$insert_owner = array(
			   			'email' => $email,
			   			'pw' => $pwd,
			   			'status' => 'Active'
			   		);

			   	$qry = $this->db->insert('owner',$insert_owner);

			   	$last_id = $this->db->insert_id();

			   	$insert_shop = array(
			   		'owner_id' => $last_id,
			   		'optshop_name' => $shop_name,
			   		'optshop_add' => $shop_add,
			   		'optshop_tel' => $shop_contact,
					'optshop_img'	=> "images/default_glass.png",
					'optshop_from_hour'	=> $shop_from_hours,
					'optshop_from_min'	=> $shop_from_minutes,
					'optshop_to_hour'	=> $shop_to_hours,
					'optshop_to_min'	=> $shop_to_minutes,
					'created_at' => date('Y-m-d')
			   		);
			   	$qry_shop = $this->db->insert('opt_shops',$insert_shop);

			   	$shop_id = $this->db->insert_id();

			   	$due_date = date('Y-m-d', strtotime('+2 months'));
			   	$save_payment = array(
			   		'shop_id' => $shop_id,
			   		'payment' => 0,
			   		'due_date' => $due_date,
			   		'remarks' => 'Trial',
			   		'date_paid' => date('Y-m-d'),
			   		'status' => '1'
			   	);
			   	$this->db->insert('subscription_payments',$save_payment);


				$next_due_date = date('Y-m-d', strtotime($due_date. ' + 1 month'));
				$next_due_date2 = date('Y-m-d', strtotime($next_due_date. ' + 15 days'));

				$save_array3 = array(
					'shop_id' => $shop_id,
					'payment' => '500',
					'remarks' => 'For Payment',
					'due_date' => $next_due_date
				);

				$this->db->insert('subscription_payments',$save_array3);


			if($qry){
				return TRUE;
			}else{
				return FALSE;
			}


			break; 		

	   }//end of switch

	}//end of fucntion


	function in_sign(){

		$signin_attr = $this->input->post('signin_attr');
		$signin_email = $signin_attr['signin_email'];
		$action = $signin_attr['action'];
		$signin_pwd = $signin_attr['signin_pwd'];
		$choose_access = $signin_attr['choose_access'];
		

	switch($action){
		case "web":
				switch($choose_access){
					case "0": //Customer
						$tbl = "patient";
						$pass = "pw";
					break;

					case "1"://optical
						$tbl = "owner";
						$pass = "pw";
					break;

					case "2"://optical
						$tbl = "employees";
						$pass = "password";
					break;
				}//end of case


				$query = $this->db->get_where($tbl,array('email'=>$signin_email,''.$pass.''=>$signin_pwd));			
				if($query->num_rows() > 0){

					$row = $query->row_array();
					if($choose_access == "2"){
						
						$type = $row['position'];
						$id = $row['emp_id'];
							
							if($type == "Admin"){
								$access = "2";
							
							}elseif($type=="Staff"){

								$access = "3";
							
							}elseif($type=="Optometrist"){
								$access = "4";
							}

					}elseif($choose_access == "0"){
						$id = $row['patient_id'];
						$access = $choose_access;

					}elseif($choose_access == "1"){
						$id = $row['owner_id'];
						$access = $choose_access;
					}

						$this->create_session($id,$signin_email,$signin_pwd,$access);
					
					return TRUE;

				}else{
					return FALSE;
				}
		break;

		case "mobile":

				$tbl = "patient";
						$pass = "pw";
				$query = $this->db->get_where($tbl,array('email'=>$signin_email,''.$pass.''=>$signin_pwd));			
				if($query->num_rows() > 0){
					return $query->result_array();					
				}else{
					return FALSE;
				}

		break;
	}	

	}//end of function

	function create_session($id,$email,$pwd,$access){
		$sess_array = array(
			'sess_id' =>$id,
			'sess_email' =>$email,
			'sess_pwd' => $pwd,
			'sess_access' => $access
			);

		$this->session->set_userdata($sess_array);

	}


	function shop_products(){
		$shop_id = $this->input->post('shop_id');
		$query = $this->db->query("SELECT * FROM opt_products WHERE optshop_id='$shop_id'");
		return $query->result_array();
	}



	function shop_services(){
		$shop_id = $this->input->post('shop_id');
		$query = $this->db->query("SELECT * FROM services WHERE optshop_id='$shop_id'");
		return $query->result_array();
	}





























}//end of class