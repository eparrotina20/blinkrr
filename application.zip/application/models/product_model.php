<?php 

Class Product_model extends CI_Model{


	function __construct(){
		$this->load->database();
		$this->load->model('Content_model','CM');
	}

	function reorder_list(){
		$sess_access = $this->session->userdata('sess_access');
		$sess_id = $this->session->userdata('sess_id');
		if($sess_access =="3"){
			$shop_id =  $this->CM->get_shop_emp($sess_id);
		}else{
			$shop_id = $this->CM->find_shop();
		}

		$query = $this->db->query("SELECT os.supplier_id,os.lens_size,os.optprod_id,os.name,os.gender,os.optshop_id,os.type_id as os_type,os.model,os.description,os.brand,os.qty,os.reserved_qty,os.reorder,os.discount,os.price,os.optprod_img,os.status,os.material,os.lens_type,os.rim,os.frame_color,os.frame_shape,os.volume,te.type_id as id_type,te.name as type_name,opt.optshop_name FROM opt_products as os LEFT JOIN type as te on te.type_id=os.type_id LEFT JOIN opt_shops as opt ON opt.optshop_id=os.optshop_id WHERE os.status='Available' AND os.optshop_id='$shop_id' AND os.qty <= os.reorder");
		$this->CM->result_encode($query);
	}

	function item_moved(){
		$action = $this->input->post('action');
		$product_id = $this->input->post('product_id');

		$query = $this->db->query("SELECT id,optprod_id,qty,patient_id,optshop_id FROM $action");
		foreach($query->result_array() as $row){
			$id = $row['id'];
			$product_id2 = $row['optshop_id'];
			$patient_id = $row['patient_id'];
			$optshop_id = $row['optshop_id'];
			$qty = $row['qty'];
		
			if($action =="my_cart"){
				$target = "reservation";
			}elseif($action =="reservation"){
				$target = "my_cart";
			}

			$find = $this->db->query("SELECT qty,id,optprod_id FROM $target WHERE optprod_id='$product_id'");
			if($find->num_rows() > 0){//product found
				foreach($find->result_array() as $row2){
					$find_id = $row2['id'];
					$origin = $row2['qty'];
					$new_qty = $origin + $qty;

					$update_array = array(
						'optshop_id' => $optshop_id,
						'optprod_id' => $product_id,
						'qty' => $new_qty,
						'patient_id' => $patient_id
					);

					$this->db->where('id',$find_id);
					$query = $this->db->update("".$target."",$update_array);
				}//end of foreach
			}else{//no product found

					$update_array = array(
						'optshop_id' => $optshop_id,
						'optprod_id' => $product_id,
						'qty' => $qty,
						'patient_id' => $patient_id
					);

				$query = $this->db->insert(''.$target.'',$update_array);
			}

			if($query){
				$this->db->where('id',$id);
				$this->db->delete(''.$action.'');
				return TRUE;
			}else{
				return FALSE;
			}

		}//end of foreach

	}


	function item_removed(){
		$action = $this->input->post('action');
		$product_id = $this->input->post('product_id');

		$query = $this->db->query("SELECT id,optprod_id,qty FROM ".$action." WHERE optprod_id='$product_id'");
		foreach($query->result_array() as $row){
			$origin = $row['qty'];
			$id = $row['id'];
			$plus = $this->less_product('plus',$product_id,$origin);
			if($plus){
				$remove = $this->db->delete(''.$action.'',array('id'=>$id));
				if($remove){
					return TRUE;
				}else{
					return FALSE;
				}
			}else{
				return FALSE;
			}

		}

	}

	function cart_reserve(){
		$action = $this->input->post('action');
		$optshop_id = $this->input->post('shop_id');
		$optprod_id = $this->input->post('product_id');
		$qty = $this->input->post('desired_quantity');
		$patient_id = $this->session->userdata('sess_id');

		$find_product = $this->db->query("SELECT id,optprod_id,qty FROM $action WHERE optprod_id='$optprod_id'");
		$num = $find_product->num_rows();
		if($num > 0){
			foreach($find_product->result_array() as $row){
				$origin = $row['qty'];
				$new_qty = $origin + $qty;
				$unique_id = $row['id'];

				$update_array = array(
					'optshop_id' => $optshop_id,
					'optprod_id' => $optprod_id,
					'qty' => $new_qty,
					'patient_id' => $patient_id,
					'sdate' => date('Y-m-d')
				);

				$this->db->where('id',$unique_id);
				$query = $this->db->update(''.$action.'',$update_array);
				if($action!="my_cart"){
					$this->CM->make_notice($patient_id,$optshop_id,'Product Reservation','Customer reserved a product');
				}
			}//end of foreach
		}else{//No prodct is found

				$insert_array = array(
					'optshop_id' => $optshop_id,
					'optprod_id' => $optprod_id,
					'qty' => $qty,
					'patient_id' => $patient_id,
					'sdate' => date('Y-m-d')
				);
				
				$query = $this->db->insert(''.$action.'',$insert_array);
				if($action!="my_cart"){
					$this->CM->make_notice($patient_id,$optshop_id,'Product Reservation','Customer reserved a product');
				}
		}

		
		if($query){
			$this->less_product('less',$optprod_id,$qty);
			return TRUE;
		}else{
			return FALSE;
		}
		
	}

	function less_product($action,$item_id,$qty){

			$query = $this->db->query("SELECT optprod_id,qty FROM opt_products WHERE optprod_id='$item_id'");
			foreach($query->result_array() as $row){
				$origin = $row['qty'];

				switch($action){
					case "less":
						$new_qty = $origin - $qty;
					break;

					case "plus":
						$new_qty = $origin + $qty;
					break;
				}//end of switch


				$new_array = array(
					'qty' => $new_qty
					);
				$this->db->where('optprod_id',$item_id);
				$exe = $this->db->update('opt_products',$new_array);
				if($exe){
					return TRUE;					
				}else{
					return FALSE;
				}	

			}//end of foreach
	}


	function cart_products(){

		$sess_id = $this->session->userdata('sess_id');
		$sess_access = $this->session->userdata('sess_access');
		
		if(!empty($sess_id)){
			if($sess_access =="0"){
				$where = "AND rs.patient_id='$sess_id'";
			}else{
				$where = "";
			}


			$query = $this->db->query("SELECT rs.id,rs.qty,rs.patient_id,rs.optprod_id as rs_product,rs.status,os.optprod_id as product_id,os.name,os.optprod_img as product_image,os.brand,os.model,os.price,(rs.qty * os.price) as amount_due FROM my_cart as rs LEFT JOIN opt_products as os ON os.optprod_id=rs.optprod_id WHERE rs.status='Pending' $where");
			$this->CM->result_encode($query);
		}
		
	}

	function reserved_products(){

		$sess_id = $this->session->userdata('sess_id');
		$sess_access = $this->session->userdata('sess_access');
		
		if(!empty($sess_id)){
			if($sess_access =="0"){
				$where = "AND rs.patient_id='$sess_id'";
			}elseif($sess_access == "3" || $sess_access == "1"){
				$shop_id = $this->CM->find_shop();
				$where = "AND rs.optshop_id='$shop_id'";
			}else{
				$where = "";
			}


			$query = $this->db->query("SELECT rs.id,rs.qty,rs.patient_id,rs.optprod_id as rs_product,rs.optshop_id,rs.status,os.optprod_id as product_id,os.name,os.optprod_img as product_image,os.brand,os.model,os.price,(rs.qty * os.price) as amount_due,pt.patient_id,pt.first_name,pt.last_name,opt.optshop_id,opt.optshop_name,pt.status as patient_status FROM reservation as rs LEFT JOIN opt_products as os ON os.optprod_id=rs.optprod_id LEFT JOIN patient as pt ON rs.patient_id=pt.patient_id LEFT JOIN opt_shops as opt ON opt.optshop_id=rs.optshop_id WHERE rs.status='Pending' $where");
			$this->CM->result_encode($query);
		}
	}

	function product_list(){

	$sess_type = $this->session->userdata('sess_access');

	if($sess_type == "1" || $sess_type == "3"){

		$shop_id = $this->CM->find_shop();
		$product_id = $this->input->post('product_id');

		if(empty($product_id)){
			$prodz = "";
		}else{
			$prodz = " AND optprod_id='$product_id'";
		}

		$shopz = " AND os.optshop_id='$shop_id'";
	}

	elseif($sess_type =="0"){
		$product_id = $this->input->post('product_id');
		if(empty($product_id)){
			$prodz = "";
		}else{
			$prodz = " AND optprod_id='$product_id'";
		}
		$shopz = "";
	}

	else{
		$shopz = "";
		$prodz = "";
	}	
		
		$query = $this->db->query("SELECT os.supplier_id,os.lens_size,os.optprod_id,os.name,os.gender,os.optshop_id,os.type_id as os_type,os.model,os.description,os.brand,os.qty,os.reserved_qty,os.reorder,os.discount,os.price,os.optprod_img,os.status,os.material,os.lens_type,os.rim,os.frame_color,os.frame_shape,os.volume,te.type_id as id_type,te.name as type_name,opt.optshop_name FROM opt_products as os LEFT JOIN type as te on te.type_id=os.type_id LEFT JOIN opt_shops as opt ON opt.optshop_id=os.optshop_id WHERE os.status='Available' ".$shopz." ".$prodz."");

		$this->CM->result_encode($query);


	}
	
	function list_type(){
		$query = $this->db->query("SELECT type_id,name FROM type");
		$this->CM->result_encode($query);
	}


	function product_process(){
		error_reporting(0);

		$sess_type = $this->session->userdata('sess_access');
		$sess_id = $this->session->userdata('sess_id');
		if($sess_type =="3"){
			$shop_id = $this->CM->get_shop_emp($sess_id);
		}else{
			$shop_id =  $this->CM->find_shop();
		}

		$action = $this->input->post('action');
		$product_id = $this->input->post('product_id');
		$product_name = $this->input->post('name');
		$product_type = $this->input->post('product_type');
		$gender = $this->input->post('gender');
		$model = $this->input->post('model');
		$brand = $this->input->post('brand');
		$qty = $this->input->post('qty');
		$reserved_qty = $this->input->post('reserved_qty');
		$reorder = $this->input->post('reorder');
		$discount = $this->input->post('discount');
		$price = $this->input->post('price');
		$material = $this->input->post('material');
		$lens_type = $this->input->post('lens_type');
		$lens_size = $this->input->post('lens_size');
		$rim = $this->input->post('rim');
		$frame_color = $this->input->post('frame_color');
		$frame_shape = $this->input->post('frame_shape');
		$volume = $this->input->post('volume');
		$supplier_id = $this->input->post('supplier_id');
		$description = $this->input->post('description');
		$upload_status = $this->input->post('upload_status');

		$remove_avatar = $this->db->query("SELECT optprod_id,optprod_img FROM opt_products WHERE optprod_id='$product_id' AND optprod_img!=''");

							if($upload_status=="dont_upload"){

								if($remove_avatar->num_rows() > 0){
									foreach($remove_avatar->result_array() as $row_avatar) {
									$avatar_location = $row_avatar['optprod_img'];
									
									}//end of foreach
								}//end of inner if
								else{$avatar_location='images/s-img1.jpg';}//end of inner else


						}//end of outer if
						elseif($upload_status=="upload"){

						//DO THIS IF UPDATE
						if(!empty($optshop_id)){
							
							if($remove_avatar->num_rows() > 0){
								foreach($remove_avatar->result_array() as $row_avatar) {
									$location_avatar = $row_avatar['optprod_img'];
								}//end of foreach
							}//end of inner if num rows
						
						 }
						//end of outer if not empty category id				
						//END OF DO THIS IF UPDATE
						$session_id = date('ymdhis');
						$file=$_FILES['file_upload']['tmp_name'];	
						$name=$_FILES['file_upload']['name'];
						$split_point = '.';
						$stringpos = strrpos($name, $split_point, -1);
						$finalstr = substr($name,0,$stringpos);
						$FinalName="".$session_id."_".$finalstr."";

						$image= addslashes(@file_get_contents($_FILES['file_upload']['tmp_name']));
						$image_name= addslashes($_FILES['file_upload']['name']);
						$image_size= @getimagesize($_FILES['file_upload']['tmp_name']);
						$splitName = explode(".", $image_name); //split the file name by the dot
						$fileExt = end($splitName); //get the file extension
						$newFileName  = ucwords($FinalName.'.'.$fileExt); //join file name and ext.
						move_uploaded_file($_FILES["file_upload"]["tmp_name"],"assets/system/images/products/".$newFileName);
				
						$avatar_location="system/images/products/".$newFileName;	

					}//end of outer else if


		switch($action){

			case "save":

			$save_array = array(
					'name' => $product_name,
					'type_id' => $product_type,
					'gender' => $gender,
					'model' => $model,
					'brand' => $brand,
					'qty' => $qty,
					'reserved_qty' => $reserved_qty,
					'reorder' => $reorder,
					'discount' => $discount,
					'price' => $price,
					'material' => $material,
					'lens_type' => $lens_type,
					'lens_size' => $lens_size,
					'rim' => $rim,
					'frame_color' => $frame_color,
					'frame_shape' => $frame_shape,
					'volume' => $volume,
					'description' => $description,
					'optprod_img' => $avatar_location,
					'supplier_id' => $supplier_id,
					'optshop_id' => $shop_id,
					'status'=> 'Available'
				);	

			if(empty($product_id)){//do create

				$query = $this->db->insert('opt_products',$save_array);

			}else{//do udpate
				$this->db->where('optprod_id',$product_id);
				$query = $this->db->update('opt_products',$save_array);
			}

			break;

			case "remove":

				$this->db->where('optprod_id',$product_id);
			$query = $this->db->update('opt_products',array('status'=>'Removed'));	

			break;


		}//end of switch

		if($query){
			return TRUE;
		}else{
			return FALSE;
		}



	}//end of function





}//end of class