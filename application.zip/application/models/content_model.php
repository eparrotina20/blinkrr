<?php

Class Content_model extends CI_Model{


	function __construct(){
		$this->load->database();
		$this->load->model('Notification_model','NM');
	}


	function result_encode($query){
		$arrayindex=array();
			
			foreach($query->result_array() as $r){
			$arrayindex[] = $r;
			}

		echo json_encode($arrayindex);
	}

	function find_shop(){
		$sess_id = $this->session->userdata('sess_id');
		$query = $this->db->query("SELECT owner_id,optshop_id FROM opt_shops WHERE owner_id='$sess_id'");

		foreach($query->result_array() as $row){
			return $row['optshop_id'];
		}
	}

	
	function get_shop_emp($sess_id){
		$query = $this->db->query("SELECT emp_id,optshop_id FROM employees WHERE emp_id='$sess_id'");
		$row = $query->row_array();
		return $row['optshop_id'];
		
	}


	function find_owner($shop_id){
		// $sess_id = $this->session->userdata('sess_id');
		$query = $this->db->query("SELECT owner_id,optshop_id FROM opt_shops WHERE optshop_id='$shop_id'");

		foreach($query->result_array() as $row){
			return $row['owner_id'];
		}
	}

	function make_notice($sender,$receiver,$module,$msg){
		$this->NM->make_notice($sender,$receiver,$module,$msg);
	}










}//end of class