<?php 

Class Employee_model extends CI_Model{


	function __construct(){
		$this->load->database();
		$this->load->model('Content_model','CM');
	}
	

	function get_list(){
		$sess_id = $this->session->userdata('sess_id');
		$sess_access = $this->session->userdata('sess_access');
		$shop_id = $this->CM->find_shop();
		$emp_id = $this->input->post('emp_id');
		$from_job = $this->input->post('from_job');
		$my_shop = $this->CM->get_shop_emp($sess_id);
		
		if($sess_access == "3"){
			$where = "es.optshop_id='$my_shop'";
		}else{

			if(empty($emp_id)){
				$where = "es.optshop_id='$shop_id'";
			}elseif(!empty($from_job)){
				$where = "es.optshop_id='$shop_id' AND es.emp_id = '$emp_id'";
			}
			else{
				$where = "es.emp_id = '$emp_id'";
			}	
		}
		

		$query = $this->db->query("SELECT es.password,es.email,es.emp_id,es.fname,es.mname,es.lname,es.address,es.contact,es.gender,es.civil_status,es.emp_image,es.dob,es.position,es.licenseNo,es.status,os.optshop_id,os.optshop_name FROM employees as es LEFT JOIN opt_shops as os ON os.optshop_id=es.optshop_id WHERE ".$where." AND es.status='Active'AND es.position!='Admin'");
		$this->CM->result_encode($query);
	}


	function get_shop_id($sess_id){
		$query = $this->db->query("SELECT owner_id,optshop_id FROM opt_shops WHERE owner_id='$sess_id'");
		$row = $query->row_array();
		return $row['optshop_id'];
		
	}


	function process(){
		error_reporting(0);
		$sess_id = $this->session->userdata('sess_id');
		$action = $this->input->post('action');
		$emp_id = $this->input->post('emp_id');
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		// $optshop_id = $this->CM->get_shop_emp($sess_id);
		$optshop_id = $this->CM->find_shop();
		$fname = $this->input->post('fname');
		$mname = $this->input->post('mname');
		$lname = $this->input->post('lname');
		$address = $this->input->post('address');
		$contact = $this->input->post('contact');
		$gender = $this->input->post('gender');
		$civil_status = $this->input->post('civil_status');
		$emp_image = $this->input->post('action');
		$DOB = $this->input->post('birthdate');
		$position = $this->input->post('position');
		$licenseNo = $this->input->post('licenseNo');
		$upload_status = $this->input->post('upload_status');
		// status = $this->input->post('action');

		$remove_avatar = $this->db->query("SELECT emp_id,emp_image FROM employees WHERE emp_id='$emp_id' AND emp_image!=''");

							if($upload_status=="dont_upload"){

								if($remove_avatar->num_rows() > 0){
									foreach($remove_avatar->result_array() as $row_avatar) {
									$avatar_location = $row_avatar['emp_image'];
									
									}//end of foreach
								}//end of inner if
								else{$avatar_location='images/default.png';}//end of inner else


						}//end of outer if
						elseif($upload_status=="upload"){

						//DO THIS IF UPDATE
						if(!empty($optshop_id)){
							
							if($remove_avatar->num_rows() > 0){
								foreach($remove_avatar->result_array() as $row_avatar) {
									$location_avatar = $row_avatar['emp_image'];
								}//end of foreach
							}//end of inner if num rows
						
						 }
						//end of outer if not empty category id				
						//END OF DO THIS IF UPDATE
						$session_id = date('ymdhis');
						$file=$_FILES['file_upload']['tmp_name'];	
						$name=$_FILES['file_upload']['name'];
						$split_point = '.';
						$stringpos = strrpos($name, $split_point, -1);
						$finalstr = substr($name,0,$stringpos);
						$FinalName="".$session_id."_".$finalstr."";

						$image= addslashes(@file_get_contents($_FILES['file_upload']['tmp_name']));
						$image_name= addslashes($_FILES['file_upload']['name']);
						$image_size= @getimagesize($_FILES['file_upload']['tmp_name']);
						$splitName = explode(".", $image_name); //split the file name by the dot
						$fileExt = end($splitName); //get the file extension
						$newFileName  = ucwords($FinalName.'.'.$fileExt); //join file name and ext.
						move_uploaded_file($_FILES["file_upload"]["tmp_name"],"assets/system/images/employees/".$newFileName);
				
						$avatar_location="system/images/employees/".$newFileName;	

		}//end of outer else if

		$save_array = array(
			'email' => $email,
			'password' => $password,
			'fname' => $fname,
			'mname' => $mname,
			'lname' => $lname,
			'address' => $address,
			'contact' => $contact,
			'gender' => $gender,
			'civil_status' => $civil_status,
			'position' => $position,
			'licenseNo' => $licenseNo,
			'DOB' => $DOB,
			'emp_image' => $avatar_location,
			'optshop_id' => $optshop_id,
			'status' => 'Active'
			);


		switch($action){

			case "save":

				if(empty($emp_id)){//do insert
					$query = $this->db->insert('employees',$save_array);
				}else{//do update
						 $this->db->where('emp_id',$emp_id);
				$query = $this->db->update("employees",$save_array);

				}
			break;

			case "remove":
						 $this->db->where('emp_id',$emp_id);
				$query = $this->db->update("employees",array('status'=>'Inactive'));
			break;
		}

		if($query){
			return TRUE;
		}else{
			return FALSE;
		}

	}




















}//end of class