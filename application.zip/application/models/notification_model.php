<?php 

Class Notification_model extends CI_Model{


	function __construct(){
		$this->load->database();
		$this->load->model('Content_model','CM');
	}
	
	function only_notice(){
		$sess_id = $this->session->userdata('sess_id');
		$query = $this->db->query("SELECT * FROM notifications WHERE receiver='$sess_id' AND status='0'");
		$this->CM->result_encode($query);
	}


	function notification_list(){

		$sess_access = $this->session->userdata('sess_access');

		switch($sess_access){
			case "0":

				$sess_id = $this->session->userdata('sess_id');
				$query = $this->db->query("SELECT ns.id,ns.sender,ns.receiver,ns.module,ns.date_send,ns.status,ns.message,os.optshop_id,os.optshop_name FROM notifications as ns LEFT JOIN opt_shops as os ON os.optshop_id=ns.sender WHERE ns.receiver='$sess_id'");
	
			break;

			case "1":
				$sess_id = $this->CM->find_shop();
				$query = $this->db->query("SELECT ns.id,ns.sender,ns.receiver,ns.module,ns.date_send,ns.status,ns.message,pt.patient_id,pt.first_name,pt.last_name FROM notifications as ns LEFT JOIN patient as pt ON pt.patient_id=ns.sender WHERE ns.receiver='$sess_id'");
			break;

			case "3":
			$sess_id = $this->CM->find_shop();
					$query = $this->db->query("SELECT ns.id,ns.sender,ns.receiver,ns.module,ns.date_send,ns.status,ns.message,pt.patient_id,pt.first_name,pt.last_name FROM notifications as ns LEFT JOIN patient as  pt ON pt.patient_id=ns.sender WHERE ns.receiver='$sess_id'");
			break;
		}

		$this->CM->result_encode($query);

	}


	function make_notice($sender,$receiver,$module,$msg){
		$save_notice = array(
			'sender' => $sender,
			'receiver' => $receiver,
			'module' => $module,
			'message' => $msg,
			'date_send' => date('Y-m-d')
			);

		$this->db->insert('notifications',$save_notice);

	}

	function process_notice(){
		$action = $this->input->post('action');
		$id = $this->input->post('id');

		switch($action){
			case "mark_as_unread":

			$this->db->where('id',$id);
			$query = $this->db->update('notifications',array('status'=>'0'));

			break;

			case "mark_as_read":

			$this->db->where('id',$id);
			$query = $this->db->update('notifications',array('status'=>'1'));

			break;
		}//end of swtich

		if($query){
			return TRUE;
		}else{
			return FALSE;
		}

	}













}//end of class