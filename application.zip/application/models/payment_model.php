<?php 

Class Payment_model extends CI_Model{


	function __construct(){
		$this->load->database();
		$this->load->model('Content_model','CM');
	}
	

	function sales_list(){
		$shop_id = $this->CM->find_shop();

		$query = $this->db->query("SELECT mc.date_paid,mc.optshop_id,mc.optprod_id,mc.qty,mc.patient_id,mc.status,(mc.qty * op.price) as total_sales,op.optprod_img,op.price,op.name,pt.patient_id,pt.first_name,pt.middle_name,pt.last_name FROM my_cart as mc LEFT JOIN patient as pt ON pt.patient_id=mc.patient_id LEFT JOIN opt_products as op ON op.optprod_id=mc.optprod_id WHERE mc.status='Paid'");
		$this->CM->result_encode($query);
	}

	function sub_list(){
		$shop_id = $this->CM->find_shop();

		$query = $this->db->query("SELECT * FROM subscription_payments WHERE shop_id='$shop_id' ORDER BY id DESC");
		$this->CM->result_encode($query);
	}

}//end of class