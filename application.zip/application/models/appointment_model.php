<?php 

Class Appointment_model extends CI_Model{


	function __construct(){
		$this->load->database();
		$this->load->model('Content_model','CM');
	}
	

	function process_appointment(){

		$action = $this->input->post('action');
		$appointment_id = $this->input->post('appointment_id');
		$service_id = $this->input->post('service_id');
		$patient_id = $this->session->userdata('sess_id');
		$id_patient = $this->input->post('id_patient');
		$shop_id = $this->input->post('shop_id');
		$app_date = $this->input->post('app_date');
		$app_time = $this->input->post('app_time');
		$emp_id  = $this->input->post('emp_id');
		$resched_id = $this->input->post('resched_id');
		if(empty($emp_id)){
			$status="Pending";
			$emp_id=0;
		}else{
			$id_emp = $emp_id;
			$status="Approved";
		}

		switch($action){

			case "approved":
				$this->db->where('appointment_id',$appointment_id);
				$query = $this->db->update('appointment',array('status'=>'Approved','emp_id'=>$id_emp));
				$this->CM->make_notice($shop_id,$id_patient,'Appointment','Your appointment has been approved');
			break;

			case "save":

				$save_array = array(
					'optshop_id' => $shop_id,
					'patient_id' => $patient_id,
					'emp_id' => $emp_id,
					'app_date' => $app_date,
					'app_time' => $app_time,
					'status' => $status,
					'services' => $service_id
				);

				$sched_arr = array(
					'app_date' => $app_date,
					'app_time' => $app_time
				);

				if(empty($appointment_id) && empty($resched_id)){
					$query = $this->db->insert('appointment',$save_array);
					$this->CM->make_notice($patient_id,$shop_id,'Appointment','You receive new appointment');
				}elseif(!empty($resched_id)){
					$this->db->where('appointment_id',$resched_id);
					$query = $this->db->update('appointment',$sched_arr);
				}
				else{
					$this->db->where('appointment_id',$appointment_id);
					$query = $this->db->update('appointment',$save_array);
				}

			break;

			case "remove":

				$this->db->where('appointment_id',$appointment_id);
				$query = $this->db->update('appointment',array('status'=>'Cancelled'));

			break;
		}

		if($query){
			return TRUE;
		}else{
			return FALSE;
		}

	}	


	function appointment_list(){

		$sess_id = $this->session->userdata('sess_id');
		$sess_access = $this->session->userdata('sess_access');

		switch($sess_access){
			
			case "0":
				$where = "at.patient_id='$sess_id'";
			break;

			case "1":
				$shop_id = $this->CM->find_shop();
				$where = "at.optshop_id='$shop_id' AND at.status='Pending'";
			break;

			case "3":
				$shop_id = $this->CM->find_shop();
				$where = "at.optshop_id='$shop_id' AND at.status='Pending'";
			break;
			
			case "4":
				$where = "at.emp_id='$sess_id'";
			break;
		}//end of switch
		if(!empty($sess_id)){
			$query = $this->db->query("SELECT pt.patient_id as id_patient, pt.first_name as patient_first,pt.last_name as patient_last,ss.services_id,ss.service_name,at.appointment_id,at.optshop_id,at.patient_id,at.emp_id,at.services,at.app_date,at.app_time,at.status,os.optshop_id as id_shop,os.optshop_name,es.emp_id as id_employee,es.fname,es.lname FROM appointment as at LEFT JOIN services as ss ON ss.services_id=at.services LEFT JOIN opt_shops as os ON os.optshop_id=at.optshop_id LEFT JOIN employees as es ON es.emp_id=at.emp_id LEFT JOIN patient as pt ON pt.patient_id=at.patient_id WHERE $where");
			// $query = $this->db->query("SELECT * FROM appointment WHERE $where");
			$this->CM->result_encode($query);	
		}
	}



}//end of class