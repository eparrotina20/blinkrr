<?php 


Class Patient_model extends CI_Model{


	function __construct(){
		$this->load->database();
		$this->load->model('Content_model','CM');
	}


	function patients(){

		$patient_id = $this->input->post('patient_id');
		if(!empty($patient_id)){
			$where = "patient_id='$patient_id'";
		}else{
			$where = "";
		}

		$query = $this->db->query("SELECT * FROM patient $where ");
		$this->CM->result_encode($query);
	}







}//end of class