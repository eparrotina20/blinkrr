<?php 

Class Service_model extends CI_Model{


	function __construct(){
		$this->load->database();
		$this->load->model('Content_model','CM');
	}
	

	function service_list(){
		$sess_type = $this->session->userdata('sess_access');
		if($sess_type == "1" || $sess_type == "3"){
			$sess_id = $this->session->userdata('sess_id');
			if($sess_type =="3"){
				$shop_id = $this->CM->get_shop_emp($sess_id);
			}else{
				$shop_id =  $this->CM->find_shop();
			}

			$where = "AND ss.optshop_id='$shop_id'";
		}else{
			$where = "";
		}

		$query = $this->db->query("SELECT ss.services_id,ss.optshop_id,ss.service_name,ss.description,ss.status,os.optshop_id,os.optshop_name,os.optshop_from_hour,os.optshop_from_min,os.optshop_to_hour,os.optshop_to_min FROM services as ss LEFT JOIN opt_shops as os ON os.optshop_id=ss.optshop_id WHERE ss.status='Active' ".$where."");
		$this->CM->result_encode($query);
	}


	function process_service(){

		$action = $this->input->post('action');
		$service_id = $this->input->post('service_id');
		$service_name = $this->input->post('service_name');
		$description = $this->input->post('description');


		switch($action){
			case "save":
			$sess_type = $this->session->userdata('sess_access');
			$sess_id = $this->session->userdata('sess_id');

			if($sess_type =="3"){
				$x_update = $this->CM->get_shop_emp($sess_id);
			}else{
				$x_update =  $this->CM->find_shop();
			}

				$save_array = array(
					'service_name' => $service_name,
					'description' => $description,
					'status' => 'Active',
					'optshop_id' => $x_update
					);
				if(empty($service_id)){//do insert
					$query = $this->db->insert('services',$save_array);
				}else{//do update
					$this->db->where('services_id',$service_id);
					$query = $this->db->update('services',$save_array);
				}

			break;

			case "remove":

			$this->db->where('services_id',$service_id);
			$query = $this->db->update('services',array('status'=>'Inactive'));

			break;	
		}//end of switch

		if($query){
			return TRUE;
		}else{
			return FALSE;
		}

	}

}//end of class