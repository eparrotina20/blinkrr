<?php 
//here
Class Account_model extends CI_Model{


	function __construct(){
		$this->load->database();
		$this->load->model('Content_model','CM');
	}
	

	function info_get(){
		$sess_access = $this->session->userdata("sess_access");
		$sess_id = $this->session->userdata("sess_id");

	// 0 - Patient
	// 1 - Optical Shop Owner
	// 2 - blinkrr Admin
	// 3 - Optical Shop Staff
	// 4 - Optometrist/ Optician
		

		switch($sess_access){
			
			case "0":
				$qry = "SELECT patient_id as account_id,last_name as lname,first_name as fname,middle_name as mname,contactNo as contact,gender as sex,address as adds, email as em,patient_img as image,civil_status as cs, DOB as birthdate FROM patient WHERE patient_id='$sess_id'";
			break;
			
			case "1":
				$qry = "SELECT owner_id as account_id,last_name as lname,first_name as fname,middle_name as mname,contactNo as contact,gender as sex, address as adds, email as em, owner_img as image,civil_status as cs,DOB as birthdate FROM owner WHERE owner_id='$sess_id'";
			break;
			
			case "2":
				$qry = "SELECT emp_id as account_id,lname as lname,fname as fname,mname as mname,contact as contact,gender as sex, address as adds, email as em, emp_image as image,civil_status as cs, DOB as birthdate FROM employees WHERE emp_id='$sess_id'";
			break;
			
			case "3":
				$qry = "SELECT emp_id as account_id,lname as lname,fname as fname,mname as mname,contact as contact,gender as sex, address as adds, email as em, emp_image as image,civil_status as cs, DOB as birthdate FROM employees WHERE emp_id='$sess_id'";
			break;

			case "4":
				$qry = "SELECT emp_id as account_id,lname as lname,fname as fname,mname as mname,contact as contact,gender as sex, address as adds, email as em, emp_image as image,civil_status as cs, DOB as birthdate FROM employees WHERE emp_id='$sess_id'";
			break;
		}//end of clase

		$query  = $this->db->query($qry);
	
		$this->CM->result_encode($query);

	}//end of function


	function account_save(){
	error_reporting(0);			
    $sess_id = $this->session->userdata('sess_id');
    $sess_access = $this->session->userdata('sess_access');

	$email = $this->input->post('email');
	$last_name = $this->input->post('last_name');
	$first_name = $this->input->post('first_name');
	$middle_name = $this->input->post('middle_name');
	$birthdate = $this->input->post('birthdate');
	$gender = $this->input->post('gender');
	$address = $this->input->post('address');
	$contact = $this->input->post('contact');
	$civil_status = $this->input->post('civil_status');
	$upload_status = $this->input->post('upload_status');

	if($sess_access == "0"){
		$tbl = "patient";
		$photo = "patient_img";
		$unique_id = "patient_id";
		$fnamex = "first_name";
		$mnamex = "middle_name";
		$lnamex = "last_name";
		$contactx = "contactNo";
	}elseif($sess_access=="1"){
		$tbl = "owner";
		$photo = "owner_img";
		$unique_id = "owner_id";
		$fnamex = "first_name";
		$mnamex = "middle_name";
		$lnamex = "last_name";
		$contactx = "contactNo";
	}else{
		$tbl = "employees";
		$photo = "emp_image";
		$unique_id = "emp_id";
		$fnamex = "fname";
		$mnamex = "mname";
		$lnamex = "lname";
		$contactx = "contact";
	}

	$remove_avatar = $this->db->query("SELECT ".$unique_id.",".$photo." FROM ".$tbl." WHERE ".$unique_id."='$sess_id' AND ".$photo."!=''");

				if($upload_status=="dont_upload"){

					if($remove_avatar->num_rows() > 0){
						foreach($remove_avatar->result_array() as $row_avatar) {
						$avatar_location = $row_avatar[''.$photo.''];
						}//end of foreach
					}//end of inner if
					else{$avatar_location='images/default.png';}//end of inner else


			}//end of outer if
			elseif($upload_status=="upload"){

			//DO THIS IF UPDATE
			if(!empty($sess_id)){
				
				if($remove_avatar->num_rows() > 0){
					foreach($remove_avatar->result_array() as $row_avatar) {
						$location_avatar = $row_avatar[''.$photo.''];
					}//end of foreach
				}//end of inner if num rows
			
			 }
			//end of outer if not empty category id				
			//END OF DO THIS IF UPDATE
			$session_id = date('ymdhis');
			$file=$_FILES['file_upload']['tmp_name'];	
			$name=$_FILES['file_upload']['name'];
			$split_point = '.';
			$stringpos = strrpos($name, $split_point, -1);
			$finalstr = substr($name,0,$stringpos);
			$FinalName="".$session_id."_".$finalstr."";

			$image= addslashes(@file_get_contents($_FILES['file_upload']['tmp_name']));
			$image_name= addslashes($_FILES['file_upload']['name']);
			$image_size= @getimagesize($_FILES['file_upload']['tmp_name']);
			$splitName = explode(".", $image_name); //split the file name by the dot
			$fileExt = end($splitName); //get the file extension
			$newFileName  = ucwords($FinalName.'.'.$fileExt); //join file name and ext.
			move_uploaded_file($_FILES["file_upload"]["tmp_name"],"assets/system/images/owners/".$newFileName);
	
			$avatar_location="system/images/owners/".$newFileName;	

		}//end of outer else if



   		$save_array = array(
			''.$lnamex.'' => $last_name,
			''.$fnamex.'' => $first_name,
			''.$mnamex.'' => $middle_name,
			''.$contactx.'' => $contact,
			'gender' => $gender,
			'address' => $address,
			'DOB' => $birthdate,
			'email' => $email,
			''.$photo.'' => $avatar_location,
			'civil_status' => $civil_status		
			);


   				 $this->db->where(''.$unique_id.'',$sess_id);	
		$query = $this->db->update(''.$tbl.'',$save_array);

		if($query){
			return TRUE;
		}else{
			return FALSE;
		}


	}//end of function account_save






















}//end of class