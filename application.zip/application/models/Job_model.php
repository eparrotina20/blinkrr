<?php 

Class Job_model extends CI_Model{


	function __construct(){
		$this->load->database();
		$this->load->model('Content_model','CM');
	}
	
	function job_list(){
		$request = $this->input->post('request');
		$shop = $this->CM->find_shop();
		$query = $this->db->query("SELECT jo.joborder_id,jo.optshop_id,jo.optprod_id,jo.patient_id,jo.promo_id,jo.emp_id,jo.date,jo.due_date,jo.od,jo.os,jo.remark,jo.discount,jo.total,jo.deposit,jo.payment_status,jo.status,es.emp_id as employee_id,es.fname as emp_fname,es.lname as emp_lname,pt.patient_id as id_patient,pt.first_name as patient_fname,pt.last_name as patient_lname,op.optprod_id as product_id,op.name as product_name,os.optshop_id as id_shop,os.optshop_name as shop_name FROM job_orders as jo LEFT JOIN employees as es ON es.emp_id=jo.emp_id LEFT JOIN patient as pt ON pt.patient_id=jo.patient_id LEFT JOIN opt_shops as os ON os.optshop_id=jo.optshop_id LEFT JOIN opt_products as op ON op.optprod_id=jo.optprod_id WHERE jo.status='$request' AND jo.optshop_id='$shop'");

		$this->CM->result_encode($query);
	}

	function process_job(){

		$job_id = $this->input->post('job_id');
		$action = $this->input->post('action');
		$job_attr = $this->input->post('job_attr');
		$in_optshop = $job_attr['in_optshop'];
		$job_order_id = $job_attr['job_order_id'];
		$patient_id = $job_attr['patient_id'];
		$emp_id = $job_attr['emp_id'];
		$due_date = $job_attr['due_date'];
		$od = $job_attr['od'];
		$os = $job_attr['os'];
		$optprod_id = $job_attr['optprod_id'];
		$in_diagnosis = $job_attr['in_diagnosis'];
		$in_prescription = $job_attr['in_prescription'];
		$in_amount = $job_attr['in_amount'];
		$in_discount = $job_attr['in_discount'];
		$in_total = $job_attr['in_total'];
		$in_remarks = $job_attr['in_remarks'];
		$in_deposit = $job_attr['in_deposit'];
		$in_promo = $job_attr['in_promo'];

		switch($action){

			case "save":
			
				$save_array = array(
					'optshop_id' => $in_optshop,
					'optprod_id' => $optprod_id,
					'patient_id' => $patient_id,
					'promo_id' => $in_promo,
					'emp_id' => $emp_id,
					'date' => date('Y-m-d h:i:s'),
					'due_date' => $due_date,
					'od' => $od,
					'os' => $os,
					'remark' => $in_remarks,
					'discount' => $in_discount,
					'total' => $in_total,
					'deposit' => $in_deposit
				);

				$save_history = array(
					'patient_id' => $patient_id,
					'emp_id' => $emp_id,
					'date' => date('Y-m-d h:i:s'),
					// 'od_sphere' => $xxx,
					// 'od_cylinder' => $xxx,
					// 'od_axis' => $xxx,
					// 'od_rdg_add' => $xxx,
					// 'os_sphere' => $xxx,
					// 'os_cylinder' => $xxx,
					// 'os_axis' => $xxx,
					// 'os_rdg_add' => $xxx,
					// 'pat_complain' => $xxx,
					// 'diagnosis' => $xxx,
					// 'prescription' => $xxx,
					'amount' => $in_total,
					'discount_id' => $in_discount,
					// 'dicounted_amount' => $xxx,
					// 'balance_insurance' => $xxx,
					'balance' => $in_total
				);

			if(empty($job_order_id)){
				$this->db->insert('patient_history',$save_history);
				$query = $this->db->insert('job_orders',$save_array);
			}else{
				$this->db->where('joborder_id',$job_order_id);
				$query = $this->db->update('job_orders',$save_array);
			}	
				
			break;
			
			case "sold":
				$this->db->where('joborder_id',$job_id);
				$query = $this->db->update('job_orders',array('status'=>'Sold','payment_status'=>'Sold'));
			break;

			case "remove":

				$this->db->where('joborder_id',$job_id);
				$query = $this->db->update('job_orders',array('status'=>'Removed','payment_status'=>'Removed'));
			break;

		}


		if($query){
			return TRUE;
		}else{
			return FALSE;
		}

	}






}//end of class