<?php 

Class Insurance_model extends CI_Model{


	function __construct(){
		$this->load->database();
		$this->load->model('Content_model','CM');
	}

	function process(){
		$action = $this->input->post('action');
		
		switch($action){
			case "save":

			break;
		}
	}

	function history(){

	}


	function insurance_list(){
		$query = $this->db->query("SELECT ie.insurance_id,ie.pathis_id,ie.acc_ins_id,ie.date,ie.agreement,ie.authorized_person,ie.amount,ie.status,ae.acc_ins_id,ae.company_name,ph.pathis_id,ph.patient_id,pt.patient_id,pt.first_name,pt.last_name FROM insurance as ie  LEFT JOIN accredited_insurance as ae ON ae.acc_ins_id=ie.acc_ins_id LEFT JOIN patient_history as ph ON ph.pathis_id=ie.pathis_id LEFT JOIN patient as pt ON pt.patient_id=ph.patient_id WHERE ie.status='Active' ORDER BY ie.acc_ins_id DESC");
		$this->CM->result_encode($query);
	}

	function companies(){
		$query = $this->db->query("SELECT * FROM accredited_insurance WHERE status='Active' ORDER BY acc_ins_id DESC");
		$this->CM->result_encode($query);
	}
	

	function process_company(){

		$action = $this->input->post('action');
		$company_id = $this->input->post('company_id');
		$company_name = $this->input->post('company_name');
		$company_address = $this->input->post('company_address');
		$company_contact = $this->input->post('company_contact');


		$in_company = $this->input->post('in_company');
		$in_authorized = $this->input->post('in_authorized');
		$in_date = $this->input->post('in_date');
		$in_agreement = $this->input->post('in_agreement');
		$in_covered_amount = $this->input->post('in_covered_amount');
		$in_patient = $this->input->post('in_patient');
		$in_employee = $this->input->post('in_employee');
		$in_date = $this->input->post('in_date');
		$in_od_sphere = $this->input->post('in_od_sphere');
		$id_od_cylinder = $this->input->post('id_od_cylinder');
		$in_od_axis = $this->input->post('in_od_axis');
		$in_rdg_add = $this->input->post('in_rdg_add');
		$in_os_sphere = $this->input->post('in_os_sphere');
		$in_os_cylinder = $this->input->post('in_os_cylinder');
		$in_os_axis = $this->input->post('in_os_axis');
		$in_os_rdg_add = $this->input->post('in_os_rdg_add');
		$in_complain = $this->input->post('in_complain');
		$in_diagnosis = $this->input->post('in_diagnosis');
		$in_prescription = $this->input->post('in_prescription');
		$in_amount = $this->input->post('in_amount');
		$in_discount = $this->input->post('in_discount');
		$in_insurance = $this->input->post('in_insurance');
		$in_balance = $this->input->post('in_balance');

		switch($action){

			case "save_insurance":

				$save_history = array(
					'patient_id' => $in_patient,
					'emp_id' => $in_employee,
					'date' => date('Y-m-d h:i:s'),
					'od_sphere' => $in_od_sphere,
					'od_cylinder' => $id_od_cylinder,
					'od_axis' => $in_od_axis,
					'od_rdg_add' => $in_rdg_add,
					'os_sphere' => $in_os_sphere,
					'os_cylinder' => $in_os_cylinder,
					'os_axis' => $in_os_axis,
					'os_rdg_add' => $in_os_rdg_add,
					'pat_complain' => $in_complain,
					'diagnosis' => $in_diagnosis,
					'prescription' => $in_prescription,
					'amount' => $in_amount,
					'discounted_amount' => $in_discount,
					'balance_insurance' => $in_balance,
					'balance' => $in_balance
				);


				$query1 = $this->db->insert('patient_history',$save_history);
				$history_id = $this->db->insert_id();
				$save_insurance = array(
					'acc_ins_id' => $in_company,
					'date' => date('Y-m-d h:i:s'),
					'agreement' => $in_agreement,
					'authorized_person' => $in_authorized,
					'amount' => $in_covered_amount,
					'pathis_id' => $history_id
					);

				$query2 = $this->db->insert('insurance',$save_insurance);

				if($query1 && $query2){
					$query = TRUE;
				}else{
					$query = FALSE;
				}

			break;

			case "company_save":

				$save_array = array(
				'company_name' => $company_name,
				'address' => $company_address,
				'contact' => $company_contact,
				'owner_id' => $this->session->userdata('sess_id'),
				'status' => 'Active'
				);

				if(empty($company_id)){
					$query = $this->db->insert("accredited_insurance",$save_array);
				}else{
					$this->db->where('acc_ins_id',$company_id);
					$query = $this->db->update("accredited_insurance",$save_array);
				}
			break;
			case "remove_company":
					$this->db->where('acc_ins_id',$company_id);
					$query = $this->db->update("accredited_insurance",array('status'=>'Inactive'));

			break;
		}

			if($query){
				return TRUE;
			}else{
				return FALSE;
			}

	}

}//end of class