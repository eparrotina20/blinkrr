<?php 

Class Subscription_model extends CI_Model{

	function __construct(){
		$this->load->database();
		$this->load->model('Content_model','CM');
	}
	

		

	function subscription_list(){
		$sess_access = $this->session->userdata('sess_access');
		$sess_id = $this->session->userdata('sess_id');
		if($sess_access == 1){
			$where = " AND owner_id='".$sess_id."'";
		}else{
			$where = "";
		}

		$query = $this->db->query("SELECT * FROM opt_shops WHERE optshop_status='Active' ".$where."");
		$this->CM->result_encode($query);
	}	



	function sub_process(){
			error_reporting(0);
			$action = $this->input->post('action');
			$optshop_id = $this->input->post('optshop_id');
			$optshop_name = $this->input->post('optshop_name');
			$optshop_add = $this->input->post('optshop_add');
			$optshop_tel = $this->input->post('optshop_tel');
			$owner_id = $this->session->userdata('sess_id');
			$optshop_lat = $this->input->post('optshop_lat');
			// $optshop_img = $this->input->post('');
			$optshop_long = $this->input->post('optshop_long');
			$file_upload = $this->input->post('file_upload');
			$upload_status = $this->input->post('upload_status');


			switch($action){

				case "save":

						$remove_avatar = $this->db->query("SELECT optshop_id,optshop_img FROM opt_shops WHERE optshop_id='$optshop_id' AND optshop_img!=''");

							if($upload_status=="dont_upload"){

								if($remove_avatar->num_rows() > 0){
									foreach($remove_avatar->result_array() as $row_avatar) {
									$avatar_location = $row_avatar['optshop_img'];
									
									}//end of foreach
								}//end of inner if
								else{$avatar_location='system/images/optical_shops/logo_icon.png';}//end of inner else


						}//end of outer if
						elseif($upload_status=="upload"){

						//DO THIS IF UPDATE
						if(!empty($optshop_id)){
							
							if($remove_avatar->num_rows() > 0){
								foreach($remove_avatar->result_array() as $row_avatar) {
									$location_avatar = $row_avatar['optshop_img'];
								}//end of foreach
							}//end of inner if num rows
						
						 }
						//end of outer if not empty category id				
						//END OF DO THIS IF UPDATE
						$session_id = date('ymdhis');
						$file=$_FILES['file_upload']['tmp_name'];	
						$name=$_FILES['file_upload']['name'];
						$split_point = '.';
						$stringpos = strrpos($name, $split_point, -1);
						$finalstr = substr($name,0,$stringpos);
						$FinalName="".$session_id."_".$finalstr."";

						$image= addslashes(@file_get_contents($_FILES['file_upload']['tmp_name']));
						$image_name= addslashes($_FILES['file_upload']['name']);
						$image_size= @getimagesize($_FILES['file_upload']['tmp_name']);
						$splitName = explode(".", $image_name); //split the file name by the dot
						$fileExt = end($splitName); //get the file extension
						$newFileName  = ucwords($FinalName.'.'.$fileExt); //join file name and ext.
						move_uploaded_file($_FILES["file_upload"]["tmp_name"],"assets/system/images/optical_shops/".$newFileName);
				
						$avatar_location="system/images/optical_shops/".$newFileName;	

					}//end of outer else if

					$save_array = array(
							'optshop_name' => $optshop_name,
							'optshop_add' => $optshop_add,
							'optshop_tel' => $optshop_tel,
							'optshop_lat' => $optshop_lat,
							'optshop_long' => $optshop_long,
							'owner_id' => $owner_id,
							'optshop_img' => $avatar_location
						);

					if(empty($optshop_id)){//do create
						$query = $this->db->insert('opt_shops',$save_array);
					}else{

							$this->db->where('optshop_id',$optshop_id);
					$query = $this->db->update('opt_shops',$save_array);

					}

				break;

				case "remove":

					$rmv_attr = array(
						'optshop_status' => 'Inactive'
						);

							$this->db->where('optshop_id',$optshop_id);
					$query = $this->db->update('opt_shops',$rmv_attr);


				break;
			}//end of case

			if($query){
				return TRUE;
			}else{
				return FALSE;
			}

		

	}//end of function






	
}//end of class