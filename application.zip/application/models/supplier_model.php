<?php
	
Class Supplier_model extends CI_Model{


	function __construct(){

		parent::__construct();
		$this->load->model('Content_model','CM');
	}


	function supplier_list(){

		$sess_id = $this->session->userdata('sess_id');

		$sess_access = $this->session->userdata('sess_access');

		$get_shop_emp = $this->CM->get_shop_emp($sess_id);
		$find_owner = $this->CM->find_owner($get_shop_emp);

		if($sess_access =="3"){
			$owner = $find_owner;
		}elseif($sess_access == "1"){
			$owner = $sess_id;
		}
		$sql = "SELECT * FROM suppliers WHERE owner_id='$owner' AND status='Active'";

		$query = $this->db->query($sql);

		$this->CM->result_encode($query);
	}	



	function supplier_process(){
		error_reporting(0);
		$sess_id = $this->session->userdata('sess_id');
		$action = $this->input->post('action');
		$supplier_id = $this->input->post('supplier_id');
		$company_name = $this->input->post('company_name');
		$contact_person = $this->input->post('contact_person');
		$contactNo = $this->input->post('contactNo');
		$email = $this->input->post('email');
		$address = $this->input->post('address');
		$upload_status = $this->input->post('upload_status');
		$file_upload = $this->input->post('file_upload');
		
		//=============================================== AVATAR CONTENT =============================================== 
		$remove_avatar = $this->db->query("SELECT sup_id,sup_image FROM suppliers WHERE sup_id='$supplier_id' AND sup_image!=''");

						if($upload_status=="dont_upload"){

								if($remove_avatar->num_rows() > 0){
									foreach($remove_avatar->result_array() as $row_avatar) {
									$avatar_location = $row_avatar['sup_image'];
									
									}//end of foreach
								}//end of inner if
								else{$avatar_location='system/images/optical_shops/logo_icon.png';}//end of inner else


						}//end of outer if
						elseif($upload_status=="upload"){

						//DO THIS IF UPDATE
						if(!empty($optshop_id)){
							
							if($remove_avatar->num_rows() > 0){
								foreach($remove_avatar->result_array() as $row_avatar) {
									$location_avatar = $row_avatar['sup_image'];
								}//end of foreach
							}//end of inner if num rows
						
						 }
						//end of outer if not empty category id				
						//END OF DO THIS IF UPDATE
						$session_id = date('ymdhis');
						$file=$_FILES['file_upload']['tmp_name'];	
						$name=$_FILES['file_upload']['name'];
						$split_point = '.';
						$stringpos = strrpos($name, $split_point, -1);
						$finalstr = substr($name,0,$stringpos);
						$FinalName="".$session_id."_".$finalstr."";

						$image= addslashes(@file_get_contents($_FILES['file_upload']['tmp_name']));
						$image_name= addslashes($_FILES['file_upload']['name']);
						$image_size= @getimagesize($_FILES['file_upload']['tmp_name']);
						$splitName = explode(".", $image_name); //split the file name by the dot
						$fileExt = end($splitName); //get the file extension
						$newFileName  = ucwords($FinalName.'.'.$fileExt); //join file name and ext.
						move_uploaded_file($_FILES["file_upload"]["tmp_name"],"assets/system/images/suppliers/".$newFileName);
				
						$avatar_location="system/images/suppliers/".$newFileName;	

					}//end of outer else if

				//=============================================== AVATAR CONTENT =============================================== 

		switch($action){

			case "save":

			$save_array = array(
				'company_name' => $company_name,
				'contact_person' => $contact_person,
				'contactNo' => $contactNo,
				'email' => $email,
				'address' => $address,
				'sup_image' => $avatar_location,
				'owner_id' => $sess_id,
				'status' => 'Active'
				);

			if(empty($supplier_id)){//do insert
				$query = $this->db->insert('suppliers',$save_array);
			}else{

				$this->db->where('sup_id',$supplier_id);
				$query = $this->db->update('suppliers',$save_array);
			}


			break;

			case "remove":
				$this->db->where('sup_id',$supplier_id);
				$query = $this->db->update('suppliers',array('status'=>'Inactive'));
			break;
		}//end of switch


		if($query){
			return TRUE;
		}else{
			return FALSE;
		}

	}
















}//end of class