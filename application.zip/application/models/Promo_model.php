<?php

Class Promo_model extends CI_Model{


	function __construct(){
		$this->load->database();
		$this->load->model('Content_model','CM');
	}


	function promo_list(){
		$product_id = $this->input->post('product_id');

		if(empty($product_id)){
			$where = "";
		}else{
			$where = "optprod_id='$product_id' AND ";
		}

		$query = $this->db->query("SELECT * FROM promos WHERE $where status='Active'");
		$this->CM->result_encode($query);
	}












}