<!-- <div class="rsidebar span_1_of_left"> -->
				<!-- <div class="top-border"> </div>
				 <div class="border">
	             <link href="<?php echo base_url();?>assets/css/default.css" rel="stylesheet" type="text/css" media="all" />
	             <link href="<?php echo base_url();?>assets/css/nivo-slider.css" rel="stylesheet" type="text/css" media="all" />
				  <script src="<?php echo base_url();?>assets/js/jquery.nivo.slider.js"></script> -->
				    <script type="text/javascript">
			
				    // $(window).load(function() {
				    //     $('#slider').nivoSlider();
				    // });
				    </script>
	<!-- 	    <div class="slider-wrapper theme-default">
              <div id="slider" class="nivoSlider">
                <img src="<?php echo base_url();?>assets/images/t-img1.jpg"  alt="" />
               	<img src="<?php echo base_url();?>assets/images/t-img2.jpg"  alt="" />
                <img src="<?php echo base_url();?>assets/images/t-img3.jpg"  alt="" />
              </div>
             </div> --><!-- 
              <div class="btn"><a href="single.html">Check it Out</a></div>
             </div> -->
          <!--  <div class="top-border"> </div> -->
			<!-- <div class="sidebar-bottom">
			    <h2 class="m_1">Newsletters<br> Signup</h2>
			    <p class="m_text">Lorem ipsum dolor sit amet, consectetuer</p>
			    <div class="subscribe">
					 <form>
					    <input name="userName" type="text" class="textbox">
					    <input type="submit" value="Subscribe">
					 </form>
	  			</div>
			</div> -->
	    </div>
	   <div class="clear"></div>
	</div>
	</div>
	</div>