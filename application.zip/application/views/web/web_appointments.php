
<div ng-controller="AppointmentCtrl">
	<h2 class="head">{{page_title}}</h2>

			<table class="table table-striped">
				<thead>
					<tr>
						<th>Service</th>
						<th>Appointment Date</th>
						<th>Appointment Time</th>
						<th>Optical Shop</th>
						<th>Optometrist/ Optician</th>
						<th>Status</th>
						<th>&nbsp;</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="x in list" id="inline_{{x.appointment_id}}">
						<td id="service_name_{{x.appointment_id}}">{{x.service_name}}</td>
						<td id="app_date_{{x.appointment_id}}">{{x.app_date}}</td>
						<td id="app_time_{{x.appointment_id}}">{{x.app_time}}</td>
						<td>{{x.optshop_name}}</td>
						<td>{{x.fname}} {{x.lname}}</td>
						<td>{{x.status}}</td>
						<td><button class="btn btn-success btn-sm" ng-click="process('resched',x.appointment_id)"><i class="fa fa-bars"></i> Reschedule</button></td>
						<td><button class="btn btn-danger btn-sm" ng-click="process('remove',x.appointment_id)"><i class="fa fa-remove"></i> Cancel</button></td>
					</tr>
				</tbody>
			</table>

</div><!-- IndexCtrl-->	
<!-- <p id="datepairExample">
    <input type="text" class="date start" />
    <input type="text" class="time start" /> to
    <input type="text" class="time end" />
    <input type="text" class="date end" />
</p>
 -->

<script>
    // initialize input widgets first
    // $('#datepairExample .time').timepicker({
    //     'showDuration': true,
    //     'timeFormat': 'g:ia'
    // });

    // $('#datepairExample .date').datepicker({
    //     'format': 'yyyy-m-d',
    //     'autoclose': true
    // });

</script>

<br><br>
<br><br>