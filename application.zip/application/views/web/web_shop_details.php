<div ng-controller="OpticalCtrl">
	
	<div style="padding-left:2%;">
		<h2 class="head"><?php echo $shop_name;?></h2>
	</div>	
	<hr>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<table>
					<tr>
						<td valign="top">
							<img src="<?php echo base_url();?>assets/<?php echo $shop_img;?>" style="width:100px;height:100px;">
						</td>
						<td valign="top">
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						</td>
						<td valign="top">

							Owner: <br><strong><?php echo $owner_name;?></strong>
							<br><br>
						
							Address: <br><strong><?php echo $shop_add;?></strong>
							<br><br>
							Telephone Number: <br><strong><?php echo $shop_tel;?></strong>
							<br><br>
							Business Hours: <br><strong><?php echo $business_hours;?></strong>
							<br>
						</td>
					</tr>
				</table>

			</div>


			<div class="col-md-1">&nbsp;&nbsp;&nbsp;&nbsp;</div>
			<div class="col-md-7">
				
				<div class="row">
					<h4>Services:</h4>
			<?php foreach($services as $row_s){?>	
							<div class="col-md-2" style="margin:15px;margin-right:155px;">
								<div class="col_1_of_3 span_1_of_3"  style="width:250px;height:320px;"> 
									<a href="javascript:void(0)" style="text-decoration:none;" onclick="service_process('add_services','<?php echo $row_s['services_id'];?>')">
										<div class="inner_content clearfix">
											<div class="product_image">
												<img src="<?php echo base_url();?>assets/images/service.jpg" style="width:170px;height:140px;" alt=""/>
											</div>
											<input type="hidden" value="<?php echo $row_s['optshop_id'];?>" id="shop_id_<?php echo $row_s['services_id'];?>">
											<div class="sale-box"><span class="on_sale title_shop"><?php echo $shop_name;?></span></div>	
											
									
											<div class="price">
												<div class="cart-left">
													<p class="title" id="service_name_<?php echo $row_s['services_id'];?>"><?php echo $row_s['service_name'];?></p>
													<span class="actual"><?php echo $row_s['description'];?></span>
											</a>		
													<div class="price1">
														<a href="javascript:void(0)"><span><?php echo $shop_name;?></span></a>
											<input type="hidden" id="business_hour_from" value="<?php echo $optshop_from_hour;?>">
											<input type="hidden" id="business_min_from" value="<?php echo $optshop_from_min;?>">
											<input type="hidden" id="business_hour_to" value="<?php echo $optshop_to_hour;?>">
											<input type="hidden" id="business_min_to" value="<?php echo $optshop_to_min;?>">
											<br><br>			
														<div id="business_hours_<?php echo $row_s['services_id'];?>">Business Hours: <br>	
															<strong>
																<?php echo $business_hours;?>
															</strong>	
														</div>
													</div>
												</div>

											<div style="float: right;padding-top:50px;padding-right: 10px;">
												<img src="<?php echo base_url();?>assets/images/plane.png" style="width:20px;height:20px;">
											</div>
			<!-- 
			 -->
											<div class="clear"></div>
											</div>				
										</div>
								</div>
							</div>	
							<?php }?>

				</div>

				<br><br>
				<div class="row">
					<h4>Products:</h4>

						<?php foreach($products as $row_p){?>

							<div class="col-md-2" style="margin:15px;margin-right:155px;">
								<div class="col_1_of_3 span_1_of_3"  style="width:250px;height:250px;"> 
									<a href="javascript:void(0)" onclick="product_service('add_to_cart','<?php echo $row_p['optprod_id'];?>')">
										<div class="inner_content clearfix">
											<div class="product_image">
												<img src="<?php echo base_url();?>assets/<?php echo $row_p['optprod_img'];?>" style="width:170px;height:140px;" alt=""/>
											</div>
											<div class="sale-box"><span class="on_sale title_shop">
												<?php echo $row_p['name'];?>
												</span></div>	
											<div class="price">
												<div class="cart-left">
													<p class="title"><?php echo $row_p['name'];?></p>
															<span class="actual"><?php echo $row_p['price'];?></span>

												</div>
										
											<div class="cart-right"> </div>
											<div class="clear"></div>
											</div>				
										</div>
									</a>
								</div>
							</div>	


						<?php }?>
				</div>

			</div>

		</div>
	</div>	



<br><br><br><br>
</div><!-- IndexCtrl-->	