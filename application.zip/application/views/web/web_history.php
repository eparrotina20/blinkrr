
<div ng-controller="HistoryCtrl">
	<h2 class="head">{{page_title}}</h2>

			<table class="table table-striped">
				<thead>
					<tr style="font-weight: bold;">
						<th>Shop</th>
						<th>Date</th>
						<th style="color:red;">OD Sphere</th>
						<th style="color:red;">OD Cylinder</th>
						<th style="color:red;">OD Axis</th>
						<th style="color:red;">OD RDG ADD</th>
						<th style="color:green;">OS Sphere</th>
						<th style="color:green;">OS Cylinder</th>
						<th style="color:green;">OS Axis</th>
						<th style="color:green;">OS RDG ADD</th>
						<th>Complain</th>
						<th>Diagnosis</th>
						<th>Prescription</th>
						<th>Amount</th>
						<th>Discount</th>
						<th>Insurance</th>
						<th>Balance</th>
						<th>Status</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="x in list" id="inline_{{x.pathis_id}}">
						<td>{{x.optshop_name}}</td>
						<td>{{x.date}}</td>
						<td>{{x.od_sphere}}</td>
						<td>{{x.od_cylinder}}</td>
						<td>{{x.od_axis}}</td>
						<td>{{x.od_rdg_add}}</td>
						<td>{{x.os_sphere}}</td>
						<td>{{x.os_cylinder}}</td>
						<td>{{x.os_axis}}</td>
						<td>{{x.os_rdg_add}}</td>
						<td>{{x.pat_complain}}</td>
						<td>{{x.diagnosis}}</td>
						<td>{{x.prescription}}</td>
						<td>{{x.amount}}</td>
						<td>{{x.discounted_amount}}</td>
						<td>{{x.balance_insurance}}</td>
						<td>{{x.balance}}</td>
						<td>{{x.status}}</td>
					</tr>
				</tbody>
			</table>

</div>
<br><br>
<br><br>