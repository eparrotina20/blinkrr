<div ng-controller="OpticalCtrl">
				  	<h2 class="head">Optical Shops</h2>
				<div class="col-md-2" style="margin:15px;margin-right:55px;"  ng-repeat="x in list">
					<div class="col_1_of_3 span_1_of_3"  style="width:250px;height:250px;"> 

								<form method="POST" action="<?php echo base_url();?>Web/shop_details">
									<input type="hidden" name="shop_id" value='{{x.optshop_id}}'>
									<input type="submit" style="display:none;" id="submit_btn_{{x.optshop_id}}" value="Submit"> 
								</form>
						<a href="javascript:void(0)" ng-click="shop_details(x.optshop_id)">
							<div class="inner_content clearfix">
								<div class="product_image">
									<img src="<?php echo base_url();?>assets/{{x.optshop_img}}" style="width:170px;height:140px;" alt=""/>
								</div>
								<div class="sale-box"><span class="on_sale title_shop">&nbsp;</span></div>	
								<div class="price">
									<div class="cart-left">
										<p class="title">{{x.optshop_name}}</p>
											<div class="price1">
												<span class="actual">{{x.optshop_add}}</span>
											</div>
									</div>
								<!-- <div style="float: right;">
									<img src="<?php echo base_url();?>assets/images/plane.png" style="width:40px;height:40px;">
								</div> -->
								<!-- <div class="call-right"> </div> -->
								<div class="clear"></div>
								</div>				
							</div>
						</a>
					</div>
				</div>	
</div><!-- IndexCtrl-->	