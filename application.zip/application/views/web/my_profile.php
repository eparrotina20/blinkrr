			
<div ng-controller="MyProfileCtrl">
	  	<h2 class="head">My Profile</h2>
	<hr>  	
	<div id="profile_here" ng-repeat="x in profile">
		<div class="row">
			<div class="col-md-3">
				<div class="form-group">
					<label>First Name:</label>
					<input type="text" class="form-control" value="{{x.first_name}}" id="first_name">
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label>Middle Name:</label>
					<input type="text" class="form-control" value="{{x.middle_name}}" id="middle_name">
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label>Last Name:</label>
					<input type="text" class="form-control" value="{{x.last_name}}" id="last_name">
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label>Contact Number:</label>
					<input type="text" class="form-control"  value="{{x.contactNo}}" id="contactNo">
				</div>
			</div>
		</div><!--row-->
		<div class="row">
			<div class="col-md-3">
				<div class="form-group">
					<label>Email:</label>
					<input type="text" class="form-control" value="{{x.email}}"  id="email">
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label>Password:</label>
					<input type="password" class="form-control" value="{{x.pw}}"  id="pw">
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label>Address:</label>
					<input type="text" class="form-control" value="{{x.address}}"  id="address">
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label>Date of Birth:</label>
					<input type="date" class="form-control" value="{{x.DOB}}"  id="dob">
				</div>
			</div>
		</div><!--row-->
		<div class="row">
			<div class="col-md-3">
				<div class="form-group">
					<label>Civil Status:</label>
					<select type="text" class="form-control" id="civil_status">
						<option selected="selected" value="{{x.civil_status}}">{{x.civil_status}}</option>
						<option value="Married">Married</option>
						<option value="Single">Single</option>
						<option value="Widowed">Widowed</option>
					</select>
				</div>
			</div>
		</div><!--row-->

		<div align="right">
			<button ng-click="update_profile()" class="btn btn-success">
				<i class="fa fa-paper-plane"></i>
				UPDATE PROFILE
			</button>
		</div>
	</div>
</div><!-- IndexCtrl-->	

