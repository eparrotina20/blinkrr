<!DOCTYPE HTML>
<html>
<head>
<title>Blinkrr | <?php echo $page_title;?></title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo base_url();?>assets/css/form.css" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo base_url();?>assets/css/bootstrap-datetimepicker.min.css" rel="stylesheet" type="text/css" media="all" />

<link rel="shortcut icon" href="<?php echo base_url();?>assets/logo_icon.png">


<!-- start menu -->
<link href="<?php echo base_url();?>assets/css/megamenu.css" rel="stylesheet" type="text/css" media="all" />

<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">


<script src="<?php echo base_url();?>assets/js/jquery-2.1.4.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.timepicker.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap-datepicker.js"></script>

<!-- Optional theme -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/font-awesome/css/font-awesome.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/font-awesome/css/font-awesome.min.css">

  <script src="<?php echo base_url();?>assets/js/angular/angular.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/angular/angular-route.js"></script>
  <script src="<?php echo base_url();?>assets/js/angular/dirPagination.js"></script>
  <script src="<?php echo base_url();?>assets/system/js/default.js"></script>
</head>
<input type="hidden" value="<?php echo $this->session->userdata('sess_access');?>" id="current_user">
<input type="hidden" value="" id="current_module">
<script>
	var blinkrr = angular.module('blinkrr',['ngRoute','angularUtils.directives.dirPagination']);
</script>

