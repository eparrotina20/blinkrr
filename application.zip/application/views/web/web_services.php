			
			<div ng-controller="WebServiceCtrl">
				  	<h2 class="head">Featured Services</h2>
				<div class="col-md-2" style="margin:15px;margin-right:55px;"  ng-repeat="x in list">
					<div class="col_1_of_3 span_1_of_3"  style="width:250px;height:320px;"> 
						<a href="javascript:void(0)" style="text-decoration:none;" ng-click="process('add_services',x.services_id)">
							<div class="inner_content clearfix">
								<div class="product_image">
									<img src="<?php echo base_url();?>assets/images/service.jpg" style="width:170px;height:140px;" alt=""/>
								</div>
								<input type="hidden" value="{{x.optshop_id}}" id="shop_id_{{x.services_id}}">
								<div class="sale-box"><span class="on_sale title_shop">{{x.optshop_name}}</span></div>	
								
						
								<div class="price">
									<div class="cart-left">
										<p class="title" id="service_name_{{x.services_id}}">{{x.service_name}}</p>
										<span class="actual">{{x.description}}</span>
								</a>		
										<div class="price1">
											<a href="javascript:void(0)"><span>{{x.optshop_name}}</span></a>
								<input type="hidden" id="business_hour_from" value="{{x.optshop_from_hour}}">
								<input type="hidden" id="business_min_from" value="{{x.optshop_from_min}}">
								<input type="hidden" id="business_hour_to" value="{{x.optshop_to_hour}}">
								<input type="hidden" id="business_min_to" value="{{x.optshop_to_min}}">
								<br><br>			
											<div id="business_hours_{{x.services_id}}">Business Hours: <br>	
												<strong>
													<span id="span_hour_from_{{x.services_id}}"></span>{{convert('from',x.services_id,x.optshop_from_hour)}}:{{x.optshop_from_min}} <span id="span_from_meridan_{{x.services_id}}"></span>  - <span id="span_hour_to_{{x.services_id}}"></span>{{convert('to',x.services_id,x.optshop_to_hour)}}:{{x.optshop_to_min}} <span id="span_to_meridan_{{x.services_id}}"></span>
												</strong>	
											</div>
										</div>
									</div>

								<div style="float: right;padding-top:50px;padding-right: 10px;">
									<img src="<?php echo base_url();?>assets/images/plane.png" style="width:20px;height:20px;">
								</div>
<!-- 
 -->
								<div class="clear"></div>
								</div>				
							</div>
					</div>
				</div>	
			</div><!-- IndexCtrl-->	

