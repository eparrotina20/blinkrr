			 
			<div ng-controller="IndexCtrl">
				  	<h2 class="head">Featured Products</h2>
				<div class="col-md-2" style="margin:15px;margin-right:55px;" ng-repeat="x in list">
					<div class="col_1_of_3 span_1_of_3"  style="width:250px;height:250px;"> 
						<a href="javascript:void(0)" ng-click="process('add_to_cart',x.optprod_id)">
							<div class="inner_content clearfix">
								<div class="product_image">
									<img src="<?php echo base_url();?>assets/{{x.optprod_img}}" style="width:170px;height:140px;" alt=""/>
								</div>
								<div class="sale-box"><span class="on_sale title_shop">New</span></div>	
								<div class="price">
									<div class="cart-left">
										<p class="title">{{x.name}}</p>
												<span class="actual">{{x.price}}</span>
											<div class="price1">
												<span>{{x.optshop_name}}</span>
											</div>
									</div>
							
								<div class="cart-right"> </div>
								<div class="clear"></div>
								</div>				
							</div>
						</a>
					</div>
				</div>	
			</div><!-- IndexCtrl-->	