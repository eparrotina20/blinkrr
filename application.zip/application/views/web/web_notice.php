<div ng-controller="NotificationCtrl">
	<h2 class="head">{{page_title}}</h2>

			<table class="table table-striped">
				<thead>
					<tr>
						<th>From</th>
						<th>Topic</th>
						<th>Message</th>
						<th>Status</th>
						<th>Option</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="x in list" id="inline_{{x.id}}">
						<td>{{x.optshop_name}}</td>
						<td>{{x.module}} Notice</td>
						<td>{{x.message}}</td>
						<td id="status_here_{{x.id}}">{{x.status==="0" ? "Unread": "Read"}}</td>
						<td><span id="notice_here_{{x.id}}">{{notice_read(x.status,x.id)}}</span> &nbsp;&nbsp;<button class="btn btn-danger" ng-click="process('remove',x.id)"><i class="fa fa-remove"></i> Remove</button></td>
					</tr>
				</tbody>
			</table>

</div>

<br><br><br><br>
<br><br><br><br>