

<div class="main">
	<div class="wrap">
		<div class="section group"><!-- 
		  <div class="cont span_3_of_3"> -->
				

		  		<ng-view></ng-view>

		<!-- 	<div class="top-box"> -->
			

				<div class="clear"></div>
			<!-- </div>	 -->
 						 			    
<!-- 		  </div> -->
			
