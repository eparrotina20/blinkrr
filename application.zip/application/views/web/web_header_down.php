
	<div class="header-bottom">
	    <div class="wrap">
			<div class="header-bottom-left">
				<div class="logo">
					<a href="<?php echo base_url();?>"><img src="<?php echo base_url();?>assets/logo_up.png" alt=""/></a>
				</div>
				<div class="menu">
	            <ul class="megamenu skyblue">
			<li class="active grid"><a href="<?php echo base_url();?>">Home</a></li>
			<li><a class="color4" href="#">women</a>
				<div class="megapanel">
							<div class="row">
									<div class="col-md-6">
											<div class="h_nav">
												<h4>Contact Lenses</h4>
												<ul>
													<li><a href="womens.html">Daily-wear soft lenses</a></li>
												</ul>	
											</div>							
									</div>

									<div class="col-md-6">
											<div class="h_nav">
												<h4>Eye Glasses</h4>
												<ul>
													<li><a href="womens.html">Daily-wear soft lenses</a></li>
												</ul>	
											</div>		
									</div>
							  </div><!-- row -->
							<div class="row">
									<div class="col-md-6">
											<div class="h_nav">
												<h4>Lens</h4>
												<ul>
													<li><a href="womens.html">Daily-wear soft lenses</a></li>
												</ul>	
											</div>							
									</div>

									<div class="col-md-6">
											<div class="h_nav">
												<h4>Frame</h4>
												<ul>
													<li><a href="womens.html">Daily-wear soft lenses</a></li>
												</ul>	
											</div>		
									</div>
							  </div><!-- row -->
							<div class="row">
									<div class="col-md-6">
											<div class="h_nav">
												<h4>Solutions</h4>
												<ul>
													<li><a href="womens.html">Daily-wear soft lenses</a></li>
												</ul>	
											</div>							
									</div>

									<div class="col-md-6">
											<div class="h_nav">
												<h4>Sun Glasses</h4>
												<ul>
													<li><a href="womens.html">Daily-wear soft lenses</a></li>
												</ul>	
											</div>		
									</div>
							  </div><!-- row -->
							<div class="row">
									<div class="col-md-6">
											<div class="h_nav">
												<h4>Accessories</h4>
												<ul>
													<li><a href="womens.html">Daily-wear soft lenses</a></li>
												</ul>	
											</div>							
									</div>
							  </div><!-- row -->
				</div>
			</li>				

				<li><a class="color5" href="#">Men</a>
					<div class="megapanel">
								<div class="row">
										<div class="col-md-6">
												<div class="h_nav">
													<h4>Contact Lenses</h4>
													<ul>
														<li><a href="womens.html">Daily-wear soft lenses</a></li>
													</ul>	
												</div>							
										</div>

										<div class="col-md-6">
												<div class="h_nav">
													<h4>Eye Glasses</h4>
													<ul>
														<li><a href="womens.html">Daily-wear soft lenses</a></li>
													</ul>	
												</div>		
										</div>
								  </div><!-- row -->
								<div class="row">
										<div class="col-md-6">
												<div class="h_nav">
													<h4>Lens</h4>
													<ul>
														<li><a href="womens.html">Daily-wear soft lenses</a></li>
													</ul>	
												</div>							
										</div>

										<div class="col-md-6">
												<div class="h_nav">
													<h4>Frame</h4>
													<ul>
														<li><a href="womens.html">Daily-wear soft lenses</a></li>
													</ul>	
												</div>		
										</div>
								  </div><!-- row -->
								<div class="row">
										<div class="col-md-6">
												<div class="h_nav">
													<h4>Solutions</h4>
													<ul>
														<li><a href="womens.html">Daily-wear soft lenses</a></li>
													</ul>	
												</div>							
										</div>

										<div class="col-md-6">
												<div class="h_nav">
													<h4>Sun Glasses</h4>
													<ul>
														<li><a href="womens.html">Daily-wear soft lenses</a></li>
													</ul>	
												</div>		
										</div>
								  </div><!-- row -->
								<div class="row">
										<div class="col-md-6">
												<div class="h_nav">
													<h4>Accessories</h4>
													<ul>
														<li><a href="womens.html">Daily-wear soft lenses</a></li>
													</ul>	
												</div>							
										</div>
								  </div><!-- row -->
					</div>

				</li>
				<li><a class="color7" href="<?php echo base_url('Web/Services');?>">Services</a></li>
				<li><a class="color6" href="<?php echo base_url('Web/shops');?>">Optical Shops</a></li>
			</ul>
			</div>
		</div>
	   <div class="header-bottom-right">
         <div class="search">	  
				<input type="text" name="s" class="textbox" value="Search" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}">
				<input type="submit" value="Subscribe" id="submit" name="submit">
				<div id="response"> </div>
		 </div>
	  <div class="tag-list">
	    <ul class="icon1 sub-icon1 profile_img">
			<li><a class="active-icon c1" title="View Reserved items" href="#/reservations" id="reserve_here"> </a>
				</ul>
			</li>
		</ul>
		<ul class="icon1 sub-icon1 profile_img">
			<li><a class="active-icon c2" title="View items in cart" href="#/my_cart" id="cart_here"></a>
			</li>
		</ul>
	  </div>
    </div>
     <div class="clear"></div>
     </div>
	</div>
  <!-- start slider -->
  <hr>