<body ng-app="blinkrr">
     <div class="header-top" ng-controller="WebHeaderUp">
	   <div class="wrap"> 
			  <div class="header-top-left" style="padding-top:1.8%;">
			  	 <a style="text-decoration:none;" href="<?php echo base_url();?>"> 
			  	 		<strong style="color:white;">BLINKRR OPTICAL SOLUTION AND SERVICES</strong>
   				 </a>
   				    <div class="clear"></div>
   			 </div>
			 <div class="cssmenu" style="padding-top:1.2%;font-weight: bold;">
				<ul>
					<?php 
						if($this->session->userdata('sess_access')!="0"){
							echo'<li><a href="javascript:void(0)" ng-click="sign_in()">Log In</a></li> |
							<li><a href="javascript:void(0)" ng-click="signup()">Sign Up</a></li>';
						}else{
							echo'<li><a href="#/appointments" id="appointments_here">Appointments</a></li>|';
							echo'<li><a href="#/my_history">History</a></li>|';
							echo'<li><a href="#/my_history">Insurance</a></li>|';
							echo'<li><a href="#/notifications" id="notice_here">Notifications</a></li>|';
							echo'<li><a href="#/my_profile" id="notice_here">My Profile</a></li>|';
							echo'<li><a href="'.base_url('content/logout').'">Logout</a></li>';
						}
						?>
					
				</ul>
			</div>
			<div class="clear"></div>
 		</div>
	</div>