
<div ng-controller="CartCtrl">
	<h2 class="head">{{page_title}}</h2>
	<div ng-show="cart_table">
			
			<div align="right">
			<!-- 	<button class="btn btn-success btn-lg"> <i class="fa fa-paper-plane"></i> Buy</button> -->
<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" target="_blank">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIICwYJKoZIhvcNAQcEoIIH/DCCB/gCAQExggE6MIIBNgIBADCBnjCBmDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCkNhbGlmb3JuaWExETAPBgNVBAcTCFNhbiBKb3NlMRUwEwYDVQQKEwxQYXlQYWwsIEluYy4xFjAUBgNVBAsUDXNhbmRib3hfY2VydHMxFDASBgNVBAMUC3NhbmRib3hfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tAgEAMA0GCSqGSIb3DQEBAQUABIGAoyT9OKQ7BHi0oPYQNOYoEwu2n5YYzlx+gSfHA5qypnNWV2mhMJSvybVxEdMrdoiWDU6KkINxr/Sc4GhfNL/5bADRL7fh7DqtukOBjV+uIze5z44UIdY00amKkzlZ6zNpYWxGQwpBhLwNZ6lWDCewaUiv2GrMzsJHTrrgxzdK4iExCzAJBgUrDgMCGgUAMIIBVQYJKoZIhvcNAQcBMBQGCCqGSIb3DQMHBAiG+BbjZM7zy4CCATDq13e2dEBcC7dCQQlebkHlARQZX+HSBxjcqrmztDe6fFPvKcjpZc++6nx27u/iKNN0VBqmjmSZWQqmpBev9gT/6fnVkxXr+kdpTQwuctkUbQjkicyKY/Ky4No566yrlyz+I/pRNYWepw6cQqOfucmwQFQGw9aFLsww+O9S4t27wCCQcfQgxd/AEZQkY2XTzhzK+6ZXD4Fjh6jgufbkKqwX1zUDxsQDuEP3n/02YK/Lm40sETddhzTqnkH7x13JtzNDACo31+Gy1jrjADV4GckDHyfIY5ZZKl1MCTk3cu9gsWHz/FhH3q5Pyzx4KQ+V/xR+H/I5R4VSqZOAAmOFt0ouecY3rgXUllZh/WPX3vhpqEA5jLtlJY0brwLqXhCZ8F/OfF+YgQU4tcU/PYCN9fiWoIIDpTCCA6EwggMKoAMCAQICAQAwDQYJKoZIhvcNAQEFBQAwgZgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpDYWxpZm9ybmlhMREwDwYDVQQHEwhTYW4gSm9zZTEVMBMGA1UEChMMUGF5UGFsLCBJbmMuMRYwFAYDVQQLFA1zYW5kYm94X2NlcnRzMRQwEgYDVQQDFAtzYW5kYm94X2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbTAeFw0wNDA0MTkwNzAyNTRaFw0zNTA0MTkwNzAyNTRaMIGYMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTERMA8GA1UEBxMIU2FuIEpvc2UxFTATBgNVBAoTDFBheVBhbCwgSW5jLjEWMBQGA1UECxQNc2FuZGJveF9jZXJ0czEUMBIGA1UEAxQLc2FuZGJveF9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBALeW47/9DdKjd04gS/tfi/xI6TtY3qj2iQtXw4vnAurerU20OeTneKaE/MY0szR+UuPIh3WYdAuxKnxNTDwnNnKCagkqQ6sZjqzvvUF7Ix1gJ8erG+n6Bx6bD5u1oEMlJg7DcE1k9zhkd/fBEZgc83KC+aMH98wUqUT9DZU1qJzzAgMBAAGjgfgwgfUwHQYDVR0OBBYEFIMuItmrKogta6eTLPNQ8fJ31anSMIHFBgNVHSMEgb0wgbqAFIMuItmrKogta6eTLPNQ8fJ31anSoYGepIGbMIGYMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTERMA8GA1UEBxMIU2FuIEpvc2UxFTATBgNVBAoTDFBheVBhbCwgSW5jLjEWMBQGA1UECxQNc2FuZGJveF9jZXJ0czEUMBIGA1UEAxQLc2FuZGJveF9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb22CAQAwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOBgQBXNvPA2Bl/hl9vlj/3cHV8H4nH/q5RvtFfRgTyWWCmSUNOvVv2UZFLlhUPjqXdsoT6Z3hns5sN2lNttghq3SoTqwSUUXKaDtxYxx5l1pKoG0Kg1nRu0vv5fJ9UHwz6fo6VCzq3JxhFGONSJo2SU8pWyUNW+TwQYxoj9D6SuPHHRTGCAaQwggGgAgEBMIGeMIGYMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTERMA8GA1UEBxMIU2FuIEpvc2UxFTATBgNVBAoTDFBheVBhbCwgSW5jLjEWMBQGA1UECxQNc2FuZGJveF9jZXJ0czEUMBIGA1UEAxQLc2FuZGJveF9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTE3MDEyMjA3MDQ1M1owIwYJKoZIhvcNAQkEMRYEFJmJiMafQeH7jGkPIfBxopnnftZSMA0GCSqGSIb3DQEBAQUABIGAUDYDKtuNDWqNNyI6VeN7a61JXvO6VNvd9yBdaJo6JbsFe/Fcu6xW2uDNVplJiRpt9xYv29GMnDlMyWYmFC8wq4XAOpeTo/erdOI1+0rue32erSvUiZ9i9aM2K/XphIXqZKFH8OrLbaSeIeRH8xwodUE8vkaQvAkmMygE5RKQHZE=-----END PKCS7-----
">
<input type="image" src="https://www.sandbox.paypal.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.sandbox.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>



			</div>
			<table class="table table-striped">
				<thead>
					<tr>
						<th>&nbsp;</th>
						<th>Item</th>
						<th>Price</th>
						<th>Quantity</th>
						<th>Amount Due</th>
						<th width="20%">Action</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="x in list" id="inline_{{x.product_id}}">
						<td><img src="<?php echo base_url();?>assets/{{x.product_image}}" style="width:40px;height:40px;" class="img-circle"></td>
						<td>{{x.name}}</td>
						<td>{{x.price}}</td>
						<td>{{x.qty}}</td>
						<td id="due_{{x.product_id}}" class="my_due">{{x.amount_due}}</td>
						<td>
							<button ng-click="process('move_item',x.product_id)" class="btn btn-primary btn-sm"><i class="fa fa-star-o"></i> Move to Reserve</button>
								&nbsp;&nbsp;
							<button ng-click="process('remove_item',x.product_id)"  class="btn btn-danger btn-sm"><i class="fa fa-remove"></i> Remove</button>
						</td>
					</tr>
				</tbody>
				<tfooter>
					<tr>
						<th colspan="4">Total:</th>
						<th id="total_amount"></th>
						<th></th>
					</tr>
				</tfooter>
			</table>

	</div>		



</div><!-- IndexCtrl-->	

<br><br>
<br><br>