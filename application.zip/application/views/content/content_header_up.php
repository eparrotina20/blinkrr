<body ng-app="blinkrr">
     <div class="header-top">
	   <div class="wrap"> 
			  <div class="header-top-left" style="padding-top:1.5%;">
			  	<a href="<?php echo base_url();?>" style="text-decoration:none;">
			  	  <strong style="color:white;">BLINKRR OPTICAL SOLUTION AND SERVICES</strong>
   				    <div class="clear"></div>
   				</a>    
   			 </div>
			 <div class="cssmenu" style="padding-top:1.1%;font-weight: bold;">
				<ul>
					<li class="active"><a href="#/notifications">Notifications (<?php echo $this->session->userdata('sess_access');?>)</a></li> |
					<?php echo $content_up_access;?>
<!-- 					<li><a href="javascript:void(0)" onclick="change_pass()">Change Password</a></li> | -->
					<li><a href="<?php echo base_url('content/logout');?>">Logout</a></li>
				</ul>
			</div>
			<div class="clear"></div>
 		</div>
	</div>