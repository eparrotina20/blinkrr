<br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br>
   <div class="footer">
		<div class="footer-top">
			<div class="wrap">
			</div>
		</div>
		<div class="footer-bottom">
			<div class="wrap">
	             <div class="copy">
			        <p>Blinkrr <a href="#">Optical Solutions</a> and <a href="#">Services</a> </p>
		         </div>
				<div class="f-list2">
				 <ul>
					<li class="active"><a href="about.html">About Us</a></li> |
					<li><a href="delivery.html">Delivery & Returns</a></li> |
					<li><a href="delivery.html">Terms & Conditions</a></li> |
					<li><a href="contact.html">Contact Us</a></li> 
				 </ul>
			    </div>
			    <div class="clear"></div>
		      </div>
	     </div>
	</div>

<style>
  .pre_blocker{
   position:fixed;
   left:0;
   top:0;
   z-index:99999999999;
   width:100%;
   height:100%;
   overflow:visible;
   background: rgba(0,0,0,0.8);
   color: #fff;
   display: table;
}
</style>
  <div id="up_note" style="display:none;position: fixed;z-index: 99999999999; top: 0; left: 0; right: 0; text-align: center;line-height: 3.5;overflow: hidden;  -webkit-box-shadow: 0 0 5px black; -moz-box-shadow:0 0 5px black;box-shadow:0 0 5px black;background-color: khaki;">
    </div>
    

<div class="pre_blocker" style="display:none;">
    <center><p style="padding-top:20%;">Processing...</p></center>
  </div>



<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

<script type="text/javascript" src="<?php echo base_url();?>assets/js/megamenu.js"></script>
<script>$(document).ready(function(){$(".megamenu").megamenu();});</script>
<!--start slider -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/fwslider.css" media="all">
    <script src="<?php echo base_url();?>assets/js/jquery-ui.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/css3-mediaqueries.js"></script>
    <script src="<?php echo base_url();?>assets/js/fwslider.js"></script>
<!--end slider -->
<script src="<?php echo base_url();?>assets/js/jquery.easydropdown.js"></script>
</body>
</html>