
	<div class="header-bottom">
	    <div class="wrap">
			<div class="header-bottom-left">
				<div class="menu">
	    	        <ul class="megamenu skyblue nav nav-pills" id="content_ul" style="font-size: 12px;font-weight: bold;">
						<?php echo $content_down_access;?>
					</ul>
				</div>
		</div>
	 
    </div> <div class="clear"></div>
     <div class="clear"><hr></div>
     </div>
	</div>
  <!-- start slider -->