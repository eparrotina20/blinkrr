<?php $sess_access  = $this->session->userdata('sess_access');?>
<input type="hidden" id="access_type" value="<?php echo $sess_access;?>">
<div ng-controller="ReportsCtrl">

			<ul class="nav nav-tabs" id="report_ul">

			 <?php if($sess_access == "2"){?>	
			  <li class="active" id="patients"><a style="cursor:pointer;" onclick="report_process('report_list','patients')">Registered Patient</a></li>
			  
			  <li id="owners"><a style="cursor:pointer;" onclick="report_process('report_list','owners')">Registered Owner</a></li>

			  <li id="subscriptions"><a style="cursor:pointer;" onclick="report_process('report_list','subscriptions')">Subscriptions</a></li>
			  <?php } ?>
			   <?php if($sess_access == "2" || $sess_access == "1" || $sess_access == "3"){?>	
			  <li id="inventory"><a style="cursor:pointer;" onclick="report_process('report_list','inventory')">Product Inventory</a></li>
			  <li id="shops"><a style="cursor:pointer;" onclick="report_process('report_list','shops')">Optical Shops</a></li>
			  <?php } ?>
			</ul>

			<br>
			<h2 id="module_title"></h2>

			<div id="patients_here" style="display:none;" class="module_list">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Name</th>
							<th>Contact Number</th>
							<th>Gender</th>
							<th>Civil Status</th>
							<th>Date of Birth</th>
							<th>Address</th>
						</tr>
					</thead>
					<tbody id="patient_list"></tbody>
				</table>	

			</div>

			<div id="owners_here" style="display:none;" class="module_list">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Name</th>
							<th>Contact Number</th>
							<th>Gender</th>
							<th>Civil Status</th>
							<th>Date of Birth</th>
							<th>Address</th>
						</tr>
					</thead>
					<tbody id="owner_list"></tbody>
				</table>	

			</div>

			<div id="subscriptions_here" style="display:none;" class="module_list">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Shop Name</th>
							<th>Term</th>
							<th>Start Date</th>
							<th>End Date</th>
							<th>Payment</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody id="sub_list"></tbody>
				</table>
			</div>

			<div id="inventory_here" style="display:none;" class="module_list">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Name</th>
							<th>Model</th>
							<th>Brand</th>
							<th>Quantity</th>
							<th>Re order Point</th>
							<th>Price</th>
						</tr>
					</thead>
					<tbody id="insert_inventory_here"></tbody>
				</table>

			</div>

			<div id="shops_here" style="display:none;" class="module_list">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>&nbsp;</th>
							<th>Name</th>
							<th>Address</th>
							<th>Contact</th>
							<th>Latitude</th>
							<th>Longitude</th>
							<th>&nbsp;</th>
						</tr>
					</thead>
					<tbody id="shop_list"></tbody>
				</table>
			</div>
</div>			

