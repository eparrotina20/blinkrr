<div ng-controller="AppointmentCtrl">
	<h2 class="head">{{page_title}}</h2>

			<table class="table table-striped">
				<thead>
					<tr>
						<th>Customer/Patient</th>
						<th>Service</th>
						<th>Appointment Date</th>
						<th>Appointment Time</th>
						<th>Optical Shop</th>
						<th>Optometrist/ Optician</th>
						<th colspan="2">Status</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="x in list" id="inline_{{x.appointment_id}}">
						<input type="hidden" value="{{x.optshop_id}}" id="shop_id_{{x.appointment_id}}">
						<input type="hidden" value="{{x.patient_id}}" id="patient_id_{{x.appointment_id}}">
						<td>{{x.patient_last}}, {{x.patient_first}}</td>
						<td>{{x.service_name}}</td>
						<td>{{x.app_date}}</td>
						<td>{{x.app_time}}</td>
						<td>{{x.optshop_name}}</td>
						<td>{{x.fname}} {{x.lname}}</td>
						<td>{{x.status}}</td>
						<td><button class="btn btn-primary btn-sm" ng-click="process('respond',x.appointment_id)"><i class="fa fa-check"></i> Respond</button></td>
					</tr>
				</tbody>
			</table>

</div>