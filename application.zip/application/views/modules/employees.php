
<div ng-controller="EmployeeCtrl">
	<h2 class="head">{{module_title}}</h2>
<div align="right">
            <form class="form-inline">
               <?php if($create){?>	
                <div class="form-group system_retrieve">
                    <label for="pwd">Search:</label>
                    <input type="text" class="form-control" ng-model="filter_here">
                </div>
                <?php } ?>
                <?php if($create){?>
                <button type="button" style="z-index:0;"  ng-click="process('create','')" class="btn btn-default system_create">Add</button>
                <?php }?>
            </form>
            <hr>
 </div>

  <table class="table table-striped">
    <thead>
      <tr>
        <th>&nbsp;</th>
        <th>Shop</th>
        <th>Email</th>
        <th>Name</th>
        <th>Address</th>
        <th>Gender</th>
        <th>Civil Status</th>
        <th>License #</th>
        <th>Position</th>
        <?php if($update || $delete){ ?>
        <th colspan="2">Action</th>
        <?php } ?>
      </tr>
    </thead>
    <tbody>
        <tr ng-repeat="emp in list|filter:filter_here" id="tr_{{emp.emp_id}}">
            <td><img src="<?php echo base_url();?>assets/{{emp.emp_image}}" style="width:50px;height:50px;"></td>
            <td>{{emp.optshop_name}}</td>
            <td>{{emp.email}}</td>
            <td>{{emp.lname}}, {{emp.fname}}</td>
            <td>{{emp.address}}</td>
            <td>{{emp.gender}}</td>
            <td>{{emp.civil_status}}</td>
            <td>{{emp.licenseNo}}</td>
            <td>{{emp.position}}</td>
            <?php if($update){ ?>
            <td>
            <button type="button"  style="z-index:0;"  ng-click="process('update',emp.emp_id)"  class="btn btn-success btn-sm"><i class="fa fa-pencil"></i> Update</button>
            </td>
            <?php } ?>


            <?php if($delete){ ?>
            <td>
            <button  style="z-index:0;" ng-click="process('remove',emp.emp_id)" type="button" class="btn btn-danger btn-sm"><i class="fa fa-remove"></i> Delete</button>
            </td>
            <?php } ?>

        </tr>
    </tbody>
  </table>



</div>	