<div ng-controller="ProductCtrl">
	<h2 class="head">{{module_title}}</h2>
<div align="right">
            <form class="form-inline">
               <?php if($create){?>	
                <div class="form-group system_retrieve">
                    <label for="pwd">Search:</label>
                    <input type="text" class="form-control" ng-model="filter_here">
                </div>
                <?php } ?>
                <?php if($create){?>
                <button type="button" style="z-index:0;"  ng-click="process('create','')" class="btn btn-primary system_create"><i class="fa fa-plus"></i> Create Product</button>
                <?php }?>
            </form>
            <hr>
 </div>


  <table class="table table-striped">
    <thead>
      <tr>
        <th>&nbsp;</th>
        <th>Shop</th>
        <th>Name</th>
        <th>Brand</th>
        <th>Model</th>
        <th>Material</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Details</th>
        <?php if($update || $delete){ ?>
        <th colspan="2">Action</th>
        <?php } ?>
      </tr>
    </thead>
    <tbody>
        <tr ng-repeat="x in module_list|filter:filter_here" id="inline_{{x.optprod_id}}">
            <td><img src="<?php echo base_url();?>assets/{{x.optprod_img}}" style="width:50px;height:50px;"></td>
            <td>{{x.optshop_name}}</td>
            <td>{{x.name}}</td>
            <td>{{x.brand}}</td>
            <td>{{x.model}}</td>
            <td>{{x.material}}</td>
            <td>{{x.qty}}</td>
            <td>{{x.price}}</td>
            <td><button class="btn btn-default" style="z-index:0;" ng-click="process('details',x.optprod_id)" >See Details</button></td>
            <?php if($update){ ?>
            <td>
            <button type="button"  style="z-index:0;"  ng-click="process('update',x.optprod_id)"  class="btn btn-success btn-sm"><i class="fa fa-pencil"></i> Update</button>
            </td>
            <?php } ?>


            <?php if($delete){ ?>
            <td>
            <button  style="z-index:0;" ng-click="process('remove',x.optprod_id)" type="button" class="btn btn-danger btn-sm"><i class="fa fa-remove"></i> Remove</button>
            </td>
            <?php } ?>

        </tr>
    </tbody>
  </table>



</div>	