<div ng-controller="AccountCtrl">
	<h2 class="head">{{module_title}}</h2>
<hr>
    <div class="row">
    <form class="form-horizontal">
        <div class="col-md-2">
    

        <img src="<?php echo base_url();?>assets/images/default.png" ng-click="upload_file()" id="img_here" style="height:90%;">

          <div class="form-group" ng-show="my_image">
            <label class="control-label col-sm-2" for="email">Image:</label>
            <div class="col-sm-10">
              <input type="file" class="form-control" alt="Account image" onchange="loadFile(event)" id="file_upload" name="file_upload">
            </div>
          </div>


        </div><!-- col-md-2 -->

        <div class="col-md-5">

            <div class="form-group">
            <label class="control-label col-sm-2" for="email">Email:</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" ng-model="details.em" id="email" name="email">
            </div>
          </div>


            <div class="form-group">
            <label class="control-label col-sm-2" for="email">Last Name:</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="last_name" ng-model="details.lname" name="last_name">
            </div>
          </div>


            <div class="form-group">
            <label class="control-label col-sm-2" for="email">First Name:</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="first_name" ng-model="details.fname" name="first_name">
            </div>
          </div>


            <div class="form-group">
            <label class="control-label col-sm-2" for="email">Middle Name:</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="middle_name" ng-model="details.mname" name="middle_name">
            </div>
          </div>

            <div class="form-group">
            <label class="control-label col-sm-2" for="email">Birth Date:</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="birthdate" ng-model="details.birthdate | date:'MM/dd/yyyy'" name="birthdate">
            </div>
          </div>

        </div><!-- col-md-5 -->

        <div class="col-md-5">
            

            <div class="form-group">
            <label class="control-label col-sm-2" for="email">Gender:</label>
            <div class="col-sm-10" style="padding-top: 1%;">
              <input type="radio" id="gender" value="Male" name="gender"> Male
              &nbsp;&nbsp;
              <input type="radio" id="gender" value="Female"  name="gender"> Female
            </div>
          </div>


            <div class="form-group">
            <label class="control-label col-sm-2" for="email">Address:</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="address" ng-model="details.adds" name="address">
            </div>
          </div>


            <div class="form-group">
            <label class="control-label col-sm-2" for="email">Contact Number:</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="contact" ng-model="details.contact" name="contact">
            </div>
          </div>


            <div class="form-group">
            <label class="control-label col-sm-2" for="email">Civil Status:</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" ng-model="details.cs" id="civil_status" name="civil_status">
            </div>
          </div>


            <div class="form-group">
            <label class="control-label col-sm-2" for="email">&nbsp;</label>
            <div class="col-sm-10" align="right">
             <button type="submit" class="btn btn-success btn-md" id="submit_btn" onclick="process_account('save','')">Save</button>

            </div>
          </div>


        </div><!-- col-md-5 -->
        </form>
    </div><!-- row -->


</div>	