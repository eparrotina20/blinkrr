<div ng-controller="ServicesCtrl">
	<h2 class="head">{{module_title}}</h2>
<div align="right">
            <form class="form-inline">
               <?php if($create){?>	
                <div class="form-group system_retrieve">
                    <label for="pwd">Search:</label>
                    <input type="text" class="form-control" ng-model="filter_here">
                </div>
                <?php } ?>
                <?php if($create){?>
                <button type="button" style="z-index:0;"  ng-click="process('create','')" class="btn btn-primary system_create"><i class="fa fa-plus"></i> Add </button>
                <?php }?>
            </form>
            <hr>
 </div>


  <table class="table table-striped">
    <thead>
      <tr>
        <th>Shop</th>
        <th>Service Name</th>
        <th>Description</th>
        <?php if($update || $delete){ ?>
        <th colspan="2">Action</th>
        <?php } ?>
      </tr>
    </thead>
    <tbody>
        <tr ng-repeat="x in list|filter:filter_here" id="inline_{{x.services_id}}">

            <td id="shop_name_{{x.services_id}}">{{x.optshop_name}}</td>
            <td id="service_name_{{x.services_id}}">{{x.service_name}}</td>
            <td id="description_{{x.services_id}}">{{x.description}}</td>

            <?php if($update){ ?>
            <td>
            <button type="button"  style="z-index:0;"  ng-click="process('update',x.services_id)"  class="btn btn-success btn-sm"><i class="fa fa-pencil"></i> Update</button>
            </td>
            <?php } ?>

            <?php if($delete){ ?>
            <td>
            <button  style="z-index:0;" ng-click="process('remove',x.services_id)" type="button" class="btn btn-danger btn-sm"><i class="fa fa-remove"></i> Delete</button>
            </td>
            <?php } ?>

        </tr>
    </tbody>
  </table>



</div>	