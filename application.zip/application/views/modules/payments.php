
<div ng-controller="PaymentCtrl">
		<ul class="nav nav-tabs" id="pay_ul">
		  <li class="active" id="sales_li"><a href="javascript:void(0)" ng-click="change_tab('sales')">Sales</a></li>
		  <li id="sub_li"><a href="javascript:void(0)" ng-click="change_tab('subscriptions')">Subscription</a></li>
		</ul>
		<br>
		<div class="row" ng-show="sales_tbl">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>&nbsp;</th>
						<th>Product</th>
						<th>Price</th>
						<th>Customer</th>
						<th>Sales</th>
						<th>Date Paid</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="x in sales">
						<td><img src="<?php echo base_url();?>assets/{{x.optprod_img}}" style="width:50px;height:50px;"></td>
						<td>{{x.name}}</td>
						<td>{{x.price}}</td>
						<td>{{x.first_name}} {{x.last_name}}</td>
						<td>{{x.total_sales}}</td>
						<td>{{x.date_paid}}</td>
					</tr>
				</tbody>
			</table>	

		</div>

		<div class="row" ng-show="subs_tbl">

			<div align="right">
				<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" target="_blank">
						<input type="hidden" name="cmd" value="_s-xclick">
						<input type="hidden" name="hosted_button_id" value="URU7UPDVY3C6W">
						<input type="image" src="https://www.sandbox.paypal.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
						<img alt="" border="0" src="https://www.sandbox.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
				</form>
			</div>

			<table class="table table-striped">
				<thead>
					<tr>
						<th>Payment</th>
						<th>Remarks</th>
						<th>Date Paid</th>
						<th>Due Date</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="x in sub_list">
						<td>{{x.payment}}</td>
						<td>{{x.remarks}}</td>
						<td>{{x.date_paid}}</td>
						<td>{{x.due_date}}</td>
					</tr>
				</tbody>
			</table>
		</div>

</div>
