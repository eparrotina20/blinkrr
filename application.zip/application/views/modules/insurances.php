<div ng-controller="InsuranceCtrl">
<!-- 	<h2 class="head">{{module_title}}</h2> -->
<!-- <div align="right">
            <form class="form-inline">
               <?php if($create){?>	
                <div class="form-group system_retrieve">
                    <label for="pwd">Search:</label>
                    <input type="text" class="form-control" ng-model="filter_here">
                </div>
                <?php } ?>
                <?php if($create){?>
                <button type="button" style="z-index:0;"  ng-click="process('create_insurance','')" class="btn btn-primary"><i class="fa fa-users"></i> Create Insurance </button>
                <button type="button" style="z-index:0;"  ng-click="process('company','')" class="btn btn-warning"><i class="fa fa-home"></i> Companies</button>
                <?php }?>
            </form>
            <hr>
 </div> -->

     <ul id="module_tabs" class="nav nav-tabs">
      <li class="active" id="show_insurance"><a data-toggle="tab" ng-click="show_insurance()" href="javascript:void(0);">Insurance List </a></li>
      <li id="show_history"><a href="javascript:void(0);" ng-click="show_history()" >Patient History</a></li>
      <li id="show_companies"><a href="javascript:void(0);" ng-click="show_companies()" >Companies</a></li>
    </ul>
    <br>

    <div ng-show="insurance_list">

        <div class="well well-sm" ng-show="patient_insurance">
            <div align="right">
                <button ng-click="create_insurance('cancel')" class="btn btn-danger"><i class="fa fa-remove"></i> Cancel</button>
            </div>
            <h4>Insurance Details:</h4>
            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                      <label for="email">Company:</label>
                      <select class="form-control" id="in_company">
                        <option value=''>Select Company</option>
                        <option ng-repeat="in_x in x_company" value="{{in_x.company_id}}">{{in_x.company_name}}</option>
                      </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                      <label for="email">Date:</label>
                      <input type="date" class="form-control" id="in_date">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                      <label for="email">Agreement:</label>
                      <textarea class="form-control" id="in_agreement"></textarea>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                      <label for="email">Covered Amount:</label>
                      <input type="number" class="form-control" id="in_covered_amount">
                    </div>

                    <div class="form-group">
                      <label for="email">Authorized Person:</label>
                      <input type="text" class="form-control" id="in_authorized">
                    </div>
                </div>
            </div>
            <hr>
            <h4>Patient Details:</h4>
            <div class="row">
                <br>
                <div class="col-md-4">
                    <div class="form-group">
                      <label for="email">Patient:</label>
                      <select class="form-control" id="in_patient">
                         <option value=''>Select Patient:</option>
                         <option ng-repeat="in_y in x_patient" value="{{in_y.patient_id}}">{{in_y.first_name}} {{in_y.last_name}}</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="email">Employee:</label>
                      <select class="form-control" id="in_employee">
                         <option value=''>Select Employee:</option>
                         <option ng-repeat="in_z in x_employee" value="{{in_z.emp_id}}">{{in_z.fname}} {{in_z.lname}}</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="email">Date:</label>
                      <input type="date" class="form-control" id="in_date">
                    </div>
                    <div class="form-group">
                      <label for="email">OD Sphere:</label>
                      <input type="text" class="form-control" id="in_od_sphere">
                    </div>
                    <div class="form-group">
                      <label for="email">OD Cylinder:</label>
                      <input type="text" class="form-control" id="id_od_cylinder">
                    </div>
                    <div class="form-group">
                      <label for="email">OD Axis:</label>
                      <input type="text" class="form-control" id="in_od_axis">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                      <label for="email">OD RDG ADD:</label>
                      <input type="text" class="form-control" id="in_rdg_add">
                    </div>
                    <div class="form-group">
                      <label for="email">OS Sphere:</label>
                      <input type="text" class="form-control" id="in_os_sphere">
                    </div>
                    <div class="form-group">
                      <label for="email">OS Cylinder:</label>
                      <input type="text" class="form-control" id="in_os_cylinder">
                    </div>
                    <div class="form-group">
                      <label for="email">OS Axis:</label>
                      <input type="text" class="form-control" id="in_os_axis">
                    </div>
                    <div class="form-group">
                      <label for="email">OS RDG ADD:</label>
                      <input type="text" class="form-control" id="in_os_rdg_add">
                    </div>
                    <div class="form-group">
                      <label for="email">Complain:</label>
                      <input type="text" class="form-control" id="in_complain">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                      <label for="email">Diagnosis:</label>
                      <input type="text" class="form-control" id="in_diagnosis">
                    </div>
                    <div class="form-group">
                      <label for="email">Prescription:</label>
                      <input type="text" class="form-control" id="in_prescription">
                    </div>
                    <div class="form-group">
                      <label for="email">Amount:</label>
                      <input type="number" class="form-control" id="in_amount">
                    </div>
                    <div class="form-group">
                      <label for="email">Discount:</label>
                      <input type="number" class="form-control" id="in_discount" onkeyup="insurance_process('minus_discount','');">
                    </div>
                    <input type="hidden" id="running_balance">
                    <div class="form-group">
                      <label for="email">Insurance:</label>
                      <input type="number" class="form-control" onkeyup="insurance_process('count_balance','');" id="in_insurance">
                    </div>
                    <div class="form-group">
                      <label for="email">Balance:</label>
                      <input type="number" class="form-control" disabled="disabled" id="in_balance">
                    </div>
                </div>
            </div>

             <div align="right">
                <button ng-click="create_insurance('cancel')" class="btn btn-danger"><i class="fa fa-remove"></i> Cancel</button>
                &nbsp;&nbsp;
                <button ng-click="process('save_insurance','')" class="btn btn-success"><i class="fa fa-paper-plane"></i> Submit</button>
            </div>

        </div>


      <div align="right" ng-show="insurance_right">
                <form class="form-inline">
                   <?php if($create){?> 
                    <div class="form-group system_retrieve">
                        <label for="pwd">Search:</label>
                        <input type="text" class="form-control" ng-model="filter_herex">
                    </div>
                    <?php } ?>
                    <?php if($create){?>
                    <button type="button" style="z-index:0;"  ng-click="create_insurance('create')" class="btn btn-primary"><i class="fa fa-users"></i> Create Insurance </button>
                    <?php }?>
                </form>
                <hr>
     </div>  

      <table class="table table-striped" ng-show="insurance_table">
        <thead>
          <tr>
            <th>Patient</th>
            <th>Company</th>
            <th>Date</th>
            <th>Agreement</th>
            <th>Authorized Person</th>
            <th>Amount</th>
            <?php if($update || $delete){ ?>
            <th colspan="2">Action</th>
            <?php } ?>
          </tr>
        </thead>
        <tbody>
            <tr ng-repeat="x in list|filter:filter_herex" id="inline_{{x.insurance_id}}">
                <td id="optshop_name_{{x.insurance_id}}">{{x.first_name}} {{x.last_name}}</td>
                <td id="optshop_name_{{x.insurance_id}}">{{x.company_name}}</td>
                <td id="optshop_add_{{x.insurance_id}}">{{x.date}}</td>
                <td id="optshop_tel_{{x.insurance_id}}">{{x.agreement}}</td>
                <td id="optshop_lat_{{x.insurance_id}}">{{x.authorized_person}}</td>
                <td id="optshop_long_{{x.insurance_id}}">{{x.amount}}</td>

                <?php if($update){ ?>
                <td>
                    <button type="button"  style="z-index:0;"  ng-click="process('patient_history',x.pathis_id)"  class="btn btn-success btn-sm"><i class="fa fa-pencil"></i> Patient History</button>
                </td>
                <?php } ?>


                <?php if($delete){ ?>
                <td>
                </td>
                <?php } ?>

            </tr>
        </tbody>
      </table>
    </div>

    <div ng-show="history_list">
        <div align="right">
                <form class="form-inline">
                   <?php if($create){?> 
                    <div class="form-group system_retrieve">
                        <label for="pwd">Search:</label>
                        <input type="text" class="form-control" ng-model="filter_herey">
                    </div>
                    <?php } ?>
                </form>
                <hr>
        </div>
            <table class="table table-striped" ng-show="history_list">
                            <thead>
                                <tr style="font-weight: bold;">
                                    <th>Date</th>
                                    <th style="color:red;">OD Sphere</th>
                                    <th style="color:red;">OD Cylinder</th>
                                    <th style="color:red;">OD Axis</th>
                                    <th style="color:red;">OD RDG ADD</th>
                                    <th style="color:green;">OS Sphere</th>
                                    <th style="color:green;">OS Cylinder</th>
                                    <th style="color:green;">OS Axis</th>
                                    <th style="color:green;">OS RDG ADD</th>
                                    <th>Complain</th>
                                    <th>Diagnosis</th>
                                    <th>Prescription</th>
                                    <th>Amount</th>
                                    <th>Discount</th>
                                    <th>Insurance</th>
                                    <th>Balance</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr ng-repeat="y in ylist|filter:filter_herey" id="inline_{{y.pathis_id}}">
                                    <td>{{y.date}}</td>
                                    <td>{{y.od_sphere}}</td>
                                    <td>{{y.od_cylinder}}</td>
                                    <td>{{y.od_axis}}</td>
                                    <td>{{y.od_rdg_add}}</td>
                                    <td>{{y.os_sphere}}</td>
                                    <td>{{y.os_cylinder}}</td>
                                    <td>{{y.os_axis}}</td>
                                    <td>{{y.os_rdg_add}}</td>
                                    <td>{{y.pat_complain}}</td>
                                    <td>{{y.diagnosis}}</td>
                                    <td>{{y.prescription}}</td>
                                    <td>{{y.amount}}</td>
                                    <td>{{y.discounted_amount}}</td>
                                    <td>{{y.balance_insurance}}</td>
                                    <td>{{y.balance}}</td>
                                    <td>{{y.status}}</td>
                                </tr>
                            </tbody>
            </table>
        </div>

        <div ng-show="company_list">

            <table class="table table-striped" ng-show="company_list">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Contact</th>
                        <th>Action</th>
                        
                    </tr>
                </thead>
                <tbody id="company_here">
                    <tr><input type="hidden" id="company_id">
                        <td><input type="text" placeholder="Company Name" id="company_name" class="form-control"></td>
                        <td><input type="text" placeholder="Address" id="company_address" class="form-control"></td>
                        <td><input type="text" placeholder="Contact" id="company_contact" class="form-control"></td>
                        <td><button onclick="insurance_process('company_save','')" class="btn btn-success btn-sm"><i class="fa fa-paper-plane"></i> SAVE </button></td>
                    </tr>
                </tbody>
            </table>
        </div>    












</div>	