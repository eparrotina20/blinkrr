
<div ng-controller="ReserveCtrl">
	<h2 class="head">{{page_title}}</h2>
	<div ng-show="cart_table">
			
			<table class="table table-striped">
				<thead>
					<tr>
						<th>Patient</th>
						<th>Patient Status</th>
						<th>Shop</th>
						<th>Item Image</th>
						<th>Item</th>
						<th>Price</th>
						<th>Quantity</th>
						<th>Amount Due</th>
<!-- 						<th width="20%">Action</th> -->
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="x in list" id="inline_{{x.product_id}}">
						<td>{{x.last_name}}, {{x.first_name}}</td>
						<td>{{x.patient_status}}</td>
						<td>{{x.optshop_name}}</td>
						<td><img src="<?php echo base_url();?>assets/{{x.product_image}}" style="width:40px;height:40px;" class="img-circle"></td>
						<td>{{x.name}}</td>
						<td>{{x.price}}</td>
						<td>{{x.qty}}</td>
						<td id="due_{{x.product_id}}">{{x.amount_due}}</td>
						<td>
							<button ng-click="process('move_item',x.product_id)" class="btn btn-success btn-sm"><i class="fa fa-shopping-cart"></i> Mark As Sold</button>
								&nbsp;&nbsp;
							<button ng-click="process('remove_item',x.product_id)"  class="btn btn-danger btn-sm"><i class="fa fa-remove"></i> Remove</button>
						</td>
					</tr>
				</tbody>
			</table>

	</div>		



</div><!-- IndexCtrl-->	

<br><br>
<br><br>