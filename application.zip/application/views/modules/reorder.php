
<div ng-controller="ReorderProductCtrl">
	<h2 class="head">{{module_title}}</h2>



  <table class="table table-striped">
    <thead>
      <tr>
        <th>&nbsp;</th>
        <th>Shop</th>
        <th>Name</th>
        <th>Brand</th>
        <th>Model</th>
        <th>Re-Order</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Details</th>
      </tr>
    </thead>
    <tbody>
        <tr ng-repeat="x in module_list|filter:filter_here" id="inline_{{x.optprod_id}}">
            <td><img src="<?php echo base_url();?>assets/{{x.optprod_img}}" style="width:50px;height:50px;"></td>
            <td>{{x.optshop_name}}</td>
            <td>{{x.name}}</td>
            <td>{{x.brand}}</td>
            <td>{{x.model}}</td>
            <td><strong style="color:green;">{{x.reorder}}</strong></td>
            <td><strong style="color:red;">{{x.qty}}</strong></td>
            <td>{{x.price}}</td>
            <td><button class="btn btn-default" style="z-index:0;" ng-click="process('details',x.optprod_id)" >See Details</button></td>

        </tr>
    </tbody>
  </table>



</div>	