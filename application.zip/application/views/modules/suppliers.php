<div ng-controller="SupplierCtrl">
	<h2 class="head">{{module_title}}</h2>


<div align="right">
            <form class="form-inline">
               <?php if($create){?>	
                <div class="form-group system_retrieve">
                    <label for="pwd">Search:</label>
                    <input type="text" class="form-control" ng-model="filter_here">
                </div>
                <?php } ?>
                <?php if($create){?>
                <button type="button" style="z-index:0;"  ng-click="process('create','')" class="btn btn-default system_create">Add Supplier</button>
                <?php }?>
            </form>
            <hr>
 </div>


  <table class="table table-striped">
    <thead>
      <tr>
        <th>&nbsp;</th>
        <th>Company</th>
        <th>Contact Person</th>
        <th>Contact Number</th>
        <th>Email</th>
        <th>Address</th>
        <th>Status</th>
        <?php if($update || $delete){ ?>
        <th colspan="2">Action</th>
        <?php } ?>
      </tr>
    </thead>
    <tbody>
        <tr ng-repeat="x in suppliers|filter:filter_here" id="inline_{{x.sup_id}}">
            <td id="sup_img_{{x.sup_id}}"><img src="<?php echo base_url();?>assets/{{x.sup_image}}" style="width:50px;height:50px;"></td>
            <td id="company_name_{{x.sup_id}}">{{x.company_name}}</td>
            <td id="contact_person_{{x.sup_id}}">{{x.contact_person}}</td>
            <td id="contactNo_{{x.sup_id}}">{{x.contactNo}}</td>
            <td id="email_{{x.sup_id}}">{{x.email}}</td>
            <td id="address_{{x.sup_id}}">{{x.address}}</td>
            <td id="status_{{x.sup_id}}">{{x.status}}</td>
            <?php if($update){ ?>
            <td>
            <button type="button"  style="z-index:0;"  ng-click="process('update',x.sup_id)"  class="btn btn-success btn-sm"><i class="fa fa-pencil"></i> Update</button>
            </td>
            <?php } ?>


            <?php if($delete){ ?>
            <td>
            <button  style="z-index:0;" ng-click="process('remove',x.sup_id)" type="button" class="btn btn-danger btn-sm"><i class="fa fa-remove"></i> Delete</button>
            </td>
            <?php } ?>

        </tr>
    </tbody>
  </table>

</div>	