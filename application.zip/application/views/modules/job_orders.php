<div ng-controller="JobOrderCtrl">

	<ul class="nav nav-tabs" id="job_ul">
		<li id="Reserved" class="active"><a style="cursor:pointer;" ng-click="job_list('Reserved')">Reserved Job Orders</a></li>
		<li id="Sold"><a style="cursor:pointer;" ng-click="job_list('Sold')">Sold Job Orders</a></li>
		<li id="create"><a style="cursor:pointer;" ng-click="process('create','')">Create Job Order</a></li>
	</ul>
	<h2 ng-model="module_title" id="page_title"></h2>		

	<br>

	<table class="table table-striped" id="job_list">
		<thead>
			<tr>
				<th>Shop</th>
				<th>Product</th>
				<th>Patient</th>
				<th>Employee</th>
				<th>Due Date</th>
				<th>OD</th>
				<th>OS</th>
				<th>Remarks</th>
				<th>Discount</th>
				<th>Total</th>
				<th>Deposit</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<tr ng-repeat="x in list" id="inline_{{x.joborder_id}}">
				<td>{{x.shop_name}}</td>
				<td>{{x.product_name}}</td>
				<td>{{x.patient_lname}}, {{x.patient_fname}}</td>
				<td>{{x.emp_lname}}, {{x.emp_fname}}</td>
				<td>{{x.due_date}}</td>
				<td>{{x.od}}</td>
				<td>{{x.os}}</td>
				<td>{{x.remark}}</td>
				<td>{{x.discount}}</td>
				<td>{{x.total}}</td>
				<td>{{x.deposit}}</td>
				<td>{{x.payment_status}}</td>
				<td id="job_{{x.joborder_id}}">{{check_status(x.joborder_id,x.status)}}</td>
			</tr>
		</tbody>
	</table>


	<div id="create_job" style="display: none;">
		         <div class="row">
                <br>
                <input type="hidden" id="in_optshop">
                <input type="hidden" id="job_order_id">
                <div class="col-md-4">
                    <div class="form-group">
                      <label for="email">Patient:</label>
                      <select class="form-control" id="patient_id">
                         <option value=''>Select Patient:</option>
                         <option ng-repeat="in_y in x_patient" value="{{in_y.patient_id}}">{{in_y.first_name}} {{in_y.last_name}}</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="email">Employee:</label>
                      <select class="form-control" id="emp_id" onchange="job_process('find_shop','')">
                         <option value=''>Select Employee:</option>
                         <option ng-repeat="in_z in x_employee" value="{{in_z.emp_id}}">{{in_z.fname}} {{in_z.lname}}</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="email">Due Date:</label>
                      <input type="date" class="form-control pick_date" id="due_date">
                    </div>
                    <div class="form-group">
                      <label for="email">OD</label>
                      <input type="email" class="form-control" id="od">
                    </div>
                    <div class="form-group">
                      <label for="email">OS:</label>
                      <input type="email" class="form-control" id="os">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                      <label for="email">Product:</label>
                      <select class="form-control" id="optprod_id" onChange="job_process('get_price','')">
                         <option value=''>Select Product:</option>
                         <option ng-repeat="x in products" value="{{x.optprod_id}}">{{x.name}} - P{{x.price}}</option>
                      </select>
                    </div>

                    <div class="form-group">
                      <label for="email">Diagnosis:</label>
                      <input type="email" class="form-control" id="in_diagnosis">
                    </div>
                    <div class="form-group">
                      <label for="email">Prescription:</label>
                      <input type="email" class="form-control" id="in_prescription">
                    </div>
                    <div class="form-group">
                      <label for="email">Amount:</label>
                      <input type="email" class="form-control" id="in_amount">
                    </div>
                    <div class="form-group">
                      <label for="email">Promo:</label>
                      <select class="form-control" id="in_promo" onChange="job_process('get_discount','')"></select>   
                    </div>

                </div>
                <div class="col-md-4">
                    <div class="form-group">
                      <label for="email">Discount:</label>
                      <input type="email" class="form-control" id="in_discount">
                    </div>
                    <div class="form-group">
                      <label for="email">Deposit:</label>
                      <input type="number" class="form-control" id="in_deposit">
                    </div>
                    <div class="form-group">
                      <label for="email">Total:</label>
                      <input type="number" class="form-control" id="in_total" disabled="disabled">
                    </div>
                    <div class="form-group">
                      <label for="email">Remarks:</label>
                      <textarea class="form-control" id="in_remarks"></textarea>
                    </div>

                    <hr>
                    <div class="form-group" align="right">
                      <button class="btn btn-success" onclick="job_process('save','')"><i class="fa fa-paper-plane"></i> SAVE</button>
                    </div>
                </div>
            </div>
		
	</div>


</div>