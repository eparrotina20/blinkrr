<div ng-controller="SubscriptionCtrl">
	<h2 class="head">{{module_title}}</h2>
<div align="right">
            <form class="form-inline">
               <?php if($create){?>	
                <div class="form-group system_retrieve">
                    <label for="pwd">Search:</label>
                    <input type="text" class="form-control" ng-model="filter_here">
                </div>
                <?php } ?>
                <!--<?php if($create){?>
                <button type="button" style="z-index:0;"  ng-click="process('create','')" class="btn btn-default system_create">Add Branch</button>
                <?php }?>-->
            </form>
            <hr>
 </div>


  <table class="table table-striped">
    <thead>
      <tr>
        <th>&nbsp;</th>
        <th>Name</th>
        <th>Address</th>
        <th>Contact</th>
        <th>Latitude</th>
        <th>Longitude</th>
        <th>&nbsp;</th>
        <?php if($update || $delete){ ?>
        <th colspan="2">Action</th>
        <?php } ?>
      </tr>
    </thead>
    <tbody>
        <tr ng-repeat="sub in sub_list|filter:filter_here" id="tr_{{sub.optshop_id}}">
            <td><img src="<?php echo base_url();?>assets/{{sub.optshop_img}}" style="width:50px;height:50px;"></td>
            <td id="optshop_name_{{sub.optshop_id}}">{{sub.optshop_name}}</td>
            <td id="optshop_add_{{sub.optshop_id}}">{{sub.optshop_add}}</td>
            <td id="optshop_tel_{{sub.optshop_id}}">{{sub.optshop_tel}}</td>
            <td id="optshop_lat_{{sub.optshop_id}}">{{sub.optshop_lat}}</td>
            <td id="optshop_long_{{sub.optshop_id}}">{{sub.optshop_long}}</td>
            <td><a href="http://www.gps-coordinates.net/" target="_blank">Check Map</a></td>

            <?php if($update){ ?>
            <td>
            <button type="button"  style="z-index:0;"  ng-click="process('update',sub.optshop_id)"  class="btn btn-success btn-sm"><i class="fa fa-pencil"></i> Update</button>
            </td>
            <?php } ?>


            <?php if($delete){ ?>
            <!--<td>
            <button  style="z-index:0;" ng-click="process('remove',sub.optshop_id)" type="button" class="btn btn-danger btn-sm"><i class="fa fa-remove"></i> Delete</button>
            </td>-->
            <?php } ?>

        </tr>
    </tbody>
  </table>



</div>	