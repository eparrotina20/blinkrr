<?php 

defined('BASEPATH') OR exit('No direct script access allowed');


class Globalcall{

	function __construct(){

		$this->CI =& get_instance();
		$this->CI->load->helper('url');
		$this->CI->load->library('session');
		$this->CI->config->item('base_url');
		$this->CI->load->library('encrypt');
		
// SAMPLE BELOW:
// $this->CI->load->view('web/web_header',$data);
// $this->script_calls($data);
// $data['set_scripts'] = array('js/jquery.dataTables','js/dataTables.tableTools.min');
// $data['set_styles'] = array('css/jquery.dataTables.min','css/jquery.dataTables_themeroller','css/dataTables.tableTools');
// $this->script_calls($data);
// $id = $this->CI->session->userdata('sess_id');

	}
	
	function result_callback($res){
		if($res){
			echo"success";
		}else{
			echo"error";
		}
	}

	function check_session(){
		$sess_id = $this->CI->session->userdata('sess_id');
		$sess_email = $this->CI->session->userdata('sess_email');
		$sess_pwd = $this->CI->session->userdata('sess_pwd');
		$sess_access = $this->CI->session->userdata('sess_access');

		if(empty($sess_id) || empty($sess_email) || empty($sess_pwd) || empty($sess_access)){
			return FALSE;
		}else{
			return TRUE;
		}
	}
	
	function web_upper_call($data){

		$this->CI->load->view('web/web_header',$data);
		$this->script_call($data);
		$this->style_call($data);
		$this->CI->load->view('web/web_header_up',$data);
		$this->CI->load->view('web/web_header_down',$data);
		$this->CI->load->view('web/web_slider',$data);
	}

	function web_lower_call($data){

		$this->CI->load->view('web/web_sidebar',$data);
		$this->others($data);
		$this->CI->load->view('web/web_footer',$data);

	}


	function content_upper_call($data){

		$data['content_down_access'] = $this->content_down_access();
		$data['content_up_access'] = $this->content_up_access();

		$this->CI->load->view('content/content_header',$data);
		$this->script_call($data);
		$this->style_call($data);
		$this->CI->load->view('content/content_header_up',$data);
		$this->CI->load->view('content/content_header_down',$data);
	}

	function content_lower_call($data){

		$this->CI->load->view('content/content_sidebar',$data);
		$this->others($data);
		$this->CI->load->view('content/content_footer',$data);

	}

	function script_call($data){
		$this->CI->load->view('others/scripts',$data);
	}

	function style_call($data){
		$this->CI->load->view('others/styles',$data);
	}


	function others($data){
		$this->CI->load->view('others/'.$data['other_call'].'');
	}


	function content_down_access(){

		$sess_id = $this->CI->session->userdata('sess_id');
	if(empty($sess_id)){
		redirect(base_url());
	}
	// 0 - Patient
	// 1 - Optical Shop Owner
	// 2 - blinkrr Admin
	// 3 - Optical Shop Staff
	// 4 - Optometrist/ Optician

		$sess_access = $this->CI->session->userdata('sess_access');
			switch($sess_access){

				case "0":
							$subscriptions = FALSE;
							$reports = FALSE;
							$payments = FALSE;
							$reservations = TRUE;
							$products = TRUE;
							$services = TRUE;
							$opticals = TRUE;
							$employees = TRUE;
							$insurances = TRUE;
							$appointments = TRUE;
							$job_orders = FALSE;
							$suppliers = FALSE;
				break;

				case "1":

							$opticals = FALSE;
							$job_orders = FALSE;
							$subscriptions = TRUE;
							$reports = TRUE;
							$payments = TRUE;
							$reservations = TRUE;
							$products = TRUE;
							$services = TRUE;
							$employees = TRUE;
							$insurances = TRUE;
							$appointments = TRUE;
							$job_orders = TRUE;
							$suppliers = TRUE;

				break;

				case "2":
							$subscriptions = TRUE;
							$reports = TRUE;
							$payments = TRUE;
							$opticals = TRUE;
							$suppliers = FALSE;
							$reservations = FALSE;
							$products = FALSE;
							$services = FALSE;
							$employees = FALSE;
							$insurances = FALSE;
							$appointments = FALSE;
							$job_orders = FALSE;
				break;

				case "3":
							$reports = TRUE;
							$payments = TRUE;
							$reservations = TRUE;
							$products = TRUE;
							$services = TRUE;
							$opticals = TRUE;
							$employees = TRUE;
							$insurances = TRUE;
							$appointments = TRUE;
							$suppliers = TRUE;
							$subscriptions = FALSE;
							$job_orders = TRUE;
				break;

				case "4":
							$products = TRUE;
							$services = TRUE;
							$opticals = TRUE;
							$employees = TRUE;
							$insurances = TRUE;
							$appointments = TRUE;
							$suppliers = TRUE;
							$subscriptions = FALSE;
							$reports = FALSE;
							$payments = FALSE;
							$reservations = FALSE;
							$job_orders = FALSE;
							
				break;

			}//end of switch

		
				if($subscriptions){
					$Subscriptions_access = '<li class="grid" id="li_Subscriptions"><a href="#/subscriptions" onclick="set_active(\'Subscriptions\')">Branches</a></li>';
				}else{
					$Subscriptions_access = '';
				}
				if($reports){	
					$Reports_access = '<li class="grid" id="li_Reports"><a href="#/reports" onclick="set_active(\'Reports\')">Reports</a></li>	';
				}else{
					$Reports_access = '';
				}
				if($payments){
					$Payments_access = '<li class="grid" id="li_Payments"><a href="#/payments" onclick="set_active(\'Payments\')">Payments/Sales</a></li>';
				}else{
					$Payments_access = '';
				}
				if($reservations){
					$Reservations_access = '<li class="grid" id="li_Reservations"><a href="#/reservations" onclick="set_active(\'Reservations\')">Reservations</a></li>';
				}else{
					$Reservations_access = '';
				}
				if($products){
					$Products_access = '<li class="grid" id="li_Products"><a href="#/products" onclick="set_active(\'Products\')">Products</a></li>';
				}else{
					$Products_access = '';
				}
				if($services){
					$Services_access = '<li class="grid" id="li_Services"><a href="#/services" onclick="set_active(\'Services\')">Services</a></li>';
				}else{
					$Services_access = '';
				}
				if($opticals){
					// $Opticals_access = '<li class="grid" id="li_Opticals"><a href="#/opticals" onclick="set_active(\'Opticals\')">Optical Shops</a></li>';

					$Opticals_access = '';
				}else{
					$Opticals_access = '';
				}
				if($employees){
					$Employees_access = '<li class="grid" id="li_Employees"><a href="#/employees" onclick="set_active(\'Employees\')">Employees</a></li>';
				}else{
					$Employees_access = '';
				}
				if($insurances){
					$Insurances_access = '<li class="grid" id="li_Insurances"><a href="#/insurances" onclick="set_active(\'Insurances\')">Insurances</a></li>';
				}else{
					$Insurances_access = '';
				}
				if($appointments){
					$Appointments_access = '<li class="grid" id="li_Appointments"><a href="#/appointments" onclick="set_active(\'Appointments\')">Appointments</a></li>';
				}else{
					$Appointments_access = '';
				}
				if($job_orders){
					$Job_access = '<li class="grid" id="li_Jobs"><a href="#/job_orders" onclick="set_active(\'Jobs\')">Job Orders</a></li>';
				}else{
					$Job_access = '';
				}

				if($suppliers){
					$Supplier_access = '<li class="grid" id="li_Suppliers"><a href="#/suppliers" onclick="set_active(\'Suppliers\')">Suppliers</a></li>';
				}else{
					$Supplier_access = '';
				}	

		$access = "".$Subscriptions_access."".$Reports_access."".$Payments_access."".$Reservations_access."".$Products_access."".$Services_access."".$Opticals_access."".$Employees_access."".$Insurances_access."".$Appointments_access."".$Job_access."".$Supplier_access."";

		return $access;
	}

	function content_up_access(){

	// 0 - Patient
	// 1 - Optical Shop Owner
	// 2 - blinkrr Admin
	// 3 - Optical Shop Staff
	// 4 - Optometrist/ Optician
		
		$sess_access = $this->CI->session->userdata('sess_access');
			switch($sess_access){
				case "0":
					$notifcation = TRUE;
					$account = TRUE;
				break;

				case "1":
					$notifcation = TRUE;
					$account = TRUE;

				case "2":
					$notifcation = FALSE;
					$account = TRUE;
				break;

				case "3":
					$notifcation = FALSE;
					$account = TRUE;
				break;

				case "4":

					$notifcation = FALSE;
					$account = FALSE;
				break;

			}//end of switch
		

		if($sess_access =="1" || $sess_access == "3"){
			$reorder_access = '<li class="active"><a href="#/reorder" onclick="set_active(\'\')">Re-Order <span id="reorder_here"></span></a></li> |';
		}else{
			$reorder_access = '';
		}	
		if($notifcation){
			$notification_access = '<li class="active"><a onclick="set_active(\'Notifications\')" href="#/notifications">Notifications</a></li> |';
		}else{
			$notification_access = '';
		}

		if($account){
			$account_access = '<li class="active"><a href="#/accounts" onclick="set_active(\'Accounts\')">My account</a></li> |';
		}else{
			$account_access = '';
		}	
		

			$access = "".$reorder_access."".$notification_access."".$account_access."";
		return $access;
	}


	function priviledge($module){
		$pieces = explode("|", $this->priviledge_list($module));
		
		$create_get = $pieces[0];
		$retrive_get = $pieces[1];
		$update_get = $pieces[2];
		$delete_get = $pieces[3];

		if($create_get == "0"){
			$create = TRUE;
		}else{
			$create = FALSE;
		}
		if($retrive_get == "0"){
			$retrive = TRUE;
		}else{
			$retrive = FALSE;
		}
		if($update_get == "0"){
			$update = TRUE;
		}else{
			$update = FALSE;
		}
		if($delete_get == "0"){
			$delete = TRUE;
		}else{
			$delete = FALSE;
		}


		$priviledge = "".$create."|".$retrive."|".$update."|".$delete."";

		return $priviledge;
	}
	
	function priviledge_list($module){
		// 0 - WITH RIGHTS | 1 - WITHOUT RIGHTS

		$access = $this->CI->session->userdata('sess_access');
		switch($module){

			case "subscriptions":

				switch($access){
					case "0":
						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "1":
						$create = "0";
						$retrive = "0";
						$update = "0";
						$delete = "0";
					break;
				
					case "2":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "3":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "4":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				}	

			break;

			case "notifications":


				switch($access){
					case "0":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "1":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "2":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "3":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "4":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				}	

			break;

			case "reports":


				switch($access){
					case "0":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "1":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "2":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "3":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "4":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				}	

			break;

			case "payments":


				switch($access){
					case "0":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "1":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "2":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "3":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "4":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				}	

			break;

			case "reservations":


				switch($access){
					case "0":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "1":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "2":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "3":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "4":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				}	

			break;

			case "accounts":


				switch($access){
					case "0":

						$create = "1";
						$retrive = "1";
						$update = "1";
						$delete = "0";
					break;
				
					case "1":

						$create = "1";
						$retrive = "1";
						$update = "1";
						$delete = "0";
					break;
				
					case "2":
						$create = "1";
						$retrive = "1";
						$update = "1";
						$delete = "0";
					break;
				
					case "3":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "4":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				}	

			break;

			case "products":


				switch($access){
					case "0":

						$create = "1";
						$retrive = "0";
						$update = "1";
						$delete = "1";
					break;
				
					case "1":

						$create = "0";
						$retrive = "0";
						$update = "0";
						$delete = "0";
					break;
				
					case "2":
						$create = "1";
						$retrive = "1";
						$update = "1";
						$delete = "1";
					break;
				
					case "3":

						$create = "0";
						$retrive = "0";
						$update = "0";
						$delete = "0";
					break;
				
					case "4":

						$create = "0";
						$retrive = "0";
						$update = "0";
						$delete = "0";
					break;
				}	

			break;

			case "services":


				switch($access){
					case "0":

						$create = "1";
						$retrive = "0";
						$update = "1";
						$delete = "1";
					break;
				
					case "1":

						$create = "0";
						$retrive = "0";
						$update = "0";
						$delete = "0";
					break;
				
					case "2":

						$create = "1";
						$retrive = "1";
						$update = "1";
						$delete = "1";
					break;
				
					case "3":

						$create = "0";
						$retrive = "0";
						$update = "0";
						$delete = "0";
					break;
				
					case "4":

						$create = "0";
						$retrive = "0";
						$update = "0";
						$delete = "0";
					break;
				}	

			break;

			case "opticals":


				switch($access){
					case "0":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "1":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "2":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "3":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "4":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				}	

			break;

			case "employees":


				switch($access){
					case "0":

						$create = "0";
						$retrive = "1";
						$update = "1";
						$delete = "1";
					break;
				
					case "1":

						$create = "0";
						$retrive = "0";
						$update = "0";
						$delete = "0";
					break;
				
					case "2":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "3":

						$create = "1";
						$retrive = "1";
						$update = "1";
						$delete = "1";
					break;
				
					case "4":

						$create = "1";
						$retrive = "0";
						$update = "1";
						$delete = "1";
					break;
				}	

			break;

			case "insurance":


				switch($access){
					case "0":

						$create = "1";
						$retrive = "0";
						$update = "1";
						$delete = "1";
					break;
				
					case "1":

						$create = "0";
						$retrive = "0";
						$update = "0";
						$delete = "0";
					break;
				
					case "2":

						$create = "1";
						$retrive = "1";
						$update = "1";
						$delete = "1";
					break;
				
					case "3":

						$create = "1";
						$retrive = "0";
						$update = "1";
						$delete = "1";
					break;
				
					case "4":

						$create = "1";
						$retrive = "0";
						$update = "1";
						$delete = "1";
					break;
				}	

			break;

			case "suppliers":


				switch($access){
					case "0":

						$create = "1";
						$retrive = "1";
						$update = "1";
						$delete = "1";
					break;
				
					case "1":

						$create = "0";
						$retrive = "0";
						$update = "0";
						$delete = "0";
					break;
				
					case "2":

						$create = "1";
						$retrive = "1";
						$update = "1";
						$delete = "1";
					break;
				
					case "3":

						$create = "1";
						$retrive = "0";
						$update = "1";
						$delete = "1";
					break;
				
					case "4":

						$create = "1";
						$retrive = "1";
						$update = "1";
						$delete = "1";
					break;
				}	

			break;

			case "appointments":


				switch($access){
					case "0":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "1":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "2":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "3":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "4":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				}	

			break;

			case "job_orders":

				switch($access){
					case "0":
						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "1":
						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "2":
						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "3":

						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				
					case "4":
						$create = "";
						$retrive = "";
						$update = "";
						$delete = "";
					break;
				}	


			break;

		}//end of module switch


		$priviledge = "".$create."|".$retrive."|".$update."|".$delete."|";

		return $priviledge;
	}//end of function




































}//end of class