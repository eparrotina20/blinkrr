<?php 

Class Job_orders extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('Job_model','JM');
		$this->load->library('globalcall');
	}

	function index(){
		$this->load->view('modules/job_orders');
	}

	function lists(){
		$this->JM->job_list();
	}

	function process(){

		$res = $this->JM->process_job();
		$this->globalcall->result_callback($res);
	}


































}//end of class