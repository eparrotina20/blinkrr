<?php 

Class Accounts extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('Account_model','AM');
		$this->load->library('global_call');
	}

	function index(){
		echo "alo";
	}




































}//end of class