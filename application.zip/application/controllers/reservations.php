<?php 

Class Reservations extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('Product_model','PM');
		$this->load->library('globalcall');
	}

	function index(){
		$this->load->view('modules/reservations');
	}




































}//end of class