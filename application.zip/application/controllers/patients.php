<?php 

Class Patients extends CI_Controller{


	function __construct(){
		parent::__construct();
		$this->load->model('Patient_model','PM');
		$this->load->library('globalcall');
	}

	function lists(){

		$this->PM->patients();
	}


}