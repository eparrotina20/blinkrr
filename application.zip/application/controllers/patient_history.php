<?php

Class Patient_history extends CI_Controller{


	function __construct(){
		parent::__construct();
		$this->load->model('History_model','HM');
		$this->load->library('globalcall');

		$logged = $this->globalcall->check_session();
		if(!$logged){
			return FALSE;
		}

	}

	function lists(){

		$this->HM->history_list();
	}















}//end of class