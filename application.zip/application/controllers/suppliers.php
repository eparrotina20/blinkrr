<?php 

Class Suppliers extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('Supplier_model',"SM");
		$this->load->library('globalcall');
	}

	function index(){
		$pieces = explode("|", $this->globalcall->priviledge('suppliers'));
		
		$data['create'] = $pieces[0];
		$data['retrive'] = $pieces[1];
		$data['update'] = $pieces[2];
		$data['delete'] = $pieces[3];


		$this->load->view('modules/suppliers',$data);
	}


	function lists(){
		$this->SM->supplier_list();
	}

	function process(){

		$res = $this->SM->supplier_process();

		if($res){
			echo"success";
		}else{
			echo"error";
		}
	}







}//end of class