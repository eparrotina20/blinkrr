<?php 

Class Products extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('Content_model','CM');
		$this->load->model('Product_model','PM');
		$this->load->library('globalcall');
	}

	function index(){
		$pieces = explode("|", $this->globalcall->priviledge('products'));
		
		$data['create'] = $pieces[0];
		$data['retrive'] = $pieces[1];
		$data['update'] = $pieces[2];
		$data['delete'] = $pieces[3];

		$this->load->view('modules/products',$data);
	}

	function lists(){
		$this->PM->product_list();
	}

	function type_list(){
		$this->PM->list_type();
	}

	function process(){
		$res = $this->PM->product_process();	
		$this->globalcall->result_callback($res);

	}

	function in_cart(){
		$this->PM->cart_products();
	}

	function in_reserved(){
		$this->PM->reserved_products();
	}

	function cart_reserve(){
		$cart_added = $this->PM->cart_reserve();
		$this->globalcall->result_callback($cart_added);
	}

	function remove_item(){
		$res = $this->PM->item_removed();
		$this->globalcall->result_callback($res);
	}

	function move_item(){
		$res = $this->PM->item_moved();
		$this->globalcall->result_callback($res);
	}

	function pay_items(){
		
		$sess_id = $this->session->userdata('sess_id');

		if(empty($sess_id)){
			redirect(base_url());
		}else{
			$this->db->where('patient_id',$sess_id);
			$query =  $this->db->update('my_cart',array('payment_status'=>'Paid','status'=>'Paid','date_paid'=>date('Y-m-d')));
			
			if($query){
				//echo"Success";
				redirect(base_url());
			}else{
				echo"Error";
			}
		}
	
	}


	function reorder_list(){
		$data['update'] = TRUE;
		$this->load->view('modules/reorder',$data);
	}

	function reorder(){
		$this->PM->reorder_list();
	}






















}//end of class