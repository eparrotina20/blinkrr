<?php 

Class Accounts extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('Account_model','AM');
		$this->load->library('globalcall');
	}

	function index(){

		$pieces = explode("|", $this->globalcall->priviledge('accounts'));
		
		$data['create'] = $pieces[0];
		$data['retrive'] = $pieces[1];
		$data['update'] = $pieces[2];
		$data['delete'] = $pieces[3];

		$this->load->view('modules/accounts',$data);
	}

	function get_info(){

		 $this->AM->info_get();
	}


	function save_account(){

		$res = $this->AM->account_save();

		if($res){
			echo"success";
		}else{
			echo"error";
		}
	}































}//end of class