<?php 

Class Insurances extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('Insurance_model','IM');
		$this->load->library('globalcall');
	}

	function index(){
		$pieces = explode("|", $this->globalcall->priviledge('insurance'));
		
		$data['create'] = $pieces[0];
		$data['retrive'] = $pieces[1];
		$data['update'] = $pieces[2];
		$data['delete'] = $pieces[3];

		$this->load->view("modules/insurances",$data);
	}

	function lists(){
		$this->IM->insurance_list();
	}

	function company_list(){
		$this->IM->companies();
	}

	function company_process(){
		$res = $this->IM->process_company();
		$this->globalcall->result_callback($res);
	}
	
































}//end of class