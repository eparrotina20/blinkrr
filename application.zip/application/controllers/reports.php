<?php 

Class Reports extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('Report_model','RM');
		$this->load->library('globalcall');
	}

	function index(){
		$this->load->view("modules/reports");
	}


	function lists(){
		$this->RM->record_list();
	}

































}//end of class