<?php 

Class Services extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('Service_model','SM');
		$this->load->library('globalcall');
	}

	function index(){
	
		$pieces = explode("|", $this->globalcall->priviledge('services'));
		
		$data['create'] = $pieces[0];
		$data['retrive'] = $pieces[1];
		$data['update'] = $pieces[2];
		$data['delete'] = $pieces[3];

		$this->load->view('modules/services',$data);
	}

	function lists(){
		$this->SM->service_list();
	}


	function process(){
		$res = $this->SM->process_service();

		if($res){
			echo"success";
		}else{
			echo"error";
		}

	}
































}//end of class