<?php 

Class Web extends CI_Controller{


	function __construct(){
		parent::__construct();
		$this->load->model("Web_model","WM");
		$this->load->library('globalcall');
		$this->load->library('encrypt');
	}


	function index(){
		$sess_access = $this->session->userdata('sess_access');
		$check_session = $this->check_session();

		if($check_session == "sess_exist"){
				
			if($sess_access == "0"){
				$this->dashboard();	
			}else{
				redirect(base_url('content'));
			}	

		
		}elseif($check_session == "sess_empty"){

			$data['page_title'] = "Home";
			$data['other_call'] = "global_modal";
			$data['set_scripts'] = array('system/js/web.js','system/js/web_process.js');

			$this->globalcall->web_upper_call($data);
			$this->load->view('web/index');
			$this->globalcall->web_lower_call($data);	
		}
	}


	function dashboard(){

		$sess_access = $this->session->userdata('sess_access');
		$data['page_title'] = "Home";
		$data['other_call'] = "global_modal";
		$data['set_scripts'] = array('system/js/web.js','system/js/web_process.js');
		$this->globalcall->web_upper_call($data);
		$this->load->view('web/index');
		$this->globalcall->web_lower_call($data);	

	}

	function sign_up(){
		$res = $this->WM->insert_sign_up();
		if($res){
			echo"success";
		}else{
			echo"error";
		}
	}

	function sign_in(){
		$signin_attr = $this->input->post('signin_attr');
		$action = $signin_attr['action'];
		$signin_email = $signin_attr['signin_email'];
		$signin_pwd = $signin_attr['signin_pwd'];
		$choose_access = $signin_attr['choose_access'];

		if($choose_access == "1"){

			$query = $this->db->query("SELECT os.optshop_id,ors.owner_id,ors.email,ors.pw FROM owner as ors LEFT JOIN opt_shops as os ON os.owner_id=ors.owner_id WHERE ors.email='$signin_email' AND ors.pw='$signin_pwd'");
			if($query->num_rows() > 0){
				$row = $query->row_array();
				$shop_id = $row['optshop_id'];

				$query2 = $this->db->query("SELECT due_date,shop_id,id FROM subscription_payments WHERE shop_id='$shop_id' ORDER BY id DESC LIMIT 1");
				$row2 = $query2->row_array();
				
				$to_date = date('Y-m-d');
				$due_date = $row2['due_date'];
				$new_due = date('Y-m-d', strtotime($due_date. ' + 15 days'));

				if($to_date > $new_due){
					echo "deactivate";
				}else{
					$this->sign_in_process();
				}
				
			}else{
				echo"error";				
			}

		}else{

			$this->sign_in_process();
		}	

	}

	function sign_in_process(){
		
		$signin_attr = $this->input->post('signin_attr');
		$action = $signin_attr['action'];
		
		$res = $this->WM->in_sign();
			if($action == "web"){
				if($res){
					echo"success";
				}else{
					echo"error";
				}
			}elseif($action == "mobile"){

				if(!$res){
					echo"error";
				}else{
					foreach($res as $row){
						echo"".$this->encrypt->encode($row['patient_id'])."|".$this->encrypt->encode($row['email'])."|".$this->encrypt->encode($row['pw'])."|0";
					}
				}

			}

	}

	function check_session(){
		$sess_email = $this->session->userdata('sess_email');
		$sess_pwd = $this->session->userdata('sess_pwd');
		$sess_access = $this->session->userdata('sess_access');
	
		if(empty($sess_email) && empty($sess_pwd) && empty($sess_access)){
			$val = "sess_empty";
		}else{
			$val = "sess_exist";
		}

			return $val;
	}


	function web_index(){
		$this->load->view('web/web_index');
	}

	function services(){
			$data['page_title'] = "Home";
			$data['other_call'] = "global_modal";
			$data['set_scripts'] = array('system/js/web.js','system/js/web_process.js');

			$this->globalcall->web_upper_call($data);
				$this->load->view('web/web_services');

		$this->globalcall->web_lower_call($data);	
	}

	function shops(){
					$data['page_title'] = "Home";
			$data['other_call'] = "global_modal";
			$data['set_scripts'] = array('system/js/web.js','system/js/web_process.js');

			$this->globalcall->web_upper_call($data);
		$this->load->view('web/web_shops');
		
		$this->globalcall->web_lower_call($data);	
	}

	function opticals(){

		$this->WM->optical_list();
	}

	function my_cart(){
		$this->load->view('web/web_cart');
	}

	function my_reserved(){
		$this->load->view('web/web_reservation');
	}

	function appointments(){
		$this->load->view('web/web_appointments');
	}

	function my_history(){
		$this->load->view('web/web_history');
	}

	function notice(){
		$this->load->view('web/web_notice');
	}

	function view_shop(){
		$this->load->view('web/web_shop_details');
	}

	function my_profile(){
		$this->load->view('web/my_profile');
	}

	function shop_details(){
		$shop_id = $this->input->post('shop_id');

		$query = $this->db->query("SELECT * FROM opt_shops WHERE optshop_id='$shop_id'");
		$row = $query->row_array();
		$data['shop_name'] = $row['optshop_name'];
		$data['shop_add'] = $row['optshop_add'];
		$data['shop_tel'] = $row['optshop_tel'];
		$data['shop_img'] = $row['optshop_img'];
		$data['page_title'] = $row['optshop_name'];


		$optshop_from_hour = $row['optshop_from_hour'];
		$optshop_from_min = $row['optshop_from_min'];
		$optshop_to_hour = $row['optshop_to_hour'];
		$optshop_to_min = $row['optshop_to_min'];


		    	 if($optshop_from_hour == "13"){
			        $return_from = "01";
			      }
			      elseif($optshop_from_hour == "14"){
			        $return_from = "02";
			      }
			      elseif($optshop_from_hour == "15"){
			        $return_from = "03";
			      }
			      elseif($optshop_from_hour == "16"){
			        $return_from = "04";
			      }
			      elseif($optshop_from_hour == "17"){
			        $return_from = "05";
			      }
			      elseif($optshop_from_hour == "18"){
			        $return_from = "06";
			      }
			      elseif($optshop_from_hour == "19"){
			        $return_from = "07";
			      }
			      elseif($optshop_from_hour == "20"){
			        $return_from = "08";
			      }
			      elseif($optshop_from_hour == "21"){
			        $return_from = "09";
			      }
			      elseif($optshop_from_hour == "22"){
			        $return_from = "10";
			      }
			      elseif($optshop_from_hour == "23"){
			        $return_from = "11";
			      }
			      elseif($optshop_from_hour == "24"){
			        $return_from = "12";
			      }
			      else{
			        $return_from = $optshop_from_hour;
			      }


		    	 if($optshop_to_hour == "13"){
			        $return_to = "01";
			      }
			      elseif($optshop_to_hour == "14"){
			        $return_to = "02";
			      }
			      elseif($optshop_to_hour == "15"){
			        $return_to = "03";
			      }
			      elseif($optshop_to_hour == "16"){
			        $return_to = "04";
			      }
			      elseif($optshop_to_hour == "17"){
			        $return_to = "05";
			      }
			      elseif($optshop_to_hour == "18"){
			        $return_to = "06";
			      }
			      elseif($optshop_to_hour == "19"){
			        $return_to = "07";
			      }
			      elseif($optshop_to_hour == "20"){
			        $return_to = "08";
			      }
			      elseif($optshop_to_hour == "21"){
			        $return_to = "09";
			      }
			      elseif($optshop_to_hour == "22"){
			        $return_to = "10";
			      }
			      elseif($optshop_to_hour == "23"){
			        $return_to = "11";
			      }
			      elseif($optshop_to_hour == "24"){
			        $return_to = "12";
			      }
			      else{
			        $return_to = $optshop_to_hour;
			      }


			      if($optshop_from_hour > 11){
			      	$merdian_from = "pm";
			      }else{
			      	$merdian_from = "am";
			      }

			      if($optshop_to_hour > 11){
			      	$merdian_to = "pm";
			      }else{
			      	$merdian_to = "am";
			      }

		$data['business_hours'] = "".$return_from.":".$optshop_from_min."".$merdian_from." - ".$return_to.":".$optshop_to_min."".$merdian_to."";	      

		$data['optshop_from_hour'] = $optshop_from_hour;
		$data['optshop_from_min'] = $optshop_from_min;
		$data['optshop_to_hour'] = $optshop_to_hour;
		$data['optshop_to_min'] = $optshop_to_min;
		$owner = $row['owner_id'];

		$own = $this->db->query("SELECT owner_id,first_name,middle_name,last_name FROM owner WHERE owner_id='$owner'");
		$own_row = $own->row_array();
		$data['owner_name'] = "".$own_row['last_name'].", ".$own_row['first_name']." ".$own_row['middle_name']." ";

		$data['products'] = $this->WM->shop_products();
		$data['services'] = $this->WM->shop_services();
		
		$data['other_call'] = "global_modal";
		$data['set_scripts'] = array('system/js/web.js','system/js/web_process.js');
		$this->globalcall->web_upper_call($data);
		$this->load->view('web/web_shop_details',$data);
		$this->globalcall->web_lower_call($data);	
	}


	function get_profile(){
		$this->WM->profile_get();
	}

	function profile_update(){
		$res = $this->WM->update_profile();
		$this->globalcall->result_callback($res);
	}

} //end of class