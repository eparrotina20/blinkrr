<?php 

Class Notifications extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('Notification_model','NM');
		$this->load->library('globalcall');
	}

	function index(){
		$this->load->view('modules/notifications');
	}


	function lists(){
		$this->NM->notification_list();
	}

	function notice_only(){
		$this->NM->only_notice();
	}

	function process(){
		$res = $this->NM->process_notice();
		$this->globalcall->result_callback($res);
	}































}//end of class