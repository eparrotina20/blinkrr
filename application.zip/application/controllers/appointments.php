<?php 

Class Appointments extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('Appointment_model','AM');
		$this->load->library('globalcall');
	
		$logged = $this->globalcall->check_session();
		if(!$logged){
			return FALSE;
		}

	}

	function index(){
		$this->load->view('modules/appointments');
	}

	function lists(){

		$this->AM->appointment_list();
	}

	function process(){
		$res = $this->AM->process_appointment();
		$this->globalcall->result_callback($res);

	}


































}//end of class