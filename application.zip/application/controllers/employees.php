<?php 

Class Employees extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('Employee_model','EM');
		$this->load->library('globalcall');
	}

	function index(){
		$pieces = explode("|", $this->globalcall->priviledge('employees'));
		
		$data['create'] = $pieces[0];
		$data['retrive'] = $pieces[1];
		$data['update'] = $pieces[2];
		$data['delete'] = $pieces[3];

		$this->load->view('modules/employees',$data);
	}


	function employee_list(){
		$this->EM->get_list();
	}


	function process(){
		$res = $this->EM->process();
	
		if($res){
			echo"success";
		}else{
			echo"error";
		}
	}
































}//end of class