<?php 

Class Promos extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('Promo_model','PM');
		$this->load->library('globalcall');
	}

	function lists(){
		$this->PM->promo_list();
	}





}