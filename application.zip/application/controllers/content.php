<?php

Class Content extends CI_Controller{

	function __construct(){

		parent::__construct();
		$this->load->model("Content_model","CM");
		$this->load->library('globalcall');
	}

	function index(){

			$sess_access = $this->session->userdata('sess_access');

			if($sess_access !="0"){

				$data['page_title'] = "Dashboard";
				$data['other_call'] = "global_modal";
				$data['set_scripts'] = array('system/js/content.js','system/js/content_process.js');

				$this->globalcall->content_upper_call($data);
				$this->load->view('content/index');
				$this->globalcall->content_lower_call($data);	
				
			}else{
				redirect(base_url());
			}

	}


	function dashboard(){
		$sess_id = $this->session->userdata('sess_id');
		$query = $this->db->query("SELECT os.optshop_id,ors.owner_id,ors.email,ors.pw FROM owner as ors LEFT JOIN opt_shops as os ON os.owner_id=ors.owner_id WHERE ors.owner_id='$sess_id'");

		$row = $query->row_array();
		$shop_id = $row['optshop_id'];

		$query2 = $this->db->query("SELECT due_date,shop_id,id FROM subscription_payments WHERE shop_id='$shop_id' ORDER BY id DESC LIMIT 1");
		$row2 = $query2->row_array();
		
		$due_date = $row2['due_date'];
		$new_due = date('Y-m-d', strtotime($due_date. ' + 15 days'));

		$next_due_date = date('Y-m-d', strtotime($due_date. ' + 1 month'));
		$next_due_date2 = date('Y-m-d', strtotime($next_due_date. ' + 15 days'));


		echo "<h2>Welcome back</h2>";
		echo'<br>
			<div class="row">
				<div class="col-md-3">
					Next Due Date: <strong>'.$next_due_date2.'</strong>
				</div>
				<div class="col-md-9">
					<i>Pay subscription:</i>
					<br><br>
					<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" target="_blank">
						<input type="hidden" name="cmd" value="_s-xclick">
						<input type="hidden" name="hosted_button_id" value="URU7UPDVY3C6W">
						<input type="image" src="https://www.sandbox.paypal.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
						<img alt="" border="0" src="https://www.sandbox.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
					</form>
				</div>	
			</div>
		';
	}

	function logout(){

		$this->session->sess_destroy();
		redirect(base_url());
	}

	function priviledge($module){
		

		$pieces = explode("|", $this->globalcall->priviledge('subscriptions'));
		
		$create_get = $pieces[0];
		$retrive_get = $pieces[1];
		$update_get = $pieces[2];
		$delete_get = $pieces[3];

		if($create_get == "0"){
			$create = TRUE;
		}else{
			$create = FALSE;
		}
		if($retrive_get == "0"){
			$retrive = TRUE;
		}else{
			$retrive = FALSE;
		}
		if($update_get == "0"){
			$update = TRUE;
		}else{
			$update = FALSE;
		}
		if($delete_get == "0"){
			$delete = TRUE;
		}else{
			$delete = FALSE;
		}


		$data['create'] = $create;
		$data['retrive'] = $retrive;
		$data['update'] = $update;
		$data['delete'] = $delete;


	}








}//end of class