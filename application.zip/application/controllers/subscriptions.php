<?php 

Class Subscriptions extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('Subscription_model',"SBM");
		$this->load->library('globalcall');
		$this->load->model('Content_model','CM');

		$logged = $this->globalcall->check_session();
		if(!$logged){
			redirect(base_url());
		}

	}

	function index(){

		$pieces = explode("|", $this->globalcall->priviledge('subscriptions'));
		
		$data['create'] = $pieces[0];
		$data['retrive'] = $pieces[1];
		$data['update'] = $pieces[2];
		$data['delete'] = $pieces[3];

		$this->load->view('modules/subscriptions',$data);
	}

	function sub_list(){
		$this->SBM->subscription_list();
	}


	function process(){
		$res = $this->SBM->sub_process();

		if($res){
			echo"success";
		}else{
			echo"error";
		}

	}


	function pay_subscribe(){
		$shop_id = $this->CM->find_shop();

		$query = $this->db->query("SELECT id,due_date,shop_id,status FROM subscription_payments WHERE shop_id = '$shop_id' AND status='0' LIMIT 1");
		$row = $query->row_array();
		$due_date = $row['due_date'];
		$id = $row['id'];
		$shop_id = $row['shop_id'];

		$to_date = date('Y-m-d');
		$new_due = date('Y-m-d', strtotime($due_date. ' + 15 days'));

		$from_date = date('Y-m-d', strtotime($due_date. ' - 1 month'));

		$next_due_date = date('Y-m-d', strtotime($due_date. ' + 1 month'));
		$next_due_date2 = date('Y-m-d', strtotime($next_due_date. ' + 15 days'));

		$save_array = array(
			'shop_id' => $shop_id,
			'payment' => '500',
			'remarks' => 'For Payment',
			'due_date' => $next_due_date
		);

		$this->db->insert('subscription_payments',$save_array);

		$this->db->where('id',$id);
		$qx = $this->db->update('subscription_payments',array('status'=>'1','remarks'=>'Covered: '.$from_date.' - '.$due_date.''));

		if($qx){
			redirect(base_url());
		}else{
			echo"error";
		}

	}



	
}//end of class