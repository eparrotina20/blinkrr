<?php 

Class Payments extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('Payment_model','PM');
		$this->load->library('globalcall');
	}

	function index(){
		$this->load->view('modules/payments');
	}

	function sales(){
		$this->PM->sales_list();
	}


	function subs(){
		$this->PM->sub_list();
	}
































}//end of class